﻿import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import ReactDOM from 'react-dom';
import {
  Home, FolderKanban, CheckSquare, AlertTriangle, CalendarDays, Repeat,
  LayoutTemplate, BarChart3, Settings, Users, LogOut, Plus,
  Search, Bell, ChevronRight, Edit3, Trash2, Clock, X, ChevronLeft,
  Check, AlertCircle, AlarmClockPlus, ChevronDown, ListTree,
  CornerDownRight, ToggleLeft, ToggleRight, Paperclip, BellRing, Mic, Archive,
  FileText, ExternalLink, Minus, Package, MessageSquare,
} from 'lucide-react';

// Detect Electron  //
const isElectron = typeof window !== 'undefined' && window.electronAPI !== undefined;

//  Helpers //
const now = new Date();
const fmt = (d) => d ? `${String(d.getDate()).padStart(2,'0')}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getFullYear()).toString().slice(-2)}` : '';
const fmtFull = (d) => d ? `${fmt(d)} ${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}` : '';
const daysFromNow = (n) => new Date(now.getTime() + n * 86400000);
const parseStoredDueDate = (value) => {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const [datePart, timePart = '09:00'] = raw.split(' ');
  const [dd, mm, yy] = datePart.split('-');
  if (!dd || !mm || !yy) return null;
  const [hh = '09', min = '00'] = String(timePart).split(':');
  const parsed = new Date(`20${yy}-${mm}-${dd}T${String(hh).padStart(2, '0')}:${String(min).padStart(2, '0')}:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
};
const toDateInputValue = (storedDueDate) => {
  const d = parseStoredDueDate(storedDueDate);
  if (!d) return '';
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
};
const dueDateFromDuration = (durationVal, durationUnit, includeTime = false) => {
  const amount = parseInt(durationVal, 10);
  if (!Number.isFinite(amount) || amount <= 0) return '';
  let deltaMs = amount * 86400000;
  if (String(durationUnit || '') === 'Hours') deltaMs = amount * 3600000;
  else if (String(durationUnit || '') === 'Weeks') deltaMs = amount * 7 * 86400000;
  const target = new Date(Date.now() + deltaMs);
  return includeTime ? fmtFull(target) : fmt(target);
};

//  Error Boundary //
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error('Render error:', error, info);
  }
  render() {
    if (this.state.error) {
      return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#f8fafc', fontFamily: "'DM Sans', system-ui" }}>
          <div style={{ background: '#fff', borderRadius: 14, padding: 24, width: 520, border: '1px solid #e2e8f0' }}>
            <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, color: '#0f172a' }}>Something went wrong</h2>
            <p style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>The app hit an error while rendering.</p>
            <pre style={{ marginTop: 12, fontSize: 11, color: '#ef4444', whiteSpace: 'pre-wrap' }}>
              {String(this.state.error)}
              {this.state.error?.stack ? `\n\n${this.state.error.stack}` : ''}
            </pre>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

const STATUS_OPTIONS = ['Not Started', 'In Progress', 'Report Issue', 'Completed', 'On Hold'];
const STATUS_COLORS = {
  'Not Started': { bg: '#f1f5f9', text: '#64748b', dot: '#94a3b8' },
  'In Progress': { bg: '#dbeafe', text: '#1d4ed8', dot: '#3b82f6' },
  'Report Issue': { bg: '#fee2e2', text: '#dc2626', dot: '#ef4444' },
  'Completed': { bg: '#dcfce7', text: '#16a34a', dot: '#22c55e' },
  'On Hold': { bg: '#fef3c7', text: '#d97706', dot: '#f59e0b' },
  'Pending Review': { bg: '#ede9fe', text: '#7c3aed', dot: '#8b5cf6' },
  'Pending Delete': { bg: '#fee2e2', text: '#dc2626', dot: '#ef4444' },
  'Review Rejected': { bg: '#fee2e2', text: '#dc2626', dot: '#ef4444' },
  Archived: { bg: '#e2e8f0', text: '#475569', dot: '#94a3b8' },
  Scheduled: { bg: '#e0f2fe', text: '#0284c7', dot: '#0ea5e9' },
  Open: { bg: '#fee2e2', text: '#dc2626', dot: '#ef4444' },
  Active: { bg: '#dbeafe', text: '#1d4ed8', dot: '#3b82f6' },
  Planned: { bg: '#f1f5f9', text: '#64748b', dot: '#94a3b8' },
  Resolved: { bg: '#dcfce7', text: '#16a34a', dot: '#22c55e' },
  Closed: { bg: '#f1f5f9', text: '#94a3b8', dot: '#cbd5e1' },
};
const PRIORITY_OPTIONS = ['Low', 'Medium', 'High', 'Critical'];
const PROJECT_STATUS = ['Planned', 'Active', 'On Hold', 'Completed', 'Cancelled'];
const ISSUE_STATUS = ['Open', 'In Progress', 'Resolved', 'Closed'];
const SYSTEM_ADMIN_NAME = 'Admin';
const SUPERADMIN_ROLE = 'Superadmin';
const BASE_ROLE = 'Executive';
const isBaseRole = (role) => ['Employee', BASE_ROLE].includes(String(role || ''));
const displayRole = (role) => String(role || 'Employee') === 'Employee' ? BASE_ROLE : String(role || BASE_ROLE);
const isSuperadminRole = (role) => String(role || '').trim().toLowerCase() === SUPERADMIN_ROLE.toLowerCase();
const isAdminRole = (role) => ['admin', 'superadmin'].includes(String(role || '').trim().toLowerCase());
const isAdminLikeRole = (role) => isAdminRole(role) || String(role || '').trim() === 'Manager';
const isDirectorRole = (role) => ['director', 'directors'].includes(String(role || '').trim().toLowerCase());
const COMPLETED_TASK_STATUSES = new Set(['Completed', 'Archived']);
const isTaskFinishedStatus = (status) => COMPLETED_TASK_STATUSES.has(String(status || ''));
const isTaskCompleted = (task) => isTaskFinishedStatus(task?.status) && !task?.reviewRejectedUnseen;
const splitMultiValue = (value) => String(value || '').split(',').map(v => v.trim()).filter(Boolean);
const joinMultiValue = (values) => [...new Set((values || []).map(v => String(v || '').trim()).filter(Boolean))].join(', ');
const includesMultiValue = (value, target) => {
  const cleanTarget = String(target || '').trim().toLowerCase();
  return !!cleanTarget && splitMultiValue(value).some(v => v.toLowerCase() === cleanTarget);
};
const textFromValue = (value) => {
  if (value == null) return '';
  if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (Array.isArray(value)) return value.map(textFromValue).join(' ');
  if (React.isValidElement(value)) return textFromValue(value.props?.children);
  return String(value);
};
const parseComparableDate = (value) => {
  const raw = String(value || '').trim();
  const match = raw.match(/^(\d{2})-(\d{2})-(\d{2,4})(?:\s+(\d{1,2}):(\d{2}))?/);
  if (!match) return null;
  const [, dd, mm, yy, hh = '00', min = '00'] = match;
  const year = yy.length === 2 ? `20${yy}` : yy;
  const parsed = new Date(`${year}-${mm}-${dd}T${String(hh).padStart(2, '0')}:${min}:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed.getTime();
};
const columnTextValue = (row, col, index, mode = 'filter') => {
  const getter = mode === 'sort' ? col.sortValue : col.filterValue;
  if (typeof getter === 'function') return textFromValue(getter(row, index));
  if (col.key) return textFromValue(row[col.key]);
  if (typeof col.render === 'function') return textFromValue(col.render(row, index));
  return '';
};
const compareColumnValues = (a, b) => {
  const ad = parseComparableDate(a);
  const bd = parseComparableDate(b);
  if (ad != null || bd != null) return (ad ?? Number.MAX_SAFE_INTEGER) - (bd ?? Number.MAX_SAFE_INTEGER);
  const an = Number(String(a).replace(/%$/, '').trim());
  const bn = Number(String(b).replace(/%$/, '').trim());
  if (Number.isFinite(an) && Number.isFinite(bn)) return an - bn;
  return String(a || '').localeCompare(String(b || ''), undefined, { numeric: true, sensitivity: 'base' });
};

//  Reusable UI Components //
const inputStyle = { width: '100%', padding: '8px 12px', border: '1.5px solid #d1d5db', borderRadius: 8, fontSize: 13, color: '#1e293b', outline: 'none', background: '#fff', boxSizing: 'border-box' };
const btnPrimary = { background: '#0d9488', color: '#fff', border: 'none', borderRadius: 8, padding: '9px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 };
const btnSecondary = { background: '#f1f5f9', color: '#475569', border: '1.5px solid #d1d5db', borderRadius: 8, padding: '8px 16px', fontSize: 13, fontWeight: 500, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 6 };
const btnDanger = { ...btnPrimary, background: '#ef4444' };
const shadcnPanel = { border: '1px solid #e5e7eb', borderRadius: 8, background: '#fff' };
const shadcnMutedPanel = { border: '1px solid #e5e7eb', borderRadius: 8, background: '#f8fafc' };
const shadcnLabel = { fontSize: 12, fontWeight: 600, color: '#334155', lineHeight: 1.2 };
const shadcnGhostButton = { ...btnSecondary, background: '#fff', border: '1px solid #e5e7eb', borderRadius: 6, color: '#334155', padding: '7px 10px', fontSize: 12 };
const messageTableMaxHeight = 296;
const messageTableColumns = [
  { key: 'srNo', label: 'Sr.No', width: 54 },
  { key: 'user', label: 'User', width: 150 },
  { key: 'time', label: 'Time', width: 120 },
  { key: 'message', label: 'Message', width: 220 },
  { key: 'attachments', label: 'Attachments', width: 150 },
  { key: 'actions', label: '', width: 44, locked: true },
];
const ColumnWidthContext = React.createContext({ widths: {}, rowHeights: {}, canResize: false, setColumnWidth: () => {}, setRowHeight: () => {} });

const StatusBadge = ({ status, labelOverride }) => {
  const c = STATUS_COLORS[status] || STATUS_COLORS['Not Started'];
  const label = labelOverride || (status === 'Pending Review' ? 'Under Review' : status);
  return (
    <span style={{ background: c.bg, color: c.text, padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 5, whiteSpace: 'nowrap' }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot, flexShrink: 0 }} />
      {label}
    </span>
  );
};

const PriorityBadge = ({ priority }) => {
  const colors = { Low: '#22c55e', Medium: '#f59e0b', High: '#ef4444', Critical: '#dc2626' };
  return <span style={{ color: colors[priority] || '#64748b', fontWeight: 600, fontSize: 12 }}>{priority}</span>;
};

const AssignmentDot = () => (
  <span
    title="New assignment"
    style={{ width: 8, height: 8, borderRadius: '50%', background: '#ef4444', display: 'inline-block', flexShrink: 0 }}
  />
);

const StatCard = ({ icon: Icon, label, value, color, onClick }) => (
  <div onClick={onClick}
    style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, padding: '16px 20px', flex: 1, minWidth: 160, cursor: onClick ? 'pointer' : 'default', transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: 14 }}
    onMouseEnter={e => { if (onClick) { e.currentTarget.style.borderColor = color; e.currentTarget.style.boxShadow = `0 2px 12px ${color}22`; }}}
    onMouseLeave={e => { e.currentTarget.style.borderColor = '#e2e8f0'; e.currentTarget.style.boxShadow = 'none'; }}>
    <div style={{ width: 42, height: 42, borderRadius: 10, background: `${color}15`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <Icon size={20} color={color} />
    </div>
    <div>
      <div style={{ fontSize: 22, fontWeight: 700, color: '#0f172a', lineHeight: 1.1 }}>{value}</div>
      <div style={{ fontSize: 12, color: '#64748b', fontWeight: 500 }}>{label}</div>
    </div>
  </div>
);

const DataTable = ({ columns, data, onRowClick, onRowDoubleClick, emptyMsg = 'No data', tableKey = '', enableHeaderTools = false }) => {
  const { widths, canResize, setColumnWidth } = React.useContext(ColumnWidthContext);
  const [sortConfig, setSortConfig] = useState(null);
  const tableWidths = widths?.[tableKey] || {};
  const columnId = (col, index) => col.id || col.key || String(col.label || index);
  const isLockedColumn = (col, index) => !!col.locked || (index === columns.length - 1 && (!col.label || col.label === 'Actions'));
  const isToolColumn = (col, index) => enableHeaderTools && !isLockedColumn(col, index) && !!col.label;
  const columnWidth = (col, index) => {
    const id = columnId(col, index);
    const explicitWidth = tableWidths[id] || col.style?.width;
    const parsedWidth = Number.parseInt(explicitWidth, 10);
    if (!Number.isFinite(parsedWidth)) return null;
    const minWidth = id === 'srNo' ? 42 : 36;
    return Math.max(minWidth, parsedWidth);
  };
  const tablePixelWidth = tableKey
    ? columns.reduce((sum, col, index) => sum + (columnWidth(col, index) || 140), 0)
    : null;
  const startResize = (event, col, index) => {
    if (!canResize || !tableKey || isLockedColumn(col, index)) return;
    event.preventDefault();
    event.stopPropagation();
    const id = columnId(col, index);
    const th = event.currentTarget.parentElement;
    const startX = event.clientX;
    const startWidth = th?.offsetWidth || Number.parseInt(tableWidths[id], 10) || 120;
    const onMove = (moveEvent) => {
      const nextWidth = Math.max(48, startWidth + moveEvent.clientX - startX);
      setColumnWidth(tableKey, id, nextWidth, { preview: true });
    };
    const onUp = (upEvent) => {
      const nextWidth = Math.max(48, startWidth + upEvent.clientX - startX);
      setColumnWidth(tableKey, id, nextWidth);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };
  const processedData = useMemo(() => {
    let rows = [...(data || [])];
    if (enableHeaderTools) {
      if (sortConfig?.id) {
        const sortIndex = columns.findIndex((col, index) => columnId(col, index) === sortConfig.id);
        const sortColumn = columns[sortIndex];
        if (sortColumn) {
          rows.sort((a, b) => {
            const result = compareColumnValues(
              columnTextValue(a, sortColumn, sortIndex, 'sort'),
              columnTextValue(b, sortColumn, sortIndex, 'sort')
            );
            return sortConfig.direction === 'desc' ? -result : result;
          });
        }
      }
    }
    return rows;
  }, [columns, data, enableHeaderTools, sortConfig]);
  const toggleSort = (col, index) => {
    if (!isToolColumn(col, index)) return;
    const id = columnId(col, index);
    setSortConfig(prev => (prev?.id === id ? { id, direction: prev.direction === 'asc' ? 'desc' : 'asc' } : { id, direction: 'asc' }));
  };
  return (
    <div style={{ border: '1px solid #e2e8f0', borderRadius: 10, overflow: 'hidden', width: '100%' }}>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: tablePixelWidth ? `max(100%, ${tablePixelWidth}px)` : '100%', borderCollapse: 'collapse', fontSize: 13, tableLayout: tableKey ? 'fixed' : 'auto' }}>
          {tableKey && (
            <colgroup>
              {columns.map((col, index) => (
                <col key={columnId(col, index)} style={{ width: columnWidth(col, index) || 140 }} />
              ))}
            </colgroup>
          )}
          <thead>
            <tr style={{ background: '#f1f5f9' }}>
              {columns.map((col, i) => {
                const id = columnId(col, i);
                const width = columnWidth(col, i) || col.style?.width;
                return (
                  <th key={id} onClick={() => toggleSort(col, i)} style={{ padding: '10px 14px', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0', whiteSpace: 'nowrap', position: 'relative', cursor: isToolColumn(col, i) ? 'pointer' : 'default', userSelect: 'none', ...(col.style || {}), textAlign: 'center', width, minWidth: width }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                      <span>{col.label}</span>
                      {isToolColumn(col, i) && sortConfig?.id === id && <span style={{ color: '#0d9488', fontSize: 10 }}>{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>}
                    </div>
                    {canResize && tableKey && !isLockedColumn(col, i) && (
                      <span onMouseDown={(e) => startResize(e, col, i)} title="Resize column" style={{ position: 'absolute', top: 0, right: -3, width: 8, height: '100%', cursor: 'col-resize', userSelect: 'none' }} />
                    )}
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody>
            {processedData.length === 0 ? (
              <tr><td colSpan={columns.length} style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>
                <Package size={32} style={{ marginBottom: 8, opacity: 0.4 }} /><br />{emptyMsg}
              </td></tr>
            ) : processedData.map((row, ri) => (
              <tr key={ri}
                onClick={() => onRowClick?.(row)}
                onDoubleClick={() => onRowDoubleClick?.(row)}
                style={{ cursor: onRowClick ? 'pointer' : 'default', borderBottom: '1px solid #f1f5f9', transition: 'background 0.15s' }}
                onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
                onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
                {columns.map((col, ci) => (
                  <td key={columnId(col, ci)} style={{ padding: '10px 14px', color: '#334155', whiteSpace: col.nowrap !== false ? 'nowrap' : 'normal', maxWidth: col.maxWidth || 'none', overflow: 'hidden', textOverflow: 'ellipsis', ...(col.cellStyle || {}) }}>
                    {col.render ? col.render(row) : row[col.key]}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

const ResizableHeaderCell = ({ tableKey, columnKey, children, style, locked = false }) => {
  const { widths, canResize, setColumnWidth } = React.useContext(ColumnWidthContext);
  const width = widths?.[tableKey]?.[columnKey] || style?.width;
  const startResize = (event) => {
    if (!canResize || !tableKey || !columnKey || locked) return;
    event.preventDefault();
    event.stopPropagation();
    const th = event.currentTarget.parentElement;
    const startX = event.clientX;
    const startWidth = th?.offsetWidth || Number.parseInt(width, 10) || 120;
    const onMove = (moveEvent) => setColumnWidth(tableKey, columnKey, Math.max(48, startWidth + moveEvent.clientX - startX), { preview: true });
    const onUp = (upEvent) => {
      setColumnWidth(tableKey, columnKey, Math.max(48, startWidth + upEvent.clientX - startX));
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onUp);
    };
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onUp);
  };
  return (
    <th style={{ ...style, position: 'relative', width, minWidth: width }}>
      {children}
      {canResize && tableKey && columnKey && !locked && (
        <span onMouseDown={startResize} title="Resize column" style={{ position: 'absolute', top: 0, right: -3, width: 8, height: '100%', cursor: 'col-resize', userSelect: 'none' }} />
      )}
    </th>
  );
};

const RowResizeHandle = ({ tableKey, rowKey }) => {
  const { rowHeights, canResize, setRowHeight } = React.useContext(ColumnWidthContext);
  const startResize = (e) => {
    if (!canResize || !tableKey || !rowKey) return;
    e.preventDefault();
    e.stopPropagation();
    const row = e.currentTarget.closest('tr');
    const startY = e.clientY;
    const startHeight = Number(rowHeights?.[tableKey]?.[rowKey]) || row?.getBoundingClientRect?.().height || 44;
    const move = (evt) => {
      const next = Math.max(34, startHeight + (evt.clientY - startY));
      setRowHeight(tableKey, rowKey, next, { preview: true });
    };
    const up = (evt) => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
      const next = Math.max(34, startHeight + (evt.clientY - startY));
      setRowHeight(tableKey, rowKey, next);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  };
  if (!canResize || !tableKey || !rowKey) return null;
  return (
    <span
      onMouseDown={startResize}
      title="Resize row"
      style={{ position: 'absolute', left: 0, right: 0, bottom: -3, height: 7, cursor: 'row-resize', userSelect: 'none', zIndex: 2 }}
    />
  );
};

const Modal = ({ open, onClose, title, width = 560, children }) => {
  if (!open) return null;
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(15,23,42,0.45)', backdropFilter: 'blur(4px)' }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#fff', borderRadius: 16, width: '90%', maxWidth: width, maxHeight: '90vh', display: 'flex', flexDirection: 'column', boxShadow: '0 20px 60px rgba(0,0,0,0.2)', animation: 'modalIn 0.2s ease-out' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 24px', borderBottom: '1px solid #e2e8f0' }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: '#0f172a' }}>{title}</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, borderRadius: 6, color: '#64748b' }}><X size={18} /></button>
        </div>
        <div style={{ padding: 24, overflow: 'auto', flex: 1 }}>{children}</div>
      </div>
    </div>
  );
};

const FormField = ({ label, children, required }) => (
  <div style={{ marginBottom: 14 }}>
    <label style={{ display: 'block', fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 5 }}>
      {label}{required && <span style={{ color: '#ef4444' }}> *</span>}
    </label>
    {children}
  </div>
);

const ConfirmDialog = ({ open, title, message, confirmLabel = 'Delete', onConfirm, onCancel }) => {
  if (!open) return null;
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(15,23,42,0.45)', backdropFilter: 'blur(4px)' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#fff', borderRadius: 16, width: '90%', maxWidth: 400, boxShadow: '0 20px 60px rgba(0,0,0,0.2)', animation: 'modalIn 0.2s ease-out', padding: '28px 28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 10, background: '#fee2e2', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <Trash2 size={18} color="#ef4444" />
          </div>
          <div>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 5 }}>{title}</h3>
            <p style={{ margin: 0, fontSize: 13, color: '#64748b', lineHeight: 1.55 }}>{message}</p>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
          <button onClick={onCancel} style={btnSecondary}>Cancel</button>
          <button onClick={onConfirm} style={btnDanger}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
};

const AlertDialog = ({ open, message, onClose }) => {
  if (!open) return null;
  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(15,23,42,0.45)', backdropFilter: 'blur(4px)' }}>
      <div onClick={e => e.stopPropagation()} style={{ background: '#fff', borderRadius: 16, width: '90%', maxWidth: 400, boxShadow: '0 20px 60px rgba(0,0,0,0.2)', animation: 'modalIn 0.2s ease-out', padding: '28px 28px 24px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14, marginBottom: 22 }}>
          <div style={{ width: 42, height: 42, borderRadius: 10, background: '#fef3c7', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <AlertCircle size={18} color="#d97706" />
          </div>
          <div>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: '#0f172a', marginBottom: 5 }}>Notice</h3>
            <p style={{ margin: 0, fontSize: 13, color: '#64748b', lineHeight: 1.55 }}>{message}</p>
          </div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={btnPrimary}>OK</button>
        </div>
      </div>
    </div>
  );
};

const StatusSelect = ({ value, onChange, onClick }) => {
  const [open, setOpen] = React.useState(false);
  const [dropPos, setDropPos] = React.useState({ top: 0, left: 0 });
  const btnRef = React.useRef(null);
  const menuRef = React.useRef(null);
  React.useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      const inBtn = !!btnRef.current?.contains(e.target);
      const inMenu = !!menuRef.current?.contains(e.target);
      if (!inBtn && !inMenu) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);
  const handleOpen = (e) => {
    e.stopPropagation();
    if (!open && btnRef.current) {
      const rect = btnRef.current.getBoundingClientRect();
      setDropPos({ top: rect.bottom + 4, left: rect.left });
    }
    setOpen(o => !o);
  };
  const c = STATUS_COLORS[value] || STATUS_COLORS['Not Started'];
  return (
    <div ref={btnRef} style={{ display: 'inline-block' }} onClick={onClick}>
      <button
        onClick={handleOpen}
        style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px 4px 8px', borderRadius: 20, border: `1.5px solid ${c.dot}33`, background: c.bg, color: c.text, fontSize: 11, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap', transition: 'box-shadow 0.15s' }}
      >
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: c.dot, flexShrink: 0 }} />
        {value === 'Pending Review' ? 'Under Review' : (value || 'Not Started')}
        <ChevronDown size={11} style={{ marginLeft: 2, opacity: 0.6 }} />
      </button>
      {open && ReactDOM.createPortal(
        <div
          ref={menuRef}
          onMouseDown={(e) => e.stopPropagation()}
          style={{ position: 'fixed', top: dropPos.top, left: dropPos.left, zIndex: 9999, background: '#fff', borderRadius: 10, boxShadow: '0 8px 24px rgba(15,23,42,0.14)', border: '1px solid #e2e8f0', minWidth: 180, padding: '4px 0', overflow: 'hidden' }}
        >
          {STATUS_OPTIONS.map(s => {
            const sc = STATUS_COLORS[s] || STATUS_COLORS['Not Started'];
            const isSelected = s === value;
            return (
              <button
                key={s}
                onClick={e => { e.stopPropagation(); onChange(s); setOpen(false); }}
                style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%', padding: '7px 12px', border: 'none', background: isSelected ? '#f1f5f9' : 'transparent', cursor: 'pointer', fontSize: 12, fontWeight: isSelected ? 600 : 500, color: sc.text, textAlign: 'left', transition: 'background 0.1s' }}
                onMouseEnter={e => { if (!isSelected) e.currentTarget.style.background = '#f8fafc'; }}
                onMouseLeave={e => { if (!isSelected) e.currentTarget.style.background = 'transparent'; }}
              >
                <span style={{ width: 8, height: 8, borderRadius: '50%', background: sc.dot, flexShrink: 0 }} />
                <span style={{ background: sc.bg, color: sc.text, padding: '2px 8px', borderRadius: 20, fontSize: 11, fontWeight: 600 }}>{s === 'Pending Review' ? 'Under Review' : s}</span>
              </button>
            );
          })}
        </div>,
        document.body
      )}
    </div>
  );
};

const timeLeft = (dueDateStr) => {
  if (!dueDateStr) return '-';
  try {
    const d = parseAppDateTime(dueDateStr);
    if (!d) return '-';
    const diff = d - now;
    if (diff < 0) return 'Overdue';
    const days = Math.floor(diff / 86400000);
    if (days > 0) return `${days}d`;
    return `${Math.floor(diff / 3600000)}h`;
  } catch { return '-'; }
};

const parseAppDateTime = (value) => {
  if (!value) return null;
  const raw = String(value).trim();
  let match = raw.match(/^(\d{1,2})-(\d{1,2})-(\d{2}|\d{4})(?:[ T](\d{1,2}):(\d{2}))?$/);
  let year; let month; let day; let hour = 9; let minute = 0;
  if (match) {
    day = parseInt(match[1], 10);
    month = parseInt(match[2], 10);
    year = parseInt(match[3], 10);
    if (year < 100) year += 2000;
    hour = match[4] ? parseInt(match[4], 10) : 9;
    minute = match[5] ? parseInt(match[5], 10) : 0;
  } else {
    match = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2}))?/);
    if (!match) return null;
    year = parseInt(match[1], 10);
    month = parseInt(match[2], 10);
    day = parseInt(match[3], 10);
    hour = match[4] ? parseInt(match[4], 10) : 9;
    minute = match[5] ? parseInt(match[5], 10) : 0;
  }
  const dt = new Date(
    year,
    month - 1,
    day,
    hour,
    minute,
    0,
    0
  );
  return Number.isNaN(dt.getTime()) ? null : dt;
};

const parseFilePathsFromText = (raw) => {
  if (!raw) return [];
  return String(raw)
    .split(/\r?\n|;/)
    .map(s => s.trim())
    .map(s => s.replace(/^"(.*)"$/, '$1'))
    .filter(Boolean);
};

const unreadMapsEqual = (a, b) => {
  const aKeys = Object.keys(a || {});
  const bKeys = Object.keys(b || {});
  if (aKeys.length !== bKeys.length) return false;
  for (const k of aKeys) {
    if ((a?.[k] || 0) !== (b?.[k] || 0)) return false;
  }
  return true;
};

const assignmentSeenStorageKey = (user) => `assignmentSeen:${String(user || '').trim().toLowerCase()}`;
const assignmentTabSeenStorageKey = (user) => `assignmentTabSeen:${String(user || '').trim().toLowerCase()}`;
const assignmentBellSeenStorageKey = (user) => `assignmentBellSeen:${String(user || '').trim().toLowerCase()}`;
const emptyAssignmentSeen = () => ({ tasks: {}, issues: {}, projects: {} });
const emptyAssignmentTabSeen = () => ({ tasks: {}, issues: {}, projects: {} });
const readAssignmentSeen = (user) => {
  if (typeof window === 'undefined') return emptyAssignmentSeen();
  try {
    const parsed = JSON.parse(window.localStorage.getItem(assignmentSeenStorageKey(user)) || '{}');
    return {
      tasks: parsed?.tasks && typeof parsed.tasks === 'object' ? parsed.tasks : {},
      issues: parsed?.issues && typeof parsed.issues === 'object' ? parsed.issues : {},
      projects: parsed?.projects && typeof parsed.projects === 'object' ? parsed.projects : {},
    };
  } catch {
    return emptyAssignmentSeen();
  }
};
const writeAssignmentSeen = (user, value) => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(assignmentSeenStorageKey(user), JSON.stringify(value || emptyAssignmentSeen()));
  } catch {}
};
const readAssignmentTabSeen = (user) => {
  if (typeof window === 'undefined') return emptyAssignmentTabSeen();
  try {
    const parsed = JSON.parse(window.localStorage.getItem(assignmentTabSeenStorageKey(user)) || '{}');
    return {
      tasks: parsed?.tasks && typeof parsed.tasks === 'object' ? parsed.tasks : {},
      issues: parsed?.issues && typeof parsed.issues === 'object' ? parsed.issues : {},
      projects: parsed?.projects && typeof parsed.projects === 'object' ? parsed.projects : {},
    };
  } catch {
    return emptyAssignmentTabSeen();
  }
};
const writeAssignmentTabSeen = (user, value) => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(assignmentTabSeenStorageKey(user), JSON.stringify(value || emptyAssignmentTabSeen()));
  } catch {}
};
const readAssignmentBellSeen = (user) => {
  if (typeof window === 'undefined') return emptyAssignmentTabSeen();
  try {
    const parsed = JSON.parse(window.localStorage.getItem(assignmentBellSeenStorageKey(user)) || '{}');
    return {
      tasks: parsed?.tasks && typeof parsed.tasks === 'object' ? parsed.tasks : {},
      issues: parsed?.issues && typeof parsed.issues === 'object' ? parsed.issues : {},
      projects: parsed?.projects && typeof parsed.projects === 'object' ? parsed.projects : {},
    };
  } catch {
    return emptyAssignmentTabSeen();
  }
};
const writeAssignmentBellSeen = (user, value) => {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(assignmentBellSeenStorageKey(user), JSON.stringify(value || emptyAssignmentTabSeen()));
  } catch {}
};

const mergeUniqueFilePaths = (existing, incoming) => {
  const out = [...(existing || [])];
  for (const fp of (incoming || [])) {
    if (!fp) continue;
    if (!out.includes(fp)) out.push(fp);
  }
  return out;
};

const mapEmployeeRows = (rows) => {
  if (!Array.isArray(rows)) return [];
  const out = [];
  const seen = new Set();
  for (const r of rows) {
    if (!r || typeof r !== 'object') continue;
    const name = String(r.name ?? r.Name ?? r.NAME ?? '').trim();
    if (!name) continue;
    if (seen.has(name)) continue;
    seen.add(name);
    const role = displayRole(String(r.role ?? r.designation ?? r.Role ?? BASE_ROLE).trim() || BASE_ROLE);
    const team = String(r.team ?? r.team_name ?? r.Team ?? '').trim();
    out.push({ name, role, team });
  }
  return out;
};

const fileToBase64Data = (file) => new Promise((resolve, reject) => {
  const reader = new FileReader();
  reader.onload = () => {
    const dataUrl = String(reader.result || '');
    const comma = dataUrl.indexOf(',');
    resolve(comma >= 0 ? dataUrl.slice(comma + 1) : '');
  };
  reader.onerror = reject;
  reader.readAsDataURL(file);
});

const getPastedAttachmentPaths = async (event) => {
  const files = Array.from(event?.clipboardData?.files || []);
  const filePaths = files.map(f => f.path).filter(Boolean);
  const stagedPaths = [];
  const blobFiles = files.filter(f => !f.path);

  if (isElectron && blobFiles.length && window.electronAPI?.attachments?.stageClipboard) {
    const payload = [];
    for (const file of blobFiles) {
      try {
        const dataBase64 = await fileToBase64Data(file);
        if (!dataBase64) continue;
        payload.push({
          name: file.name || `clipboard-${Date.now()}`,
          type: file.type || '',
          dataBase64,
        });
      } catch {}
    }
    if (payload.length) {
      const res = await window.electronAPI.attachments.stageClipboard({ files: payload });
      if (res?.ok && Array.isArray(res.filePaths)) stagedPaths.push(...res.filePaths);
    }
  }

  const textPaths = parseFilePathsFromText(event?.clipboardData?.getData('text') || '');
  return mergeUniqueFilePaths(mergeUniqueFilePaths(filePaths, stagedPaths), textPaths);
};

// Main App 
function AppShell({ mode = 'client' }) {
  const isRemoteApp = mode === 'remote';
  const [currentUser, setCurrentUser] = useState(null);
  const [employees, setEmployees] = useState([]);
  const [teams, setTeams] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [issues, setIssues] = useState([]);
  const [sops, setSops] = useState([]);
  const [subtasks, setSubtasks] = useState([]);
  const [recurring, setRecurring] = useState([]);
  const [activePage, setActivePage] = useState('home');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [modalState, setModalState] = useState({ open: false, type: null, data: null });
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProjectId, setSelectedProjectId] = useState('');
  const [taskTemplates, setTaskTemplates] = useState([]);
  const [projectTemplates, setProjectTemplates] = useState([]);
  const [projectTags, setProjectTags] = useState([]);
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [syncQueueOpen, setSyncQueueOpen] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [syncQueueItems, setSyncQueueItems] = useState([]);
  const [taskCommentUnread, setTaskCommentUnread] = useState({});
  const [assignmentSeen, setAssignmentSeen] = useState(emptyAssignmentSeen);
  const [assignmentTabSeen, setAssignmentTabSeen] = useState(emptyAssignmentTabSeen);
  const [assignmentBellSeen, setAssignmentBellSeen] = useState(emptyAssignmentTabSeen);
  const [confirmDeleteTask, setConfirmDeleteTask] = useState(null);
  const [extendTaskTarget, setExtendTaskTarget] = useState(null);
  const [savedLogin, setSavedLogin] = useState(null);
  const [autoLoginTried, setAutoLoginTried] = useState(false);
  const [alertMsg, setAlertMsg] = useState(null);
  const [syncConnection, setSyncConnection] = useState({ enabled: false, online: true, serverUrl: '', pendingCount: 0, lastError: '', lastSyncedAt: '' });
  const [tableColumnWidths, setTableColumnWidths] = useState({});
  const [tableRowHeights, setTableRowHeights] = useState({});
  const tableColumnWidthsRef = useRef({});
  const tableRowHeightsRef = useRef({});
  const tasksRef = useRef(tasks);

  useEffect(() => {
    tasksRef.current = tasks;
  }, [tasks]);

  useEffect(() => {
    tableColumnWidthsRef.current = tableColumnWidths || {};
  }, [tableColumnWidths]);

  useEffect(() => {
    tableRowHeightsRef.current = tableRowHeights || {};
  }, [tableRowHeights]);

  useEffect(() => {
    setAssignmentSeen(currentUser ? readAssignmentSeen(currentUser) : emptyAssignmentSeen());
    setAssignmentTabSeen(currentUser ? readAssignmentTabSeen(currentUser) : emptyAssignmentTabSeen());
    setAssignmentBellSeen(currentUser ? readAssignmentBellSeen(currentUser) : emptyAssignmentTabSeen());
  }, [currentUser]);

  useEffect(() => {
    if (!isElectron || !window.electronAPI?.auth?.getRememberedLogin) return;
    let cancelled = false;
    window.electronAPI.auth.getRememberedLogin().then((res) => {
      if (cancelled) return;
      if (res?.ok && res?.data?.remember) {
        setSavedLogin({
          name: String(res.data.name || ''),
          password: String(res.data.password || ''),
          remember: true,
        });
      }
    }).catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Load data from Electron SQLite on mount
  useEffect(() => {
    if (!isElectron || !currentUser) return;
    let cancelled = false;
    window.electronAPI?.config?.getAppSettings?.().then((settings) => {
      if (cancelled) return;
      const directDbDir = String(settings?.directDbDir || '').trim();
      const driveScriptUrl = String(settings?.driveScriptUrl || '').trim();
      const serverUrl = String(directDbDir || driveScriptUrl || settings?.serverUrl || '').trim();
      const mode = directDbDir ? 'direct' : driveScriptUrl ? 'drive' : 'lan';
      const enabled = directDbDir
        ? settings?.directSyncEnabled !== false
        : driveScriptUrl
          ? settings?.driveSyncEnabled !== false
          : !!serverUrl;
      if (settings?.tableColumnWidths && typeof settings.tableColumnWidths === 'object') {
        setTableColumnWidths(settings.tableColumnWidths);
      }
      if (settings?.tableRowHeights && typeof settings.tableRowHeights === 'object') {
        setTableRowHeights(settings.tableRowHeights);
      }
      setSyncConnection(prev => ({
        ...prev,
        enabled,
        serverUrl,
        mode,
        online: enabled ? (mode === 'lan' ? (settings?.serverTokenConfigured ? prev.online : false) : prev.online) : true,
        lastError: enabled ? (mode === 'lan' ? (settings?.serverTokenConfigured ? prev.lastError : 'Server token not configured.') : prev.lastError) : '',
      }));
    }).catch(() => {});
    return () => { cancelled = true; };
  }, [currentUser]);

  useEffect(() => {
    if (!isElectron || !currentUser || !syncConnection.enabled || syncConnection.mode === 'direct' || syncConnection.mode === 'drive' || !syncConnection.serverUrl || !window.electronAPI?.config?.checkServerHealth) return undefined;
    let cancelled = false;
    const check = async () => {
      const res = await window.electronAPI.config.checkServerHealth({ serverUrl: syncConnection.serverUrl });
      if (cancelled) return;
      setSyncConnection(prev => ({
        ...prev,
        online: !!res?.ok,
        lastError: res?.ok ? '' : 'Server not connected',
      }));
    };
    check();
    const timer = setInterval(check, 10000);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, [currentUser, syncConnection.enabled, syncConnection.serverUrl]);

  useEffect(() => {
    if (!isElectron || !currentUser) return;
    const role = employees.find(e => e.name === currentUser)?.role;
    const isAdmin = isAdminLikeRole(role);
    const isAdminAuthorityLocal = isAdminRole(role);

    Promise.all([
      window.electronAPI.tasks.list({ user: currentUser, isAdmin }),
      window.electronAPI.projects.list({ user: currentUser, isAdmin }),
      window.electronAPI.issues.list(),
      window.electronAPI.recurring.list(),
      window.electronAPI.sops?.list ? window.electronAPI.sops.list({ user: currentUser, isAdmin: isAdminAuthorityLocal }) : Promise.resolve([]),
    ]).then(([t, p, i, r, s]) => {
      if (t) setTasks(t.map(mapTaskRow));
      if (p) setProjects(p.map(mapProjectRow));
      if (i) setIssues(i.map(mapIssueRow));
      if (r) setRecurring(r.map(mapRecurringRow));
      if (s) setSops(s.map(mapSopRow));
    }).catch(console.error);
  }, [currentUser, employees]);

  useEffect(() => {
    setCreateMenuOpen(false);
  }, [activePage]);

  // Load employees on mount
  useEffect(() => {
    if (!isElectron) return;
    window.electronAPI.employees.list().then(rows => {
      const parsed = mapEmployeeRows(rows);
      setEmployees(parsed);
    }).catch(err => {
      console.error(err);
      setEmployees([]);
    });
    window.electronAPI.teams.list().then(rows => {
      if (rows) setTeams(rows.map(r => (r.team_name || '').trim()).filter(Boolean));
    }).catch((err) => {
      console.error('Unable to load teams:', err);
    });
  }, []);

  // Listen for CSV export from menu
  useEffect(() => {
    if (!isElectron) return;
    const unsubscribe = window.electronAPI.onExportCsv(() => {
      const rows = tasksRef.current || [];
      const header = 'ID,Task,Assigned To,Status,Due Date\n';
      const body = rows.map(t => `${t.id},${t.name},${t.assignedTo},${t.status},${t.dueDate}`).join('\n');
      window.electronAPI.saveCsv(header + body);
    });
    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  const userRole = useMemo(() => employees.find(e => e.name === currentUser)?.role || BASE_ROLE, [currentUser, employees]);
  const isAdmin = isAdminLikeRole(userRole);
  const isAdminAuthority = isAdminRole(userRole);
  const isSuperAdmin = isSuperadminRole(userRole) || String(currentUser || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase();
  const currentUserTeam = useMemo(
    () => String(employees.find(e => String(e.name || '').toLowerCase() === String(currentUser || '').toLowerCase())?.team || '').trim(),
    [employees, currentUser]
  );
  const currentUserTeamNames = useMemo(() => {
    const team = currentUserTeam.toLowerCase();
    if (!team) return new Set();
    return new Set(
      employees
        .filter(e => String(e.team || '').trim().toLowerCase() === team)
        .map(e => String(e.name || '').trim().toLowerCase())
        .filter(Boolean)
    );
  }, [employees, currentUserTeam]);
  const updateColumnWidth = useCallback((tableKey, columnKey, width, options = {}) => {
    if (!tableKey || !columnKey || !isSuperAdmin) return;
    const cleanWidth = Math.max(48, Math.round(Number(width) || 48));
    const prevWidths = tableColumnWidthsRef.current || {};
    const nextWidths = {
      ...prevWidths,
      [tableKey]: {
        ...(prevWidths[tableKey] || {}),
        [columnKey]: cleanWidth,
      },
    };
    tableColumnWidthsRef.current = nextWidths;
    setTableColumnWidths(prev => {
      const current = prev || {};
      return {
        ...current,
        [tableKey]: {
          ...(current[tableKey] || {}),
          [columnKey]: cleanWidth,
        },
      };
    });
    if (!options.preview && isElectron && window.electronAPI?.config?.setAppSettings) {
      window.electronAPI.config.setAppSettings({ tableColumnWidths: nextWidths, actor: currentUser }).catch(() => {});
    }
  }, [isSuperAdmin, currentUser]);
  const updateRowHeight = useCallback((tableKey, rowKey, height, options = {}) => {
    if (!tableKey || !rowKey || !isSuperAdmin) return;
    const cleanHeight = Math.max(34, Math.round(Number(height) || 34));
    const prevHeights = tableRowHeightsRef.current || {};
    const nextHeights = {
      ...prevHeights,
      [tableKey]: {
        ...(prevHeights[tableKey] || {}),
        [rowKey]: cleanHeight,
      },
    };
    tableRowHeightsRef.current = nextHeights;
    setTableRowHeights(prev => {
      const current = prev || {};
      return {
        ...current,
        [tableKey]: {
          ...(current[tableKey] || {}),
          [rowKey]: cleanHeight,
        },
      };
    });
    if (!options.preview && isElectron && window.electronAPI?.config?.setAppSettings) {
      window.electronAPI.config.setAppSettings({ tableRowHeights: nextHeights, actor: currentUser }).catch(() => {});
    }
  }, [isSuperAdmin, currentUser]);
  const syncColumnWidthsNow = useCallback(async () => {
    if (!isSuperAdmin || !isElectron || !window.electronAPI?.config?.setAppSettings) return;
    await window.electronAPI.config.setAppSettings({ tableColumnWidths: tableColumnWidthsRef.current || {}, tableRowHeights: tableRowHeightsRef.current || {}, actor: currentUser });
  }, [isSuperAdmin, currentUser]);
  const unreadNotificationCount = useMemo(() => notifications.filter(n => !n?.isRead).length, [notifications]);
  const unseenAssignmentIds = useMemo(() => {
    const out = { tasks: new Set(), issues: new Set(), projects: new Set() };
    const userName = String(currentUser || '').trim().toLowerCase();
    if (!userName) return out;
    const currentTasks = new Map((tasks || []).map(t => [String(t.id || ''), t]).filter(([id]) => !!id));
    const currentIssues = new Map((issues || []).map(i => [String(i.id || ''), i]).filter(([id]) => !!id));
    const currentProjects = new Map((projects || []).map(p => [String(p.id || ''), p]).filter(([id]) => !!id));
    for (const [id, task] of currentTasks) {
      const assignedToUser = String(task.assignedTo || '').trim().toLowerCase() === userName;
      const assignedByUser = String(task.assignedBy || '').trim().toLowerCase() === userName;
      if (((assignedToUser && !assignedByUser) || (assignedByUser && !assignedToUser)) && !assignmentSeen?.tasks?.[id]) out.tasks.add(id);
      if (assignedToUser && task.reviewRejectedUnseen) out.tasks.add(id);
    }
    for (const [id, issue] of currentIssues) {
      const assignedToUser = String(issue.assignedTo || '').trim().toLowerCase() === userName;
      const reportedByUser = String(issue.reportedBy || '').trim().toLowerCase() === userName;
      if (assignedToUser && !reportedByUser && !assignmentSeen?.issues?.[id]) out.issues.add(id);
    }
    for (const [id, project] of currentProjects) {
      const assignedToUser = (
        includesMultiValue(project.owner, userName) ||
        splitMultiValue(project.team).some(team => employees.some(e => String(e.name || '').trim().toLowerCase() === userName && String(e.team || '').trim().toLowerCase() === team.toLowerCase()))
      );
      const createdByUser = String(project.createdBy || '').trim().toLowerCase() === userName;
      if (((assignedToUser && !createdByUser) || (createdByUser && !assignedToUser)) && !assignmentSeen?.projects?.[id]) out.projects.add(id);
    }
    for (const n of (notifications || [])) {
      const actorIsUser = String(n?.actor || '').trim().toLowerCase() === userName;
      const recipients = Array.isArray(n?.recipients) ? n.recipients.map(v => String(v || '').trim().toLowerCase()) : [];
      if (!recipients.includes(userName)) continue;
      const eventType = String(n?.eventType || '');
      const itemType = String(n?.itemType || '');
      const type = itemType === 'task' || eventType === 'task_add'
        ? 'tasks'
        : itemType === 'issue' || eventType === 'issue_add' || eventType === 'issue_update' || eventType === 'issue_comment'
          ? 'issues'
          : itemType === 'project' || eventType === 'project_add'
            ? 'projects'
            : '';
      if (!type) continue;
      const id = String(n?.itemId || (type === 'tasks' ? n?.taskId : type === 'projects' ? n?.projectId : '') || '').trim();
      const item = type === 'tasks' ? currentTasks.get(id) : type === 'issues' ? currentIssues.get(id) : currentProjects.get(id);
      if (!item) continue;
      const assignedToUser = type === 'tasks'
        ? String(item.assignedTo || '').trim().toLowerCase() === userName
        : type === 'issues'
          ? String(item.assignedTo || '').trim().toLowerCase() === userName
          : (
              includesMultiValue(item.owner, userName) ||
              splitMultiValue(item.team).some(team => employees.some(e => String(e.name || '').trim().toLowerCase() === userName && String(e.team || '').trim().toLowerCase() === team.toLowerCase()))
            );
      const assignedByUser = type === 'tasks' && String(item.assignedBy || '').trim().toLowerCase() === userName;
      const createdByUser = type === 'projects' && String(item.createdBy || '').trim().toLowerCase() === userName;
      const isRelevantToUser = assignedToUser || assignedByUser || createdByUser || (actorIsUser && (eventType === 'task_add' || eventType === 'project_add'));
      if (!isRelevantToUser) continue;
      if (!id) continue;
      if (type === 'issues' && (eventType === 'issue_update' || eventType === 'issue_comment')) {
        if (!n?.isRead) out.issues.add(id);
        continue;
      }
      if (assignmentSeen?.[type]?.[id]) continue;
      out[type].add(id);
    }
    return out;
  }, [notifications, currentUser, assignmentSeen, tasks, issues, projects, employees]);
  const rejectedReviewTaskIds = useMemo(() => new Set((tasks || [])
    .filter(t => String(t.assignedTo || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase() && t.reviewRejectedUnseen)
    .map(t => String(t.id || ''))
    .filter(Boolean)), [tasks, currentUser]);
  const unseenAssignmentCounts = useMemo(() => ({
    tasks: [...unseenAssignmentIds.tasks].filter(id => rejectedReviewTaskIds.has(String(id)) || !assignmentTabSeen?.tasks?.[id]).length,
    issues: [...unseenAssignmentIds.issues].filter(id => !assignmentTabSeen?.issues?.[id]).length,
    projects: [...unseenAssignmentIds.projects].filter(id => !assignmentTabSeen?.projects?.[id]).length,
  }), [unseenAssignmentIds, assignmentTabSeen, rejectedReviewTaskIds]);
  const assignmentBellCount = useMemo(() => (
    [...unseenAssignmentIds.tasks].filter(id => !assignmentBellSeen?.tasks?.[id]).length +
    [...unseenAssignmentIds.issues].filter(id => !assignmentBellSeen?.issues?.[id]).length +
    [...unseenAssignmentIds.projects].filter(id => !assignmentBellSeen?.projects?.[id]).length
  ), [unseenAssignmentIds, assignmentBellSeen]);
  const assignmentNotifications = useMemo(() => {
    const rows = [];
    for (const id of unseenAssignmentIds.tasks) {
      const task = tasks.find(t => String(t.id || '') === String(id));
      if (!task) continue;
      rows.push({
        id: `assignment-task-${id}`,
        actor: task.assignedBy || 'Task',
        title: `New task assigned: ${task.name || id}`,
        message: `Assigned by ${task.assignedBy || '-'}. Due: ${task.dueDate || '-'}.`,
        ts: task.dateAssigned || '',
        isRead: !!assignmentBellSeen?.tasks?.[id],
      });
    }
    for (const id of unseenAssignmentIds.issues) {
      const issue = issues.find(i => String(i.id || '') === String(id));
      if (!issue) continue;
      rows.push({
        id: `assignment-issue-${id}`,
        actor: issue.reportedBy || 'Issue',
        title: `New issue assigned: ${issue.title || id}`,
        message: `Reported by ${issue.reportedBy || '-'}. Priority: ${issue.priority || '-'}.`,
        ts: issue.dateReported || '',
        isRead: !!assignmentBellSeen?.issues?.[id],
      });
    }
    for (const id of unseenAssignmentIds.projects) {
      const project = projects.find(p => String(p.id || '') === String(id));
      if (!project) continue;
      rows.push({
        id: `assignment-project-${id}`,
        actor: project.createdBy || 'Project',
        title: `New project assigned: ${project.name || id}`,
        message: [
          project.team ? `Teams: ${project.team}` : '',
          project.owner ? `Users: ${project.owner}` : '',
        ].filter(Boolean).join(' | ') || 'Unassigned.',
        ts: project.createdOn || '',
        isRead: !!assignmentBellSeen?.projects?.[id],
      });
    }
    return rows;
  }, [unseenAssignmentIds, assignmentBellSeen, tasks, issues, projects]);
  const notificationBadgeCount = unreadNotificationCount + assignmentBellCount;
  const markAssignmentSeen = useCallback((type, id) => {
    const key = String(type || '');
    const itemId = String(id || '').trim();
    if (!currentUser || !['tasks', 'issues', 'projects'].includes(key) || !itemId) return;
    setAssignmentSeen(prev => {
      if (prev?.[key]?.[itemId]) return prev;
      const next = {
        tasks: { ...(prev?.tasks || {}) },
        issues: { ...(prev?.issues || {}) },
        projects: { ...(prev?.projects || {}) },
      };
      next[key][itemId] = Date.now();
      writeAssignmentSeen(currentUser, next);
      return next;
    });
  }, [currentUser]);
  const markAssignmentTabSeen = useCallback((type) => {
    const key = String(type || '');
    if (!currentUser || !['tasks', 'issues', 'projects'].includes(key)) return;
    const ids = [...(unseenAssignmentIds?.[key] || [])];
    if (!ids.length) return;
    setAssignmentTabSeen(prev => {
      const next = {
        tasks: { ...(prev?.tasks || {}) },
        issues: { ...(prev?.issues || {}) },
        projects: { ...(prev?.projects || {}) },
      };
      let changed = false;
      for (const id of ids) {
        if (next[key][id]) continue;
        next[key][id] = Date.now();
        changed = true;
      }
      if (!changed) return prev;
      writeAssignmentTabSeen(currentUser, next);
      return next;
    });
  }, [currentUser, unseenAssignmentIds]);
  const markAssignmentBellSeen = useCallback(() => {
    if (!currentUser) return;
    setAssignmentBellSeen(prev => {
      const next = {
        tasks: { ...(prev?.tasks || {}) },
        issues: { ...(prev?.issues || {}) },
        projects: { ...(prev?.projects || {}) },
      };
      let changed = false;
      for (const key of ['tasks', 'issues', 'projects']) {
        for (const id of [...(unseenAssignmentIds?.[key] || [])]) {
          if (next[key][id]) continue;
          next[key][id] = Date.now();
          changed = true;
        }
      }
      if (!changed) return prev;
      writeAssignmentBellSeen(currentUser, next);
      return next;
    });
  }, [currentUser, unseenAssignmentIds]);
  const resolveProjectRecipients = useCallback((projectId) => {
    const p = projects.find(pr => pr.id === projectId);
    if (!p) return [];
    const out = [];
    out.push(...splitMultiValue(p.owner));
    const projectTeams = splitMultiValue(p.team).map(t => t.toLowerCase());
    if (projectTeams.length) out.push(...employees.filter(e => projectTeams.includes(String(e.team || '').trim().toLowerCase())).map(e => e.name));
    return [...new Set(out.filter(Boolean))];
  }, [projects, employees]);
  const resolveTaskRecipients = useCallback((taskLike) => {
    if (!taskLike) return [];
    return [...new Set([
      taskLike.assignedTo,
      taskLike.assignedBy,
      ...resolveProjectRecipients(taskLike.projectId),
    ].filter(Boolean))];
  }, [resolveProjectRecipients]);

  const fetchNotifications = useCallback((opts = {}) => {
    if (!isElectron || !currentUser) return;
    if (!window.electronAPI?.notifications?.list) return;
    window.electronAPI.notifications.list({ user: currentUser, isAdmin: isAdminAuthority, includeArchived: !!opts.includeArchived }).then(rows => {
      if (rows) setNotifications(rows);
    }).catch(console.error);
  }, [currentUser, isAdminAuthority]);
  const applyQueueStatus = useCallback((status) => {
    if (!status) return;
    setSyncConnection(prev => ({
      ...prev,
      pendingCount: Number(status.pendingCount || 0),
      ...(status.direct ? { mode: 'direct' } : {}),
      ...(status.drive ? { mode: 'drive', online: true, lastError: '' } : {}),
    }));
    if (Array.isArray(status.items)) setSyncQueueItems(status.items);
  }, []);
  const refreshQueueStatus = useCallback(async () => {
    if (!isElectron || !window.electronAPI?.sync?.queueStatus) return;
    try {
      const status = await window.electronAPI.sync.queueStatus();
      applyQueueStatus(status);
    } catch {}
  }, [applyQueueStatus]);
  const refreshWorkspaceData = useCallback(async (opts = {}) => {
    if (!isElectron || !currentUser) return;
    const role = employees.find(e => e.name === currentUser)?.role;
    const canSeeAdminRows = isAdminLikeRole(role);
    const isAdminAuthorityLocal = isAdminRole(role);
    try {
      if (opts.pullFirst && window.electronAPI?.sync?.pull) {
        const pullResult = await window.electronAPI.sync.pull();
        setSyncConnection(prev => (
          prev.enabled && !pullResult?.skipped
            ? {
                ...prev,
                online: pullResult?.ok ? true : false,
                pendingCount: Number(pullResult?.pendingCount || 0),
                mode: pullResult?.direct ? 'direct' : pullResult?.drive ? 'drive' : prev.mode,
                lastError: pullResult?.ok ? '' : (pullResult?.error || prev.lastError),
                lastSyncedAt: pullResult?.ok ? new Date().toISOString() : prev.lastSyncedAt,
              }
            : prev
        ));
      }
      if (window.electronAPI?.config?.getAppSettings) {
        const settings = await window.electronAPI.config.getAppSettings();
        if (settings?.tableColumnWidths && typeof settings.tableColumnWidths === 'object') {
          setTableColumnWidths(settings.tableColumnWidths);
        }
        if (settings?.tableRowHeights && typeof settings.tableRowHeights === 'object') {
          setTableRowHeights(settings.tableRowHeights);
        }
      }
      const [t, p, i, r, s] = await Promise.all([
        window.electronAPI.tasks.list({ user: currentUser, isAdmin: canSeeAdminRows }),
        window.electronAPI.projects.list({ user: currentUser, isAdmin: canSeeAdminRows }),
        window.electronAPI.issues.list(),
        window.electronAPI.recurring.list(),
        window.electronAPI.sops?.list ? window.electronAPI.sops.list({ user: currentUser, isAdmin: isAdminAuthorityLocal }) : Promise.resolve([]),
      ]);
      if (t) setTasks(t.map(mapTaskRow));
      if (p) setProjects(p.map(mapProjectRow));
      if (i) setIssues(i.map(mapIssueRow));
      if (r) setRecurring(r.map(mapRecurringRow));
      if (s) setSops(s.map(mapSopRow));
    } catch (error) {
      console.error(error);
    }
  }, [currentUser, employees]);
  const handleServerSettingsChanged = useCallback((settings, initialPull, connection) => {
    const directDbDir = String(settings?.directDbDir || '').trim();
    const driveScriptUrl = String(settings?.driveScriptUrl || '').trim();
    const serverUrl = String(directDbDir || driveScriptUrl || settings?.serverUrl || '').trim();
    const mode = connection?.mode || (directDbDir ? 'direct' : driveScriptUrl ? 'drive' : 'lan');
    const enabled = directDbDir
      ? settings?.directSyncEnabled !== false
      : driveScriptUrl
        ? settings?.driveSyncEnabled !== false
        : !!serverUrl;
    const online = connection && Object.prototype.hasOwnProperty.call(connection, 'online')
      ? !!connection.online
      : (enabled ? !!initialPull?.ok : true);
    setSyncConnection(prev => ({
      ...prev,
      enabled,
      serverUrl: String(connection?.serverUrl || serverUrl || '').trim(),
      mode,
      online,
      pendingCount: Number(connection?.pendingCount ?? initialPull?.pendingCount ?? 0),
      lastError: enabled && !online
        ? (connection?.lastError || initialPull?.error || (mode === 'direct' ? 'DB not connected' : mode === 'drive' ? 'Drive not connected' : 'Server not connected'))
        : '',
      lastSyncedAt: initialPull?.ok && !initialPull?.skipped ? new Date().toISOString() : prev.lastSyncedAt,
    }));
    if (initialPull?.ok && !initialPull?.skipped) {
      refreshWorkspaceData({ pullFirst: false });
    }
  }, [refreshWorkspaceData]);
  const openNotifications = useCallback(async () => {
    setNotificationsOpen(true);
    setSyncQueueOpen(false);
    markAssignmentBellSeen();
    if (isElectron && window.electronAPI?.notifications?.markAllRead) {
      await window.electronAPI.notifications.markAllRead({ user: currentUser, isAdmin: isAdminAuthority, includeArchived: false });
      fetchNotifications();
    }
  }, [currentUser, isAdminAuthority, fetchNotifications, markAssignmentBellSeen]);

  const syncNow = useCallback(async () => {
    if (!isElectron || !window.electronAPI?.sync?.pull) return;
    const result = await window.electronAPI.sync.pull();
    if (result?.ok) {
      await refreshWorkspaceData({ pullFirst: false });
      await refreshQueueStatus();
    }
  }, [refreshWorkspaceData, refreshQueueStatus]);
  const fetchTaskCommentUnread = useCallback(async () => {
    if (!isElectron || !currentUser || !window.electronAPI?.taskComments?.unreadCounts) return;
    const rows = await window.electronAPI.taskComments.unreadCounts({ actor: currentUser, isAdmin: isAdminAuthority });
    const map = {};
    for (const r of (rows || [])) {
      const id = String(r.taskId || '');
      const cnt = Number(r.unreadCount) || 0;
      if (id && cnt > 0) map[id] = cnt;
    }
    setTaskCommentUnread(prev => unreadMapsEqual(prev, map) ? prev : map);
  }, [currentUser, isAdminAuthority]);
  const markTaskCommentsRead = useCallback((taskId) => {
    if (!taskId) return;
    setTaskCommentUnread(prev => {
      if (!prev[taskId]) return prev;
      const next = { ...prev };
      delete next[taskId];
      return next;
    });
  }, []);

  const logActivity = useCallback(async ({ title, message, recipients, eventType, itemType, itemId, projectId, taskId }) => {
    if (!isElectron) return;
    if (!window.electronAPI?.notifications?.add) return;
    await window.electronAPI.notifications.add({
      title,
      message,
      recipients: Array.isArray(recipients) ? recipients.filter(Boolean) : [],
      actor: currentUser,
      ts: fmtFull(new Date()),
      eventType: eventType || 'activity',
      itemType: itemType || '',
      itemId: itemId || '',
      projectId: projectId || '',
      taskId: taskId || '',
    });
    if (notificationsOpen) fetchNotifications();
  }, [currentUser, notificationsOpen, fetchNotifications]);

  useEffect(() => {
    if (!isElectron || !currentUser) return;
    fetchNotifications();
    fetchTaskCommentUnread();
    refreshWorkspaceData({ pullFirst: true });
  }, [currentUser, fetchNotifications, fetchTaskCommentUnread, refreshWorkspaceData]);

  useEffect(() => {
    if (!isElectron || !window.electronAPI?.sync?.onSnapshotUpdated) return undefined;
    return window.electronAPI.sync.onSnapshotUpdated((data) => {
      setSyncConnection(prev => ({
        ...prev,
        online: true,
        lastError: '',
        pendingCount: Number(data?.pendingCount ?? prev.pendingCount ?? 0),
        mode: data?.drive ? 'drive' : data?.direct ? 'direct' : prev.mode,
        lastSyncedAt: new Date().toISOString(),
      }));
      refreshWorkspaceData();
      fetchNotifications();
      fetchTaskCommentUnread();
      refreshQueueStatus();
    });
  }, [refreshWorkspaceData, fetchNotifications, fetchTaskCommentUnread, refreshQueueStatus]);

  useEffect(() => {
    if (!isElectron || !window.electronAPI?.sync?.onQueueUpdated) return undefined;
    return window.electronAPI.sync.onQueueUpdated((status) => {
      applyQueueStatus(status);
    });
  }, [applyQueueStatus]);

  useEffect(() => {
    if (!notificationsOpen) return;
    fetchNotifications();
    fetchTaskCommentUnread();
  }, [notificationsOpen, fetchNotifications, fetchTaskCommentUnread]);
  useEffect(() => {
    if (!isElectron || !currentUser) return;
    const timer = setInterval(() => {
      refreshWorkspaceData({ pullFirst: true });
      fetchNotifications();
      fetchTaskCommentUnread();
      refreshQueueStatus();
    }, 10000);
    return () => clearInterval(timer);
  }, [currentUser, refreshWorkspaceData, fetchNotifications, fetchTaskCommentUnread, refreshQueueStatus]);

  useEffect(() => {
    if (!isElectron || !currentUser || syncConnection.mode !== 'direct' || !syncConnection.enabled) return undefined;
    refreshQueueStatus();
    const timer = setInterval(refreshQueueStatus, 3000);
    return () => clearInterval(timer);
  }, [currentUser, syncConnection.mode, syncConnection.enabled, refreshQueueStatus]);

  const handleLogin = async ({ name, password, remember }) => {
    const userName = String(name || '').trim();
    const pwd = String(password || '');
    if (!userName) return { ok: false, error: 'Please select user.' };
    if (!pwd) return { ok: false, error: 'Please enter password.' };

    if (!isElectron || !window.electronAPI?.auth?.login) {
      return { ok: false, error: 'Desktop authentication is unavailable.' };
    }
    let res = await window.electronAPI.auth.login({ name: userName, password: pwd });
    if (!res?.ok && res?.multipleSignIn) {
      const useHere = window.confirm(res.error || 'Multiple sign-in detected. This user is already signed in on another client. Use here?');
      if (!useHere) return { ok: false, error: 'Sign in cancelled.' };
      res = await window.electronAPI.auth.login({ name: userName, password: pwd, force: true });
    }
    if (!res?.ok) return { ok: false, error: res?.error || 'Invalid user or password.' };
    setCurrentUser(res.user?.name || userName);

    const next = { name: userName, password: pwd, remember: !!remember };
    setSavedLogin(next.remember ? next : null);
    if (isElectron && window.electronAPI?.auth?.setRememberedLogin && next.remember) {
      await window.electronAPI.auth.setRememberedLogin(next);
    } else if (isElectron && window.electronAPI?.auth?.clearRememberedLogin && !next.remember) {
      await window.electronAPI.auth.clearRememberedLogin();
    }
    return { ok: true };
  };

  useEffect(() => {
    if (currentUser || autoLoginTried || !savedLogin?.remember || !savedLogin.name || !savedLogin.password) return;
    if (!employees.some(e => String(e.name || '').toLowerCase() === String(savedLogin.name || '').toLowerCase())) return;
    setAutoLoginTried(true);
    handleLogin({ name: savedLogin.name, password: savedLogin.password, remember: true }).catch(() => {});
  }, [currentUser, autoLoginTried, savedLogin, employees]);

  const handleLogout = async () => {
    try {
      await syncColumnWidthsNow();
      if (isElectron && window.electronAPI?.sync?.pull) {
        await window.electronAPI.sync.pull();
      }
    } catch (error) {
      console.warn('Unable to sync column widths before logout:', error);
    }
    const previousUser = currentUser;
    setCurrentUser(null);
    setSavedLogin(null);
    setAutoLoginTried(true);
    if (isElectron && window.electronAPI?.auth?.clearRememberedLogin) {
      await window.electronAPI.auth.clearRememberedLogin();
    }
    if (isElectron && window.electronAPI?.auth?.logout) {
      await window.electronAPI.auth.logout({ name: previousUser });
    }
  };

  const handlePasswordChanged = (newPassword) => {
    if (!savedLogin?.remember || !currentUser) return;
    if ((savedLogin.name || '').toLowerCase() !== String(currentUser).toLowerCase()) return;
    const next = { ...savedLogin, password: String(newPassword || '') };
    setSavedLogin(next);
    if (isElectron && window.electronAPI?.auth?.setRememberedLogin) {
      window.electronAPI.auth.setRememberedLogin(next).catch(() => {});
    }
  };

  const visibleTasks = useMemo(() => {
    const active = tasks.filter(t => t.status !== 'Archived');
    const meForAdmin = String(currentUser || '').trim().toLowerCase();
    if (isAdminAuthority) {
      return active.filter(t => {
        const assignedTo = String(t.assignedTo || '').trim().toLowerCase();
        const assignedBy = String(t.assignedBy || '').trim().toLowerCase();
        return !(assignedTo && assignedTo === assignedBy && assignedTo !== meForAdmin);
      });
    }
    const me = String(currentUser || '').toLowerCase();
    const subtaskTaskIds = new Set(
      (subtasks || [])
        .filter(s => String(s.assignedTo || '').toLowerCase() === me || String(s.assignedBy || '').toLowerCase() === me)
        .map(s => String(s.taskId || ''))
        .filter(Boolean)
    );
    const teamTaskIds = new Set();
    const projectTeamTaskIds = new Set();
    if (userRole === 'Manager' && currentUserTeamNames.size) {
      const managerTeams = new Set(
        employees
          .filter(e => String(e.name || '').trim().toLowerCase() === me)
          .flatMap(e => splitMultiValue(e.team).map(team => team.toLowerCase()))
      );
      for (const p of (projects || [])) {
        if (!splitMultiValue(p.team).some(team => managerTeams.has(team.toLowerCase()))) continue;
        const projectId = String(p.id || '');
        if (projectId) projectTeamTaskIds.add(projectId);
      }
      for (const s of (subtasks || [])) {
        const subAssignedTo = String(s.assignedTo || '').trim().toLowerCase();
        const subAssignedBy = String(s.assignedBy || '').trim().toLowerCase();
        if (currentUserTeamNames.has(subAssignedTo) || currentUserTeamNames.has(subAssignedBy)) {
          const taskId = String(s.taskId || '');
          if (taskId) teamTaskIds.add(taskId);
        }
      }
    }
    return active.filter(t =>
      t.assignedTo === currentUser ||
      t.assignedBy === currentUser ||
      subtaskTaskIds.has(String(t.id || '')) ||
      (
        userRole === 'Manager' &&
        (
          currentUserTeamNames.has(String(t.assignedTo || '').trim().toLowerCase()) ||
          currentUserTeamNames.has(String(t.assignedBy || '').trim().toLowerCase()) ||
          teamTaskIds.has(String(t.id || '')) ||
          projectTeamTaskIds.has(String(t.projectId || ''))
        )
      )
    );
  }, [tasks, subtasks, projects, employees, currentUser, userRole, currentUserTeamNames, isAdminAuthority]);
  const archivedTasks = useMemo(() => tasks.filter(t => t.status === 'Archived'), [tasks]);

  const filteredTasks = useMemo(() => {
    const base = visibleTasks;
    if (!searchQuery) return base;
    const q = searchQuery.toLowerCase();
    return base.filter(t => t.name?.toLowerCase().includes(q) || t.assignedTo?.toLowerCase().includes(q) || t.status?.toLowerCase().includes(q));
  }, [visibleTasks, searchQuery]);

  const taskStats = useMemo(() => ({
    total: visibleTasks.length,
    inProgress: visibleTasks.filter(t => t.status === 'In Progress').length,
    completed: visibleTasks.filter(isTaskCompleted).length,
    overdue: visibleTasks.filter(t => timeLeft(t.dueDate) === 'Overdue' && !isTaskCompleted(t)).length,
    pending: visibleTasks.filter(t => t.status === 'Pending Review').length,
  }), [visibleTasks]);

  const homeRelevantTasks = useMemo(() => {
    const me = String(currentUser || '').toLowerCase();
    if (isAdminAuthority) return (tasks || []);
    const subtaskTaskIds = new Set(
      (subtasks || [])
        .filter(s => String(s.assignedTo || '').toLowerCase() === me || String(s.assignedBy || '').toLowerCase() === me)
        .map(s => String(s.taskId || ''))
        .filter(Boolean)
    );
    const teamTaskIds = new Set();
    const projectTeamTaskIds = new Set();
    if (userRole === 'Manager' && currentUserTeamNames.size) {
      const managerTeams = new Set(
        employees
          .filter(e => String(e.name || '').trim().toLowerCase() === me)
          .flatMap(e => splitMultiValue(e.team).map(team => team.toLowerCase()))
      );
      for (const p of (projects || [])) {
        if (!splitMultiValue(p.team).some(team => managerTeams.has(team.toLowerCase()))) continue;
        const projectId = String(p.id || '');
        if (projectId) projectTeamTaskIds.add(projectId);
      }
      for (const s of (subtasks || [])) {
        const subAssignedTo = String(s.assignedTo || '').trim().toLowerCase();
        const subAssignedBy = String(s.assignedBy || '').trim().toLowerCase();
        if (currentUserTeamNames.has(subAssignedTo) || currentUserTeamNames.has(subAssignedBy)) {
          const taskId = String(s.taskId || '');
          if (taskId) teamTaskIds.add(taskId);
        }
      }
    }
    return (tasks || []).filter((t) => {
      const assignedToMe = String(t.assignedTo || '').toLowerCase() === me;
      const assignedByMe = String(t.assignedBy || '').toLowerCase() === me;
      const linkedViaSubtask = subtaskTaskIds.has(String(t.id || ''));
      const linkedViaTeam = userRole === 'Manager' && (
        currentUserTeamNames.has(String(t.assignedTo || '').trim().toLowerCase()) ||
        currentUserTeamNames.has(String(t.assignedBy || '').trim().toLowerCase()) ||
        teamTaskIds.has(String(t.id || '')) ||
        projectTeamTaskIds.has(String(t.projectId || ''))
      );
      return assignedToMe || assignedByMe || linkedViaSubtask || linkedViaTeam;
    });
  }, [tasks, subtasks, projects, employees, currentUser, userRole, currentUserTeamNames, isAdminAuthority]);

  const homeTaskIds = useMemo(() => new Set(homeRelevantTasks.map(t => String(t.id))), [homeRelevantTasks]);

  const homeRelevantIssues = useMemo(() => {
    if (isAdminAuthority) return issues;
    const me = String(currentUser || '').toLowerCase();
    return (issues || []).filter((i) => {
      const assignedToMe = String(i.assignedTo || '').toLowerCase() === me;
      const reportedByMe = String(i.reportedBy || '').toLowerCase() === me;
      const relatedTask = homeTaskIds.has(String(i.taskId || ''));
      return assignedToMe || reportedByMe || relatedTask;
    });
  }, [isAdminAuthority, issues, currentUser, homeTaskIds]);

  const homeRelevantProjects = useMemo(() => {
    if (isAdminAuthority) return projects;
    const projectIds = new Set(homeRelevantTasks.map(t => String(t.projectId || '')).filter(Boolean));
    return (projects || []).filter((p) => projectIds.has(String(p.id || '')));
  }, [isAdminAuthority, projects, homeRelevantTasks]);

  const homeRelevantSubtasks = useMemo(() => {
    if (isAdminAuthority) return subtasks;
    const me = String(currentUser || '').toLowerCase();
    return (subtasks || []).filter((s) => {
      const relatedTask = homeTaskIds.has(String(s.taskId || ''));
      const assignedToMe = String(s.assignedTo || '').toLowerCase() === me;
      const assignedByMe = String(s.assignedBy || '').toLowerCase() === me;
      return relatedTask || assignedToMe || assignedByMe;
    });
  }, [isAdminAuthority, subtasks, currentUser, homeTaskIds]);

  if (!currentUser) {
    return <LoginPage employees={employees} onLogin={handleLogin} savedLogin={savedLogin} />;
  }

  const openModal = async (type, data = null) => {
    let nextData = data;
    if (type === 'editTask' && data?.id && data?.reviewRejectedUnseen && String(data.assignedTo || '') === String(currentUser || '')) {
      if (isElectron && window.electronAPI?.tasks?.clearReviewReject) {
        await window.electronAPI.tasks.clearReviewReject({ id: data.id, actor: currentUser });
      }
      setTasks(prev => prev.map(t => (t.id === data.id ? { ...t, reviewRejectedUnseen: false } : t)));
      nextData = { ...data, reviewRejectedUnseen: false };
    }
    setModalState({ open: true, type, data: nextData });
  };
  const closeModal = () => setModalState({ open: false, type: null, data: null });
  const summarizeTaskChanges = (before, after) => {
    const diffs = [];
    const pushDiff = (label, a, b) => {
      if (String(a || '') === String(b || '')) return;
      diffs.push(`${label}: "${String(a || '-')}" -> "${String(b || '-')}"`);
    };
    pushDiff('Task Name', before?.name, after?.name);
    pushDiff('Description', before?.description, after?.description);
    pushDiff('Assigned To', before?.assignedTo, after?.assignedTo);
    pushDiff('Assigned By', before?.assignedBy, after?.assignedBy);
    pushDiff('Due Date', before?.dueDate, after?.dueDate);
    pushDiff('Status', before?.status, after?.status);
    pushDiff('Remarks', before?.remarks, after?.remarks);
    return diffs.length ? diffs.join(' | ') : 'No field changes.';
  };

  const addTask = async (task) => {
    if (!isElectron || !window.electronAPI?.tasks?.create) {
      setAlertMsg('Task creation is unavailable.');
      return null;
    }
    let createdId = null;
    const res = await window.electronAPI.tasks.create({ ...task, actor: currentUser, isAdminUser: isAdminAuthority });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to create task.');
      return null;
    }
    if (res.ok) {
      setTasks(prev => [...prev, { ...task, id: res.id }]);
      createdId = res.id;
    }
    if (createdId) {
      await logActivity({
        title: `Task created: ${task.name}`,
        message: `Task Name: ${task.name || '-'} | Description: ${task.description || '-'} | Due: ${task.dueDate || '-'} | Assigned To: ${task.assignedTo || '-'} | Assigned By: ${task.assignedBy || '-'}`,
        recipients: [...new Set([currentUser, ...resolveTaskRecipients(task)].filter(Boolean))],
        eventType: 'task_add',
        itemType: 'task',
        itemId: createdId,
        projectId: task.projectId || '',
        taskId: createdId,
      });
    }
    closeModal();
    return createdId;
  };
  const updateTask = async (id, updates) => {
    let finalStatus = updates.status;
    let approvalRequired = false;
    let approvers = [];
    let pendingTargetStatus = '';
    let pendingDueDate = '';
    let effectiveDueDate = updates.dueDate;
    if (isElectron) {
      const res = await window.electronAPI.tasks.update({ id, ...updates, actor: currentUser, isAdminUser: isAdminAuthority });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update task.');
        return;
      }
      if (res?.status) finalStatus = res.status;
      approvalRequired = !!res?.approvalRequired;
      approvers = Array.isArray(res?.approvers) ? res.approvers : [];
      pendingTargetStatus = String(res?.pendingTargetStatus || '');
      pendingDueDate = String(res?.pendingDueDate || '');
      if (res?.dueDate !== undefined) effectiveDueDate = String(res.dueDate || '');
    }
    const t = tasks.find(x => x.id === id) || {};
    const nextTask = {
      ...t,
      ...updates,
      ...(finalStatus ? { status: finalStatus } : {}),
      dueDate: effectiveDueDate !== undefined ? effectiveDueDate : t.dueDate,
      pendingTargetStatus,
      pendingDueDate,
      ...(isTaskFinishedStatus(finalStatus || updates.status || t.status) ? {} : { completedOn: '', archivedOn: '' }),
    };
    setTasks(prev => prev.map(item => item.id === id ? nextTask : item));
    const mergedTask = { ...nextTask };
    const changeSummary = summarizeTaskChanges(t, mergedTask);
    await logActivity({
      title: `Task updated: ${updates.name || t.name || id}`,
      message: approvalRequired
        ? `Review requested (${updates.status || finalStatus || 'Status change'}). Awaiting approval from ${approvers.join(', ') || 'assigner/admin'}. Changes: ${changeSummary}`
        : `Changes: ${changeSummary}`,
      recipients: approvalRequired ? approvers : resolveTaskRecipients(mergedTask),
      eventType: approvalRequired ? 'task_review_requested' : 'task_update',
      projectId: mergedTask.projectId || '',
      taskId: id,
    });
    if (String(mergedTask.status || '') !== 'Report Issue') {
      setIssues(prev => prev.filter(i => String(i.taskId || '') !== String(mergedTask.id || '')));
    }
    await createIssueFromTaskIfNeeded(mergedTask, t.status);
    closeModal();
  };

  const createIssueFromTaskIfNeeded = async (task, previousStatus) => {
    if (!task || task.status !== 'Report Issue') return null;
    if (String(previousStatus || '') === 'Report Issue') return null;
    const alreadyExists = issues.some(i => i.taskId === task.id && !['Resolved', 'Closed'].includes(String(i.status || '')));
    if (alreadyExists) return null;
    const issuePayload = {
      title: `Issue: ${task.name || task.id}`,
      description: task.description || 'Auto-generated from task status: Report Issue.',
      taskId: task.id,
      reportedBy: currentUser,
      assignedTo: task.assignedBy || task.assignedTo || '',
      priority: 'Medium',
      status: 'Open',
      remarks: 'Auto-created from task status.',
    };
    if (!isElectron || !window.electronAPI?.issues?.create) return null;
    let createdId = null;
    const res = await window.electronAPI.issues.create(issuePayload);
    if (!res?.ok) return null;
    createdId = res.id;
    setIssues(prev => [...prev, { ...issuePayload, id: createdId, dateReported: fmtFull(new Date()) }]);
    await logActivity({
      title: `Issue auto-created: ${issuePayload.title}`,
      message: `Generated from task ${task.id}.`,
      recipients: [issuePayload.assignedTo].filter(Boolean),
      eventType: 'issue_add',
      itemType: 'issue',
      itemId: createdId || '',
      taskId: task.id || '',
    });
    return createdId;
  };
  const openReportIssueFromTask = (task) => {
    if (!task) return;
    const prefill = {
      title: `Issue: ${task.name || task.id}`,
      description: task.description || 'Auto-generated from task status: Report Issue.',
      taskId: task.id || '',
      reportedBy: currentUser,
      assignedTo: task.assignedBy || task.assignedTo || '',
      priority: 'Medium',
      status: 'Open',
      remarks: 'Auto-created from task status.',
    };
    openModal('addIssue', prefill);
  };

  const setTaskStatus = async (id, status, remarks, options = {}) => {
    const t = tasks.find(x => x.id === id);
    if (!t) return;
    let finalStatus = status;
    let approvalRequired = false;
    let approvers = [];
    let pendingTargetStatus = '';
    let pendingDueDate = '';
    let effectiveDueDate = t.dueDate;
    let reviewRejectedUnseen = !!options.reviewRejected;
    if (isElectron && window.electronAPI?.tasks?.setStatus) {
      const res = await window.electronAPI.tasks.setStatus({
        id,
        status,
        remarks,
        actor: currentUser,
        isAdminUser: isAdminAuthority,
        reviewRejected: !!options.reviewRejected,
      });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update task status.');
        return;
      }
      finalStatus = res?.status || status;
      approvalRequired = !!res?.approvalRequired;
      approvers = Array.isArray(res?.approvers) ? res.approvers : [];
      pendingTargetStatus = String(res?.pendingTargetStatus || '');
      pendingDueDate = String(res?.pendingDueDate || '');
      if (res?.dueDate !== undefined) effectiveDueDate = String(res.dueDate || '');
      reviewRejectedUnseen = !!res?.reviewRejectedUnseen;
    }
    const nextTask = {
      ...t,
      status: finalStatus,
      dueDate: effectiveDueDate,
      pendingTargetStatus,
      pendingDueDate,
      reviewRejectedUnseen,
      completedOn: finalStatus === 'Completed' ? (t.completedOn || fmtFull(new Date())) : '',
      archivedOn: finalStatus === 'Archived' ? (t.archivedOn || fmtFull(new Date())) : '',
      ...(remarks !== undefined ? { remarks } : {}),
    };
    setTasks(prev => prev.map(item => item.id === id ? nextTask : item));
    const changeSummary = summarizeTaskChanges(t, nextTask);
    await logActivity({
      title: `Task status: ${t.name || id}`,
      message: approvalRequired
        ? `Review requested (${status}). Awaiting approval from ${approvers.join(', ') || 'assigner/admin'}. Changes: ${changeSummary}`
        : (remarks && finalStatus === 'In Progress'
          ? `Status changed to ${finalStatus}. Review note: ${remarks}. Changes: ${changeSummary}`
          : `Status changed to ${finalStatus}. Changes: ${changeSummary}`),
      recipients: approvalRequired ? approvers : resolveTaskRecipients(nextTask),
      eventType: approvalRequired ? 'task_review_requested' : 'task_status',
      projectId: nextTask.projectId || '',
      taskId: id,
    });
    if (String(nextTask.status || '') !== 'Report Issue') {
      setIssues(prev => prev.filter(i => String(i.taskId || '') !== String(nextTask.id || '')));
    }
    if (!options?.skipAutoIssue) {
      await createIssueFromTaskIfNeeded(nextTask, t.status);
    }
  };
  const deleteTask = async (id, options = {}) => {
    if (!isAdmin) return;
    const task = tasks.find(x => x.id === id);
    const fromProjectContext = !!options.fromProjectContext;
    if (String(task?.projectId || '').trim() && !fromProjectContext) {
      setAlertMsg('Project tasks can only be deleted from Projects tab.');
      return;
    }
    if (isElectron) {
      const res = await window.electronAPI.tasks.delete({ id, actor: currentUser, fromProjectContext });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to delete task.');
        return;
      }
    }
    setTasks(prev => prev.filter(t => t.id !== id));
    const t = tasks.find(x => x.id === id) || {};
    await logActivity({
      title: `Task deleted: ${t.name || id}`,
      message: `Deleted by ${currentUser}.`,
      recipients: resolveTaskRecipients(t),
      eventType: 'task_delete',
      projectId: t.projectId || '',
      taskId: id,
    });
    closeModal();
    return id;
  };
  const requestDeleteTask = (id, options = {}) => {
    if (!isAdmin) return;
    const task = tasks.find(x => x.id === id);
    const fromProjectContext = !!options.fromProjectContext;
    if (String(task?.projectId || '').trim() && !fromProjectContext) {
      setAlertMsg('Project tasks can only be deleted from Projects tab.');
      return;
    }
    setConfirmDeleteTask({ id, options });
  };
  const restoreTask = async (id) => {
    if (!isAdminAuthority) return;
    if (isElectron && window.electronAPI?.tasks?.restore) {
      const res = await window.electronAPI.tasks.restore({ id, actor: currentUser, isAdminUser: isAdminAuthority });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to restore task.');
        return;
      }
    }
    setTasks(prev => prev.map(t => (
      t.id === id
        ? { ...t, status: 'In Progress', archivedOn: '', completedOn: '', pendingTargetStatus: '', pendingDueDate: '' }
        : t
    )));
    await logActivity({
      title: `Task restored: ${id}`,
      message: `Restored from archive by ${currentUser}.`,
      recipients: [],
      eventType: 'task_restore',
      taskId: id,
    });
  };
  const extendTaskNextDay = async (id) => {
    if (!id || !isElectron || !window.electronAPI?.tasks?.extendNextDay) return;
    const res = await window.electronAPI.tasks.extendNextDay({ id, actor: currentUser, isAdminUser: isAdminAuthority });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to extend task due date.');
      return;
    }
    setTasks(prev => prev.map(t => (
      t.id === id
        ? {
            ...t,
            status: res.status || 'In Progress',
            dueDate: res.dueDate || t.dueDate,
            pendingTargetStatus: '',
            pendingDueDate: '',
          }
        : t
    )));
    await logActivity({
      title: `Task extended: ${id}`,
      message: `Due date extended to ${res.dueDate || '-'}.`,
      recipients: [],
      eventType: 'task_extend',
      taskId: id,
    });
  };
  const extendOverdueTask = async ({ task, durationVal, durationUnit, comment }) => {
    if (!task?.id || !isElectron || !window.electronAPI?.tasks?.extendNextDay) return;
    const res = await window.electronAPI.tasks.extendNextDay({
      id: task.id,
      actor: currentUser,
      isAdminUser: isAdminAuthority,
      durationVal,
      durationUnit,
      comment,
    });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to extend task due date.');
      return;
    }
    setTasks(prev => prev.map(t => (
      t.id === task.id
        ? {
            ...t,
            status: res.status || 'In Progress',
            durationVal: res.durationVal || durationVal || t.durationVal,
            durationUnit: res.durationUnit || durationUnit || t.durationUnit,
            dueDate: res.dueDate || t.dueDate,
            pendingTargetStatus: '',
            pendingDueDate: '',
            completedOn: '',
            archivedOn: '',
          }
        : t
    )));
    setModalState(prev => (
      prev.data?.id === task.id
        ? {
            ...prev,
            data: {
              ...prev.data,
              status: res.status || 'In Progress',
              durationVal: res.durationVal || durationVal || prev.data.durationVal,
              durationUnit: res.durationUnit || durationUnit || prev.data.durationUnit,
              dueDate: res.dueDate || prev.data.dueDate,
              pendingTargetStatus: '',
              pendingDueDate: '',
              completedOn: '',
              archivedOn: '',
            },
          }
        : prev
    ));
    await logActivity({
      title: `Task extended: ${task.name || task.id}`,
      message: `Due date extended to ${res.dueDate || '-'}.`,
      recipients: resolveTaskRecipients(task),
      eventType: 'task_extend',
      taskId: task.id,
      projectId: task.projectId || '',
    });
    setExtendTaskTarget(null);
  };
  const addProject = async (project) => {
    if (!isElectron || !window.electronAPI?.projects?.create) {
      setAlertMsg('Project creation is unavailable.');
      return null;
    }
    let createdId = null;
    const res = await window.electronAPI.projects.create({ ...project, actor: currentUser, createdBy: project.createdBy || currentUser });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to create project.');
      return null;
    }
    if (res.ok) { setProjects(prev => [...prev, { ...project, id: res.id }]); createdId = res.id; }
    await logActivity({
      title: `Project created: ${project.name}`,
      message: [
        project.team ? `Teams: ${project.team}` : '',
        project.owner ? `Users: ${project.owner}` : '',
      ].filter(Boolean).join(' | ') || 'Unassigned.',
      recipients: [...new Set([
        currentUser,
        project.createdBy,
        ...splitMultiValue(project.owner),
        ...(() => {
          const projectTeams = splitMultiValue(project.team).map(t => t.toLowerCase());
          return projectTeams.length ? employees.filter(e => projectTeams.includes(String(e.team || '').trim().toLowerCase())).map(e => e.name) : [];
        })(),
      ].filter(Boolean))],
      eventType: 'project_add',
      itemType: 'project',
      itemId: createdId || '',
      projectId: createdId || '',
    });
    closeModal();
    return createdId;
  };
  const updateProject = async (id, updates) => {
    if (isElectron) {
      const res = await window.electronAPI.projects.update({ id, ...updates, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update project.');
        return null;
      }
    }
    setProjects(prev => prev.map(p => p.id === id ? { ...p, ...updates } : p));
    const p = projects.find(x => x.id === id) || {};
    await logActivity({
      title: `Project updated: ${updates.name || p.name || id}`,
      message: `Status: ${updates.status || p.status || 'Updated'}.`,
      recipients: resolveProjectRecipients(id),
      eventType: 'project_update',
      projectId: id,
    });
    closeModal();
  };
  const deleteProject = async (id) => {
    if (!isAdminAuthority) return;
    const p = projects.find(x => x.id === id) || {};
    if (isElectron && window.electronAPI?.projects?.delete) {
      const res = await window.electronAPI.projects.delete({ id, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to delete project.');
        return;
      }
    }
    setProjects(prev => prev.filter(project => project.id !== id));
    setTasks(prev => prev.map(task => task.projectId === id ? { ...task, projectId: '' } : task));
    if (selectedProjectId === id) setSelectedProjectId('');
    await logActivity({
      title: `Project deleted: ${p.name || id}`,
      message: `Deleted by ${currentUser}.`,
      recipients: resolveProjectRecipients(id),
      eventType: 'project_delete',
      projectId: id,
    });
    closeModal();
  };
  const addIssue = async (issue) => {
    if (!isElectron || !window.electronAPI?.issues?.create) {
      setAlertMsg('Issue creation is unavailable.');
      return null;
    }
    let createdId = null;
    const res = await window.electronAPI.issues.create({ ...issue, actor: currentUser });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to create issue.');
      return null;
    }
    if (res.ok) {
      createdId = res.id;
      setIssues(prev => [...prev, { ...issue, id: res.id }]);
      if (issue?.taskId) {
        await setTaskStatus(issue.taskId, 'Report Issue', undefined, { skipAutoIssue: true });
      }
    }
    await logActivity({
      title: `Issue reported: ${issue.title}`,
      message: `Assigned to ${issue.assignedTo || 'Unassigned'}.`,
      recipients: [issue.assignedTo].filter(Boolean),
      eventType: 'issue_add',
      itemType: 'issue',
      itemId: createdId || '',
      taskId: issue.taskId || '',
    });
    closeModal();
    return createdId;
  };
  const updateIssue = async (id, updates) => {
    let syncTaskFromBackend = null;
    if (isElectron) {
      const res = await window.electronAPI.issues.update({ id, ...updates, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update issue.');
        return null;
      }
      syncTaskFromBackend = res?.syncedTaskStatus || null;
    }
    setIssues(prev => prev.map(i => i.id === id ? { ...i, ...updates } : i));
    const i = issues.find(x => x.id === id) || {};
    if (syncTaskFromBackend?.taskId) {
      setTasks(prev => prev.map(t => (
        String(t.id || '') === String(syncTaskFromBackend.taskId || '')
          ? { ...t, status: String(syncTaskFromBackend.status || t.status || '') }
          : t
      )));
    }
    await logActivity({
      title: `Issue updated: ${updates.title || i.title || id}`,
      message: `Status: ${updates.status || i.status || 'Updated'}.`,
      recipients: [...new Set([updates.assignedTo || i.assignedTo, i.reportedBy || currentUser, ...resolveTaskRecipients(tasks.find(t => t.id === (updates.taskId || i.taskId)))].filter(Boolean))],
      eventType: 'issue_update',
      itemType: 'issue',
      itemId: id,
      taskId: updates.taskId || i.taskId || '',
    });
    closeModal();
    return id;
  };
  const deleteIssue = async (id) => {
    const issue = issues.find(x => x.id === id);
    if (!issue) return;
    if (!isAdminAuthority && String(issue.reportedBy || '').toLowerCase() !== String(currentUser || '').toLowerCase()) {
      setAlertMsg('Only Admin or the issue creator can delete this issue.');
      return;
    }
    if (isElectron && window.electronAPI?.issues?.delete) {
      const res = await window.electronAPI.issues.delete({ id, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to delete issue.');
        return;
      }
    }
    setIssues(prev => prev.filter(i => i.id !== id));
    await logActivity({
      title: `Issue deleted: ${issue.title || id}`,
      message: `Deleted by ${currentUser}.`,
      recipients: [...new Set([issue.assignedTo, issue.reportedBy].filter(Boolean))],
      eventType: 'issue_delete',
      taskId: issue.taskId || '',
    });
  };

  //  Subtask Operations //
  const addSop = async (payload) => {
    if (!isElectron || !window.electronAPI?.sops?.create) return null;
    const res = await window.electronAPI.sops.create(payload);
    if (!res?.ok) return null;
    const next = {
      id: res.id,
      task: payload.task || '',
      description: payload.description || '',
      detail: payload.detail || '',
      attachmentPath: payload.attachmentPath || '',
      assignedTo: payload.assignedTo || '',
      assignedBy: payload.assignedBy || currentUser,
      createdOn: fmtFull(new Date()),
      updatedOn: fmtFull(new Date()),
    };
    setSops(prev => [next, ...prev]);
    await logActivity({
      title: `SOP assigned: ${next.task || next.id}`,
      message: `Assigned to ${next.assignedTo}.`,
      recipients: [next.assignedTo].filter(Boolean),
      eventType: 'sop_assigned',
    });
    return res.id;
  };

  const deleteSop = async (id) => {
    if (!isElectron || !window.electronAPI?.sops?.delete) return;
    const item = sops.find(s => s.id === id);
    const res = await window.electronAPI.sops.delete({ id });
    if (!res?.ok) return;
    setSops(prev => prev.filter(s => s.id !== id));
    await logActivity({
      title: `SOP removed: ${item?.task || id}`,
      message: `Removed by ${currentUser}.`,
      recipients: [item?.assignedTo].filter(Boolean),
      eventType: 'sop_deleted',
    });
  };

  const addSubtask = async (subtask) => {
    if (!isElectron || !window.electronAPI?.subtasks?.create) {
      setAlertMsg('Subtask creation is unavailable.');
      return null;
    }
    let createdId = null;
    const res = await window.electronAPI.subtasks.create({ ...subtask, actor: currentUser });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to create subtask.');
      return null;
    }
    if (res.ok) {
      setSubtasks(prev => [...prev, { ...subtask, id: res.id, dateAssigned: fmtFull(new Date()) }]);
      createdId = res.id;
    }
    if (createdId) {
      await logActivity({
        title: `Subtask created: ${subtask.name}`,
        message: `Assigned to ${subtask.assignedTo || 'Unassigned'}.`,
        recipients: [subtask.assignedTo, subtask.assignedBy || currentUser],
        eventType: 'subtask_add',
        taskId: subtask.taskId || '',
      });
    }
    return createdId;
  };
  const updateSubtask = async (id, updates) => {
    if (isElectron) {
      const res = await window.electronAPI.subtasks.update({ id, ...updates, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update subtask.');
        return;
      }
    }
    setSubtasks(prev => prev.map(s => s.id === id ? { ...s, ...updates } : s));
    const s = subtasks.find(x => x.id === id) || {};
    await logActivity({
      title: `Subtask updated: ${updates.name || s.name || id}`,
      message: `Status: ${updates.status || s.status || 'Updated'}.`,
      recipients: [updates.assignedTo || s.assignedTo, s.assignedBy || currentUser],
      eventType: 'subtask_update',
      taskId: updates.taskId || s.taskId || '',
    });
  };
  const deleteSubtask = async (id) => {
    const s = subtasks.find(x => x.id === id) || {};
    let pendingApproval = false;
    if (isElectron) {
      const res = await window.electronAPI.subtasks.delete({ id, actor: currentUser, isAdmin: isAdminAuthority });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to delete subtask.');
        return;
      }
      pendingApproval = !!res?.pendingApproval;
      if (pendingApproval) {
        const nextSubtask = res.row ? mapSubtaskRow(res.row) : { ...s, status: 'Pending Delete', remarks: `Delete requested by ${currentUser}` };
        setSubtasks(prev => prev.map(item => item.id === id ? { ...item, ...nextSubtask, id } : item));
      } else {
        setSubtasks(prev => prev.filter(item => item.id !== id));
      }
    } else {
      setSubtasks(prev => prev.filter(item => item.id !== id));
    }
    await logActivity({
      title: pendingApproval ? `Subtask delete requested: ${s.name || id}` : `Subtask deleted: ${s.name || id}`,
      message: pendingApproval ? `Delete requested by ${currentUser}. Awaiting assignor approval.` : `Deleted by ${currentUser}.`,
      recipients: [s.assignedTo, s.assignedBy || currentUser],
      eventType: 'subtask_delete',
      taskId: s.taskId || '',
    });
  };
  const setSubtaskStatus = async (id, status) => {
    if (isElectron) await window.electronAPI.subtasks.setStatus({ id, status });
    setSubtasks(prev => prev.map(s => s.id === id ? { ...s, status } : s));
    const s = subtasks.find(x => x.id === id) || {};
    await logActivity({
      title: `Subtask status: ${s.name || id}`,
      message: `Status set to ${status}.`,
      recipients: [s.assignedTo, s.assignedBy || currentUser],
      eventType: 'subtask_status',
      taskId: s.taskId || '',
    });
  };

  //  Recurring Template Operations //
  const addRecurring = async (template) => {
    if (!isElectron || !window.electronAPI?.recurring?.create) {
      setAlertMsg('Recurring template creation is unavailable.');
      return;
    }
    const res = await window.electronAPI.recurring.create({ ...template, assignedBy: template.assignedBy || currentUser });
    if (!res?.ok) {
      setAlertMsg(res?.error || 'Unable to create recurring template.');
      return;
    }
    await refreshWorkspaceData({ pullFirst: false });
  };
  const updateRecurring = async (id, updates) => {
    if (isElectron) {
      const res = await window.electronAPI.recurring.update({ id, ...updates, assignedBy: updates.assignedBy || currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to update recurring template.');
        return;
      }
    }
    await refreshWorkspaceData({ pullFirst: false });
  };
  const deleteRecurring = async (id) => {
    if (!isAdmin) return;
    if (isElectron) {
      const res = await window.electronAPI.recurring.delete({ id, isAdminUser: isAdmin, actor: currentUser });
      if (!res?.ok) {
        setAlertMsg(res?.error || 'Unable to delete recurring template.');
        return;
      }
    }
    setRecurring(prev => prev.filter(r => r.id !== id));
  };
  const hasSopAccess = isAdminAuthority || sops.some(s => String(s.assignedTo || '').toLowerCase() === String(currentUser || '').toLowerCase());

  const navItems = [
    { key: 'home', label: 'Home', icon: Home },
    { key: 'tasks', label: 'Tasks', icon: CheckSquare, hasUnseen: unseenAssignmentCounts.tasks > 0 },
    ...(isAdminAuthority ? [{ key: 'archive', label: 'Archive', icon: Archive }] : []),
    { key: 'projects', label: 'Projects', icon: FolderKanban, hasUnseen: unseenAssignmentCounts.projects > 0 },
    { key: 'recurring', label: 'Recurring', icon: Repeat },
    { key: 'calendar', label: 'Calendar', icon: CalendarDays },
    { key: 'issues', label: 'Issues', icon: AlertTriangle, hasUnseen: unseenAssignmentCounts.issues > 0 },
    ...(hasSopAccess ? [{ key: 'sop', label: 'SOP', icon: FileText }] : []),
    { key: 'templates', label: 'Templates', icon: LayoutTemplate },
    ...(isAdminAuthority ? [{ key: 'reports', label: 'Reports', icon: BarChart3 }] : []),
    ...(isAdmin ? [{ key: 'employees', label: 'Users', icon: Users }] : []),
    { key: 'settings', label: 'Settings', icon: Settings },
  ];

  const renderPage = () => {
    switch (activePage) {
      case 'home': return <HomePage tasks={homeRelevantTasks} issues={homeRelevantIssues} projects={homeRelevantProjects} subtasks={homeRelevantSubtasks} onNavigate={setActivePage} currentUser={currentUser} />;
      case 'tasks': return <TasksPage tasks={filteredTasks} subtasks={subtasks} employees={employees} searchQuery={searchQuery} onSearch={setSearchQuery} selectedProjectId={selectedProjectId} onAdd={() => openModal('addTask')} onEdit={(t) => { markAssignmentSeen('tasks', t.id); openModal('editTask', t); }} onDelete={requestDeleteTask} isAdmin={isAdmin} isSuperAdmin={isAdminAuthority} canViewHistory currentUser={currentUser} onSetTaskStatus={setTaskStatus} onExtendNextDay={extendTaskNextDay} onExtendOverdue={(task) => setExtendTaskTarget(task)} onReportIssue={openReportIssueFromTask} onAddSubtask={addSubtask} onUpdateSubtask={updateSubtask} onDeleteSubtask={deleteSubtask} onSetSubtaskStatus={setSubtaskStatus} taskCommentUnread={taskCommentUnread} unseenTaskIds={unseenAssignmentIds.tasks} />;
      case 'archive': return <ArchiveTasksPage tasks={archivedTasks} onRestore={restoreTask} />;
      case 'projects': return <ProjectsPage projects={projects} tasks={tasks} onAdd={() => openModal('addProject')} onEdit={(p) => { markAssignmentSeen('projects', p.id); openModal('editProject', p); }} onDelete={deleteProject} onEditTask={(t) => { markAssignmentSeen('tasks', t.id); openModal('editTask', { ...t, __fromProjectContext: true }); }} onDeleteTask={(taskId) => requestDeleteTask(taskId, { fromProjectContext: true })} canDeleteProject={isAdminAuthority} canDeleteTask={isAdmin} currentUser={currentUser} isAdmin={isAdmin} unseenProjectIds={unseenAssignmentIds.projects} unseenTaskIds={unseenAssignmentIds.tasks} onProjectSeen={(id) => markAssignmentSeen('projects', id)} />;
      case 'recurring': return <RecurringPage recurring={recurring} employees={employees} projects={projects} currentUser={currentUser} isAdmin={isAdmin} canDelete={isAdmin} onAdd={addRecurring} onUpdate={updateRecurring} onDelete={deleteRecurring} />;
      case 'calendar': return <CalendarPage tasks={tasks} />;
      case 'issues': return <IssuesPage issues={issues} onAdd={() => openModal('addIssue')} onEdit={(i) => { markAssignmentSeen('issues', i.id); openModal('editIssue', i); }} onDelete={deleteIssue} currentUser={currentUser} isAdmin={isAdminAuthority} unseenIssueIds={unseenAssignmentIds.issues} />;
      case 'sop': return <SopPage sops={sops} employees={employees} currentUser={currentUser} isAdmin={isAdminAuthority} onAdd={addSop} onDelete={deleteSop} />;
      case 'templates': return <PlaceholderPage icon={LayoutTemplate} title="Template Library" />;
      case 'reports': return <ReportsPage tasks={tasks} projects={projects} issues={issues} employees={employees} />;
      case 'employees': return <EmployeesPage employees={employees} setEmployees={setEmployees} teams={teams} setTeams={setTeams} currentUser={currentUser} />;
      case 'settings': return <SettingsPage currentUser={currentUser} isSuperAdmin={isSuperAdmin} isRemoteApp={isRemoteApp} syncConnection={syncConnection} onPasswordChanged={handlePasswordChanged} onServerSettingsChanged={handleServerSettingsChanged} />;
      default: return null;
    }
  };

  const offlineBadge = syncConnection.enabled && !syncConnection.online ? (
    <span
      title={syncConnection.pendingCount > 0 ? `${syncConnection.pendingCount} change${syncConnection.pendingCount === 1 ? '' : 's'} waiting to sync` : (syncConnection.mode === 'direct' ? 'DB not connected' : 'Offline')}
      style={{ border: '1px solid #fca5a5', color: '#dc2626', background: '#fff7ed', borderRadius: 6, padding: '3px 7px', fontSize: 10, fontWeight: 700, lineHeight: 1, flexShrink: 0 }}
    >
      {syncConnection.mode === 'direct' ? 'DB not connected' : 'Offline'}
    </span>
  ) : null;

  return (
    <ColumnWidthContext.Provider value={{ widths: tableColumnWidths, rowHeights: tableRowHeights, canResize: isSuperAdmin, setColumnWidth: updateColumnWidth, setRowHeight: updateRowHeight }}>
    <div style={{ display: 'flex', height: '100vh', fontFamily: "'DM Sans', 'Segoe UI', system-ui, sans-serif", background: '#f4f7fa', overflow: 'hidden' }}>
      <style>{`
        @keyframes modalIn { from { opacity: 0; transform: scale(0.95) translateY(8px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
        input:focus, select:focus, textarea:focus { border-color: #0d9488 !important; box-shadow: 0 0 0 3px rgba(13,148,136,0.1) !important; }
      `}</style>

      {/* Sidebar */}
      <div style={{ width: sidebarCollapsed ? 64 : 220, background: '#fff', borderRight: '1px solid #e2e8f0', display: 'flex', flexDirection: 'column', transition: 'width 0.25s ease', flexShrink: 0 }}>
        <div style={{ padding: sidebarCollapsed ? '0 12px' : '0 20px', borderBottom: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', gap: 10, height: 56, boxSizing: 'border-box' }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: 'linear-gradient(135deg, #0d9488, #14b8a6)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <CheckSquare size={16} color="#fff" />
          </div>
          {!sidebarCollapsed && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
              <span style={{ fontWeight: 700, fontSize: 15, color: '#0f172a', whiteSpace: 'nowrap' }}>ERP Tasks</span>
              {offlineBadge}
            </div>
          )}
        </div>
        <nav style={{ flex: 1, padding: '8px', overflowY: 'auto' }}>
          {navItems.map(item => {
            const active = activePage === item.key;
            const assignmentTabType = item.key === 'tasks' ? 'tasks' : item.key === 'issues' ? 'issues' : item.key === 'projects' ? 'projects' : '';
            return (
              <button key={item.key} onClick={() => { if (assignmentTabType) markAssignmentTabSeen(assignmentTabType); setActivePage(item.key); }}
                style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%', padding: sidebarCollapsed ? '10px 0' : '9px 14px', marginBottom: 2, border: 'none', borderRadius: 8, cursor: 'pointer', fontSize: 13, fontWeight: active ? 600 : 500, color: active ? '#0d9488' : '#475569', background: active ? '#f0fdfa' : 'transparent', justifyContent: sidebarCollapsed ? 'center' : 'flex-start', transition: 'all 0.15s', position: 'relative' }}
                onMouseEnter={e => { if (!active) e.currentTarget.style.background = '#f8fafc'; }}
                onMouseLeave={e => { if (!active) e.currentTarget.style.background = active ? '#f0fdfa' : 'transparent'; }}>
                <item.icon size={18} style={{ flexShrink: 0 }} />
                {!sidebarCollapsed && <span>{item.label}</span>}
                {!sidebarCollapsed && item.hasUnseen && <span style={{ marginLeft: 'auto' }}><AssignmentDot /></span>}
                {sidebarCollapsed && item.hasUnseen && <span style={{ position: 'absolute', right: 8, width: 7, height: 7, borderRadius: '50%', background: '#ef4444' }} />}
              </button>
            );
          })}
        </nav>
        <div style={{ padding: '12px 8px', borderTop: '1px solid #e2e8f0' }}>
          <button onClick={() => setSidebarCollapsed(!sidebarCollapsed)} style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: '100%', padding: '8px 0', border: 'none', borderRadius: 8, cursor: 'pointer', background: '#f8fafc', color: '#64748b', fontSize: 12, gap: 6 }}>
            {sidebarCollapsed ? <ChevronRight size={16} /> : <><ChevronLeft size={14} /> Collapse</>}
          </button>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 6px', marginTop: 8 }}>
            <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#0d9488', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>{currentUser?.charAt(0)}</div>
            {!sidebarCollapsed && (
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: '#0f172a', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{currentUser}</div>
                {!isBaseRole(userRole) && <div style={{ fontSize: 11, color: '#64748b' }}>{displayRole(userRole)}</div>}
              </div>
            )}
            <button onClick={handleLogout} title="Logout" style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#94a3b8', padding: 4, flexShrink: 0 }}><LogOut size={16} /></button>
          </div>
        </div>
      </div>

      {/* Main */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ background: '#fff', borderBottom: '1px solid #e2e8f0', padding: '0 24px', height: 56, display: 'flex', alignItems: 'center', gap: 16, flexShrink: 0 }}>
          <h2 style={{ margin: 0, fontSize: 17, fontWeight: 700, color: '#0f172a' }}>{navItems.find(n => n.key === activePage)?.label || 'Dashboard'}</h2>
          <div style={{ flex: 1 }} />
          <div
            style={{ position: 'relative', display: (syncConnection.mode === 'direct' || syncConnection.mode === 'drive') ? 'block' : 'none' }}
            title={syncConnection.pendingCount > 0 ? `${syncConnection.pendingCount} queued change${syncConnection.pendingCount === 1 ? '' : 's'} waiting to appear in the app` : 'No queued remote changes'}
          >
            <ListTree size={18} color={syncConnection.pendingCount > 0 ? '#0d9488' : '#64748b'} style={{ cursor: 'pointer' }} onClick={() => { setSyncQueueOpen(v => !v); setNotificationsOpen(false); }} />
            {syncConnection.pendingCount > 0 && (
              <span style={{ position: 'absolute', top: -4, right: -6, minWidth: 16, height: 16, padding: '0 4px', borderRadius: 999, background: '#0d9488', color: '#fff', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center', boxSizing: 'border-box' }}>
                {syncConnection.pendingCount > 99 ? '99+' : syncConnection.pendingCount}
              </span>
            )}
            {syncQueueOpen && (
              <div style={{ position: 'absolute', right: 0, top: 28, width: 340, maxHeight: 380, overflow: 'auto', background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, boxShadow: '0 16px 45px rgba(15,23,42,0.16)', zIndex: 30, padding: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: '#0f172a' }}>Queued Changes</div>
                  <button onClick={syncNow} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 11 }}>Sync Now</button>
                </div>
                {syncQueueItems.length === 0 ? (
                  <div style={{ fontSize: 12, color: '#64748b', padding: '16px 0', textAlign: 'center' }}>No queued changes</div>
                ) : (
                  <div style={{ display: 'grid', gap: 8 }}>
                    {syncQueueItems.slice().reverse().map((item) => (
                      <div key={item.id || `${item.queuedAt}-${item.label}`} style={{ border: '1px solid #e2e8f0', borderRadius: 8, padding: 10, background: '#f8fafc' }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: '#0f172a' }}>{item.label || `${item.action || 'update'} ${item.table || 'change'}`}</div>
                        <div style={{ fontSize: 11, color: '#64748b', marginTop: 4 }}>{item.queuedAt ? new Date(item.queuedAt).toLocaleString() : 'Queued'}</div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          <div style={{ position: 'relative' }}>
            <MessageSquare size={18} color="#64748b" style={{ cursor: 'pointer' }} onClick={openNotifications} />
            {notificationBadgeCount > 0 && <span style={{ position: 'absolute', top: -4, right: -4, width: 16, height: 16, borderRadius: '50%', background: '#0d9488', color: '#fff', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{notificationBadgeCount > 99 ? '99+' : notificationBadgeCount}</span>}
          </div>
          <div style={{ position: 'relative' }} onClick={() => setModalState({ open: true, type: 'reminders', data: null })}>
            <BellRing size={18} color="#64748b" style={{ cursor: 'pointer' }} />
            {taskStats.overdue > 0 && <span style={{ position: 'absolute', top: -4, right: -4, width: 16, height: 16, borderRadius: '50%', background: '#ef4444', color: '#fff', fontSize: 9, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{taskStats.overdue}</span>}
          </div>
          <div style={{ width: 1, height: 24, background: '#e2e8f0' }} />
          <div style={{ fontSize: 12, color: '#64748b' }}>{now.toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })}</div>
          <div style={{ position: 'relative' }}>
            <button onClick={() => setCreateMenuOpen(v => !v)} style={{ background: '#16a34a', border: '1px solid #16a34a', color: '#fff', borderRadius: 8, padding: '6px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
              <Plus size={12} />Create
            </button>
            {createMenuOpen && (
              <div style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, boxShadow: '0 12px 24px rgba(15,23,42,0.12)', padding: 6, minWidth: 160, zIndex: 50 }}>
                <button onClick={() => { setCreateMenuOpen(false); openModal('addTask'); }} style={{ width: '100%', textAlign: 'left', padding: '8px 10px', border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 12, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <CheckSquare size={14} /> Task
                </button>
                <button onClick={() => { setCreateMenuOpen(false); openModal('addIssue'); }} style={{ width: '100%', textAlign: 'left', padding: '8px 10px', border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 12, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <AlertTriangle size={14} /> Issue
                </button>
                <button onClick={() => { setCreateMenuOpen(false); openModal('addProject'); }} style={{ width: '100%', textAlign: 'left', padding: '8px 10px', border: 'none', background: 'transparent', cursor: 'pointer', fontSize: 12, color: '#0f172a', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <FolderKanban size={14} /> Project
                </button>
              </div>
            )}
          </div>
        </div>
        <div style={{ flex: 1, overflow: 'auto', padding: 24, animation: 'fadeIn 0.25s ease-out' }}>{renderPage()}</div>
      </div>

      {/* Modals */}
      <TaskModal open={modalState.open && (modalState.type === 'addTask' || modalState.type === 'editTask')} onClose={closeModal} task={modalState.data} employees={employees} projects={projects} subtasks={subtasks} tasks={tasks} taskTemplates={taskTemplates} onSaveTemplate={(tpl) => setTaskTemplates(prev => [tpl, ...prev.filter(t => (t.templateName || '').toLowerCase() !== (tpl.templateName || '').toLowerCase())])} onAddSubtask={addSubtask} onUpdateSubtask={updateSubtask} onSave={modalState.type === 'editTask' ? (data) => updateTask(modalState.data.id, data) : addTask} onDelete={(modalState.type === 'editTask' && isAdmin && (!modalState.data?.projectId || modalState.data?.__fromProjectContext)) ? () => requestDeleteTask(modalState.data.id, { fromProjectContext: !!modalState.data?.__fromProjectContext }) : null} onExtendOverdue={(task) => setExtendTaskTarget(task)} currentUser={currentUser} userRole={userRole} unreadCommentsCount={taskCommentUnread[modalState.data?.id] || 0} onCommentsRead={markTaskCommentsRead} />
      <ExtendTaskModal
        open={!!extendTaskTarget}
        task={extendTaskTarget}
        onClose={() => setExtendTaskTarget(null)}
        onSave={extendOverdueTask}
      />
      <ProjectModal open={modalState.open && (modalState.type === 'addProject' || modalState.type === 'editProject')} onClose={closeModal} project={modalState.data} employees={employees} teams={teams} projectTemplates={projectTemplates} onSaveTemplate={(tpl) => setProjectTemplates(prev => [tpl, ...prev.filter(t => (t.templateName || '').toLowerCase() !== (tpl.templateName || '').toLowerCase())])} projectTags={projectTags} onAddTag={(tag) => setProjectTags(prev => prev.some(t => t.toLowerCase() === tag.toLowerCase()) ? prev : [...prev, tag])} onSave={modalState.type === 'editProject' ? (data) => updateProject(modalState.data.id, data) : addProject} onDelete={(modalState.type === 'editProject' && isAdminAuthority) ? () => deleteProject(modalState.data.id) : null} currentUser={currentUser} isAdmin={isAdmin} />
      <IssueModal open={modalState.open && (modalState.type === 'addIssue' || modalState.type === 'editIssue')} onClose={closeModal} issue={modalState.data} employees={employees} tasks={tasks} onSave={modalState.type === 'editIssue' ? (data) => updateIssue(modalState.data.id, data) : addIssue} currentUser={currentUser} isAdmin={isAdmin} />
      <ReminderListPanel open={modalState.open && modalState.type === 'reminders'} onClose={closeModal} currentUser={currentUser} isAdmin={isAdmin} />
      <NotificationPanel open={notificationsOpen} onClose={() => setNotificationsOpen(false)} notifications={notifications} assignmentNotifications={assignmentNotifications} currentUser={currentUser} isAdmin={isAdminAuthority} onRefresh={fetchNotifications} />
      <ConfirmDialog
        open={!!confirmDeleteTask}
        title="Delete Task"
        message="Are you sure you want to delete this task?."
        confirmLabel="Delete"
        onConfirm={() => {
          const target = confirmDeleteTask;
          setConfirmDeleteTask(null);
          if (target?.id) deleteTask(target.id, target.options || {});
        }}
        onCancel={() => setConfirmDeleteTask(null)}
      />
      <AlertDialog open={!!alertMsg} message={alertMsg} onClose={() => setAlertMsg(null)} />
    </div>
    </ColumnWidthContext.Provider>
  );
}

export default function App({ mode = 'client' }) {
  return (
    <ErrorBoundary>
      <AppShell mode={mode} />
    </ErrorBoundary>
  );
}

//  Row Mappers (SQLite â†’ React state shape) //
function mapTaskRow(r) {
  return {
    id: r.task_id,
    name: r.task_name,
    description: r.description,
    assignedTo: r.assigned_to,
    assignedBy: r.assigned_by,
    dateAssigned: r.date_assigned,
    durationVal: r.duration_val,
    durationUnit: r.duration_unit,
    dueDate: r.due_date,
    status: r.status,
    remarks: r.remarks,
    templateId: r.template_id || null,
    projectId: r.project_id || '',
    completedOn: r.completed_on || '',
    archivedOn: r.archived_on || '',
    pendingTargetStatus: r.pending_target_status || '',
    pendingDueDate: r.pending_due_date || '',
    reviewRejectedUnseen: !!r.review_rejected_unseen,
  };
}
function mapSubtaskRow(r) {
  return {
    id: r.subtask_id,
    taskId: r.task_id,
    name: r.subtask_name,
    status: r.status,
    assignedTo: r.assigned_to,
    assignedBy: r.assigned_by,
    description: r.description,
    dateAssigned: r.date_assigned,
    durationVal: r.duration_val,
    durationUnit: r.duration_unit,
    dueDate: r.due_date,
    remarks: r.remarks,
    inputLabel: r.input_label || '',
    inputType: r.input_type || '',
    inputValue: r.input_value || '',
    validationRules: r.validation_rules || '',
  };
}
function mapProjectRow(r) {
  return { id: r.project_id, name: r.project_name, description: r.description, team: r.team_name || '', owner: r.owner_name, status: r.status, priority: r.priority, start: r.start_date, due: r.due_date, progress: parseInt(r.progress) || 0, createdBy: r.created_by, createdOn: r.created_on };
}
function mapIssueRow(r) {
  return { id: r.issue_id, title: r.title, description: r.description, taskId: r.task_id, reportedBy: r.reported_by, assignedTo: r.assigned_to, priority: r.priority, status: r.status, dateReported: r.date_reported, remarks: r.remarks };
}
function mapRecurringRow(r) {
  let attachmentPaths = [];
  try {
    const parsed = JSON.parse(r.attachment_paths || '[]');
    if (Array.isArray(parsed)) attachmentPaths = parsed.filter(Boolean);
  } catch {}
  return {
    id: r.id,
    taskName: r.task_name,
    description: r.description || '',
    assignedTo: r.assigned_to,
    assignedBy: r.assigned_by,
    frequency: r.frequency,
    nextRun: r.next_run_date,
    durationVal: r.duration_val,
    durationUnit: r.duration_unit,
    customInterval: r.custom_interval || '',
    customUnit: r.custom_unit || '',
    projectId: r.project_id || '',
    attachmentPaths,
  };
}
function mapSopRow(r) {
  return {
    id: r.sop_id,
    task: r.sop_task || '',
    description: r.description || '',
    detail: r.detail_text || '',
    attachmentPath: r.attachment_path || '',
    assignedTo: r.assigned_to || '',
    assignedBy: r.assigned_by || '',
    createdOn: r.created_on || '',
    updatedOn: r.updated_on || '',
  };
}

// Page Components (abbreviated for key pages - full implementations below)

function LoginPage({ employees, onLogin, savedLogin }) {
  const [selected, setSelected] = useState(savedLogin?.name || employees[0]?.name || '');
  const [password, setPassword] = useState(savedLogin?.password || '');
  const [remember, setRemember] = useState(!!savedLogin?.remember);
  const [authError, setAuthError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showDefaultHint, setShowDefaultHint] = useState(false);
  useEffect(() => {
    if (selected) return;
    if (employees.length === 0) return;
    const admin = employees.find(e => e.name === 'Admin');
    setSelected(admin ? admin.name : employees[0].name);
  }, [employees, selected]);

  useEffect(() => {
    if (!savedLogin) return;
    setSelected(savedLogin.name || '');
    setPassword(savedLogin.password || '');
    setRemember(!!savedLogin.remember);
  }, [savedLogin]);

  useEffect(() => {
    if (!savedLogin?.remember) return;
    const savedName = String(savedLogin.name || '').toLowerCase();
    const currentName = String(selected || '').toLowerCase();
    if (currentName && currentName === savedName) {
      setPassword(String(savedLogin.password || ''));
      setRemember(true);
    } else {
      setPassword('');
      setRemember(false);
    }
  }, [selected, savedLogin]);

  useEffect(() => {
    if (!selected) { setShowDefaultHint(false); return; }
    if (!isElectron || !window.electronAPI?.auth?.isDefaultPassword) {
      setShowDefaultHint(true);
      return;
    }
    let cancelled = false;
    window.electronAPI.auth.isDefaultPassword({ name: selected }).then((res) => {
      if (cancelled) return;
      if (res?.ok && typeof res?.showDefaultPasswordHint === 'boolean') {
        setShowDefaultHint(!!res.showDefaultPasswordHint);
      } else {
        setShowDefaultHint(!!res?.ok && !!res?.isDefaultPassword);
      }
    }).catch(() => {
      if (!cancelled) setShowDefaultHint(false);
    });
    return () => { cancelled = true; };
  }, [selected]);

  const submit = async () => {
    setAuthError('');
    setLoading(true);
    try {
      const res = await onLogin({ name: selected, password, remember });
      if (!res?.ok) {
        setAuthError(res?.error || 'Unable to login.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #f0fdfa 0%, #e0f2fe 50%, #ede9fe 100%)', fontFamily: "'DM Sans', system-ui" }}>
      <div style={{ background: '#fff', borderRadius: 20, padding: '40px 36px', width: 380, boxShadow: '0 20px 60px rgba(0,0,0,0.08)', animation: 'fadeIn 0.4s ease-out' }}>
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: 'linear-gradient(135deg, #0d9488, #14b8a6)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginBottom: 16 }}><CheckSquare size={26} color="#fff" /></div>
          <h1 style={{ margin: 0, fontSize: 22, fontWeight: 700, color: '#0f172a' }}>Task Manager</h1>
          <p style={{ margin: '6px 0 0', color: '#64748b', fontSize: 14 }}>Sign in to continue</p>
        </div>
        <FormField label="Select User">
          <select value={selected} onChange={e => setSelected(e.target.value)} style={{ ...inputStyle, height: 40 }}>
            {employees.map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
          </select>
        </FormField>
        <FormField label="Password">
          <input
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') submit(); }}
            style={{ ...inputStyle, height: 40, cursor: 'text', caretColor: '#0f172a' }}
            placeholder="Enter password"
          />
        </FormField>
        <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#475569', marginTop: 4 }}>
          <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} style={{ accentColor: '#0d9488' }} />
          Save login on this PC
        </label>
        {authError && <div style={{ marginTop: 8, fontSize: 12, color: '#dc2626' }}>{authError}</div>}
        <button onClick={submit} disabled={!selected || !password || loading} style={{ ...btnPrimary, width: '100%', padding: '12px 0', fontSize: 14, marginTop: 10, justifyContent: 'center', opacity: (!selected || !password || loading) ? 0.6 : 1, cursor: (!selected || !password || loading) ? 'not-allowed' : 'pointer' }}>
          {loading ? 'Signing In...' : 'Sign In'}
        </button>
        {showDefaultHint && (
          <div style={{ marginTop: 10, fontSize: 11, color: '#64748b' }}>
            Default password: <b>12345</b>
          </div>
        )}
      </div>
    </div>
  );
}

function HomePage({ tasks, projects, issues, subtasks, onNavigate, currentUser }) {
  const currentNow = new Date();
  const greeting = currentNow.getHours() < 12 ? 'Good Morning' : currentNow.getHours() < 17 ? 'Good Afternoon' : 'Good Evening';
  const todayKey = `${String(currentNow.getDate()).padStart(2, '0')}-${String(currentNow.getMonth() + 1).padStart(2, '0')}-${String(currentNow.getFullYear()).slice(-2)}`;
  const activeTasks = (tasks || []).filter(t => String(t.status || '') !== 'Archived');
  const activeTaskIds = new Set(activeTasks.map(t => String(t.id || '')).filter(Boolean));
  const activeSubtasks = (subtasks || []).filter(s => !s.taskId || activeTaskIds.has(String(s.taskId || '')));
  const projectTaskCount = activeTasks.filter(t => String(t.projectId || '').trim()).length;
  const subtaskCount = activeSubtasks.length;
  const stepCount = activeSubtasks.filter(s => s.status === 'Completed').length;
  const taskSummary = {
    total: activeTasks.length,
    ongoing: activeTasks.filter(t => ['In Progress', 'Pending Review'].includes(t.status)).length,
    completed: activeTasks.filter(isTaskCompleted).length,
    overdue: activeTasks.filter(t => timeLeft(t.dueDate) === 'Overdue' && !isTaskCompleted(t)).length,
    scheduled: activeTasks.filter(t => t.status === 'Not Started').length,
  };
  const issueSummary = {
    total: issues.length,
    open: issues.filter(i => i.status === 'Open').length,
    ignored: issues.filter(i => i.status === 'Closed').length,
    resolved: issues.filter(i => i.status === 'Resolved').length,
  };
  const reviewSummary = {
    total: activeTasks.filter(t => t.status === 'Pending Review').length,
    completed: activeTasks.filter(t => t.status === 'Pending Review' && (t.pendingTargetStatus || 'Completed') === 'Completed').length,
    onHold: activeTasks.filter(t => t.status === 'Pending Review' && t.pendingTargetStatus === 'On Hold').length,
  };

  const getTimeMeta = (dueDate) => {
    const dt = parseAppDateTime(dueDate);
    if (!dt) return { label: '-', hoursLeft: null };
    const hoursLeft = (dt.getTime() - currentNow.getTime()) / 3600000;
    if (hoursLeft < 0) return { label: 'Overdue', hoursLeft };
    const daysLeft = hoursLeft / 24;
    if (daysLeft >= 1) return { label: `${Math.ceil(daysLeft)}d`, hoursLeft };
    return { label: `${Math.max(0, Math.ceil(hoursLeft))}h`, hoursLeft };
  };

  const isDueWithinDuration = (task) => {
    const dueDt = parseAppDateTime(task.dueDate);
    if (!dueDt) return false;
    const durationValue = parseInt(task.durationVal, 10) || 0;
    let deltaMs;
    if (String(task.durationUnit || '') === 'Hours') deltaMs = durationValue * 3600000;
    else if (String(task.durationUnit || '') === 'Weeks') deltaMs = durationValue * 7 * 86400000;
    else deltaMs = durationValue * 86400000;
    return currentNow.getTime() + deltaMs >= dueDt.getTime();
  };

  const todayTasks = activeTasks
    .filter(isDueWithinDuration)
    .map((t) => ({ ...t, timeMeta: getTimeMeta(t.dueDate) }))
    .sort((a, b) => {
      const ah = a.timeMeta.hoursLeft;
      const bh = b.timeMeta.hoursLeft;
      if (ah == null && bh == null) return 0;
      if (ah == null) return 1;
      if (bh == null) return -1;
      return ah - bh;
    });

  const mergedRows = [
    ...activeTasks
      .map((t) => ({
        type: 'task',
        name: t.name || '-',
        description: t.description || '-',
        status: t.status || '-',
        timeLabel: getTimeMeta(t.dueDate).label,
      })),
    ...issues.map((i) => ({
      type: 'issue',
      name: i.title || i.name || '-',
      description: i.description || '-',
      status: i.status || '-',
      timeLabel: '-',
    })),
  ];

  const topSectionHeight = 304;
  const cardStyle = { background: '#fff', border: '1px solid #e2e8f0', borderRadius: 10, padding: '10px 12px', cursor: 'pointer', minHeight: 0 };
  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
      <div style={{ marginBottom: 14, flexShrink: 0 }}>
        <h2 style={{ margin: 0, fontSize: 20, fontWeight: 700, color: '#0f172a' }}>{greeting} ! {currentUser}</h2>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.15fr 1fr', gap: 14, marginBottom: 14, alignItems: 'stretch', height: topSectionHeight, flexShrink: 0 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(190px, 1fr))', gridTemplateRows: 'repeat(2, minmax(0, 1fr))', gap: 10, minHeight: 0 }}>
          <div style={cardStyle} onClick={() => onNavigate('projects')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
              <span style={{ width: 24, height: 24, borderRadius: 8, background: '#dcfce7', color: '#16a34a', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><FolderKanban size={14} /></span>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{projects.length}</div>
              <div style={{ fontSize: 14, color: '#1e293b', fontWeight: 600 }}>Projects</div>
            </div>
            <div style={{ display: 'flex', gap: 10, color: '#64748b', fontSize: 12 }}>
              <span>Tasks <b style={{ color: '#f59e0b' }}>{projectTaskCount}</b></span>
              <span>Subtasks <b style={{ color: '#22c55e' }}>{subtaskCount}</b></span>
              <span>Steps <b style={{ color: '#fb7185' }}>{stepCount}</b></span>
            </div>
          </div>
          <div style={cardStyle} onClick={() => onNavigate('tasks')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
              <span style={{ width: 24, height: 24, borderRadius: 8, background: '#dbeafe', color: '#2563eb', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><CheckSquare size={14} /></span>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{taskSummary.total}</div>
              <div style={{ fontSize: 14, color: '#1e293b', fontWeight: 600 }}>Tasks</div>
            </div>
            <div style={{ display: 'flex', gap: 10, color: '#64748b', fontSize: 12, flexWrap: 'wrap' }}>
              <span>Ongoing <b style={{ color: '#f59e0b' }}>{taskSummary.ongoing}</b></span>
              <span>Overdue <b style={{ color: '#ef4444' }}>{taskSummary.overdue}</b></span>
              <span>Completed <b style={{ color: '#22c55e' }}>{taskSummary.completed}</b></span>
              <span>Scheduled <b style={{ color: '#8b5cf6' }}>{taskSummary.scheduled}</b></span>
            </div>
          </div>
          <div style={cardStyle} onClick={() => onNavigate('issues')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
              <span style={{ width: 24, height: 24, borderRadius: 8, background: '#ffedd5', color: '#f97316', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><AlertTriangle size={14} /></span>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{issueSummary.total}</div>
              <div style={{ fontSize: 14, color: '#1e293b', fontWeight: 600 }}>Issues</div>
            </div>
            <div style={{ display: 'flex', gap: 10, color: '#64748b', fontSize: 12, flexWrap: 'wrap' }}>
              <span>Open <b style={{ color: '#f59e0b' }}>{issueSummary.open}</b></span>
              <span>Ignored <b style={{ color: '#ef4444' }}>{issueSummary.ignored}</b></span>
              <span>Resolved <b style={{ color: '#22c55e' }}>{issueSummary.resolved}</b></span>
            </div>
          </div>
          <div style={cardStyle} onClick={() => onNavigate('tasks')}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 7 }}>
              <span style={{ width: 24, height: 24, borderRadius: 8, background: '#ede9fe', color: '#7c3aed', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><Check size={14} /></span>
              <div style={{ fontSize: 15, fontWeight: 700 }}>{reviewSummary.total}</div>
              <div style={{ fontSize: 14, color: '#1e293b', fontWeight: 600 }}>Review</div>
            </div>
            <div style={{ display: 'flex', gap: 10, color: '#64748b', fontSize: 12, flexWrap: 'wrap' }}>
              <span>Need Review <b style={{ color: '#7c3aed' }}>{reviewSummary.total}</b></span>
              <span>Completed <b style={{ color: '#22c55e' }}>{reviewSummary.completed}</b></span>
              <span>On Hold <b style={{ color: '#f59e0b' }}>{reviewSummary.onHold}</b></span>
            </div>
          </div>
        </div>

        <div style={{ border: '1px solid #e2e8f0', borderRadius: 12, overflow: 'hidden', background: '#fff', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
          <div style={{ padding: '14px 16px', borderBottom: '1px solid #e2e8f0', background: '#f8fafc', fontSize: 16, fontWeight: 700, color: '#0f172a' }}>
            Task for Today
          </div>
          <div style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
              <thead>
                <tr style={{ background: '#f8fafc' }}>
                  {['Sr.', 'Date', 'Task', 'Time Left', 'Status'].map((h) => (
                    <th key={h} style={{ padding: '6px 10px', textAlign: 'left', borderBottom: '1px solid #e2e8f0', color: '#334155', fontWeight: 600, position: 'sticky', top: 0, background: '#f8fafc', zIndex: 1 }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {todayTasks.length === 0 ? (
                  <tr>
                    <td colSpan={5} style={{ padding: '22px 12px', textAlign: 'center', color: '#94a3b8' }}>No daily or ongoing tasks.</td>
                  </tr>
                ) : todayTasks.map((t, idx) => {
                  const h = t.timeMeta.hoursLeft;
                  const tone = h != null && h <= 24
                    ? { bg: '#fee2e2', text: '#b91c1c' }
                    : h != null && h <= 72
                      ? { bg: '#fef3c7', text: '#92400e' }
                      : null;
                  return (
                    <tr key={t.id || `${t.name}-${idx}`} style={{ background: tone ? tone.bg : 'transparent', borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '10px 10px', color: '#334155', width: 50 }}>{idx + 1}</td>
                      <td style={{ padding: '10px 10px', color: '#475569', whiteSpace: 'nowrap' }}>{String(t.dueDate || '').split(' ')[0] || '-'}</td>
                      <td style={{ padding: '10px 10px', color: '#0f172a', fontWeight: 600 }}>{t.name || '-'}</td>
                      <td style={{ padding: '10px 10px', color: tone ? tone.text : '#334155', fontWeight: tone ? 700 : 600, whiteSpace: 'nowrap' }}>{t.timeMeta.label}</td>
                      <td style={{ padding: '10px 10px', color: '#334155', whiteSpace: 'nowrap' }}>{t.status || '-'}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div style={{ border: '1px solid #e2e8f0', borderRadius: 12, overflow: 'hidden', background: '#fff', display: 'flex', flexDirection: 'column', flex: 1.2, minHeight: 0 }}>
        <div style={{ padding: '9px 18px', borderBottom: '1px solid #e2e8f0', background: '#f8fafc', fontSize: 18, fontWeight: 700, color: '#0f172a' }}>
          Tasks and Issues
        </div>
        <div style={{ flex: 1, minHeight: 0, overflowY: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: '#f8fafc' }}>
                {['Sr.No', 'Task / Issue', 'Description', 'Status', 'Time Left', ''].map((h, i) => (
                    <th key={h + i} style={{ padding: '6px 10px', borderBottom: '1px solid #e2e8f0', color: '#334155', fontWeight: 600, fontSize: 13, textAlign: 'left', position: 'sticky', top: 0, background: '#f8fafc', zIndex: 1 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {mergedRows.length === 0 ? (
                <tr>
                  <td colSpan={6} style={{ textAlign: 'center', padding: '24px 10px', color: '#94a3b8' }}>
                    <Package size={30} style={{ opacity: 0.25, marginBottom: 8 }} />
                    <div style={{ fontSize: 13, color: '#94a3b8' }}>No tasks or issues found.</div>
                  </td>
                </tr>
              ) : mergedRows.map((row, idx) => (
                <tr key={`${row.type}-${idx}`} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '10px 10px', color: '#334155', width: 70 }}>{idx + 1}</td>
                  <td style={{ padding: '10px 10px', color: '#0f172a', fontWeight: 600 }}>{row.name}</td>
                  <td style={{ padding: '10px 10px', color: '#64748b' }}>{row.description}</td>
                  <td style={{ padding: '10px 10px', color: '#334155', whiteSpace: 'nowrap' }}>{row.status}</td>
                  <td style={{ padding: '10px 10px', color: '#334155', whiteSpace: 'nowrap' }}>{row.timeLabel}</td>
                  <td style={{ padding: '10px 10px', textAlign: 'right', width: 40 }}>
                    {row.type === 'issue' ? <AlertTriangle size={14} color="#eab308" /> : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
function TasksPage({ tasks, subtasks, employees, searchQuery, onSearch, selectedProjectId, onAdd, onEdit, onDelete, isAdmin, isSuperAdmin, canViewHistory, currentUser, onSetTaskStatus, onExtendNextDay, onExtendOverdue, onReportIssue, onAddSubtask, onUpdateSubtask, onDeleteSubtask, onSetSubtaskStatus, taskCommentUnread, unseenTaskIds }) {
  const [filterStatus, setFilterStatus] = useState('All');
  const [expandedTasks, setExpandedTasks] = useState(new Set());
  const [subtaskMgrTask, setSubtaskMgrTask] = useState(null);
  const [showAttachmentsForTask, setShowAttachmentsForTask] = useState(null);
  const [rejectReviewTask, setRejectReviewTask] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [rejectFiles, setRejectFiles] = useState([]);
  const [rejectManualPath, setRejectManualPath] = useState('');
  const [rejectError, setRejectError] = useState('');
  const [submitReviewTask, setSubmitReviewTask] = useState(null);
  const [submitReviewComment, setSubmitReviewComment] = useState('');
  const [submitReviewFiles, setSubmitReviewFiles] = useState([]);
  const [submitReviewManualPath, setSubmitReviewManualPath] = useState('');
  const [historyTask, setHistoryTask] = useState(null);
  const [historyRows, setHistoryRows] = useState([]);
  const [sortConfig, setSortConfig] = useState(null);
  const { widths: sharedColumnWidths, rowHeights: sharedRowHeights } = React.useContext(ColumnWidthContext);
  const taskTableColumns = [
    { key: 'srNo', label: 'Sr.No', width: 42, sortValue: (_t, idx) => idx + 1, filterValue: (_t, idx) => idx + 1 },
    { key: 'expand', label: '', width: 30, locked: true },
    { key: 'task', label: 'Task', width: 180, sortValue: t => t.name, filterValue: t => t.name },
    { key: 'id', label: 'ID', width: 110, sortValue: t => t.id, filterValue: t => t.id },
    { key: 'description', label: 'Description', width: 170, sortValue: t => t.description, filterValue: t => t.description },
    { key: 'assignedTo', label: 'Assigned To', width: 120 },
    { key: 'dueDate', label: 'Due Date', width: 110 },
    { key: 'timeLeft', label: 'Time Left', width: 105, sortValue: t => timeLeft(t.dueDate), filterValue: t => timeLeft(t.dueDate) },
    { key: 'status', label: 'Status', width: 170 },
    { key: 'actions', label: '', width: 170, locked: true },
  ];
  const isTaskToolColumn = (col) => !col.locked && !!col.label;
  const taskColumnWidth = (key, fallback) => {
    if (key === 'expand') return 30;
    return Math.max(key === 'srNo' ? 42 : 36, Number(sharedColumnWidths?.tasks?.[key] || fallback || 80));
  };
  const taskRowHeight = (rowKey, fallback = 44) => {
    return Math.max(34, Number(sharedRowHeights?.tasks?.[rowKey] || fallback));
  };
  const taskTableWidth = taskTableColumns.reduce((sum, col) => sum + taskColumnWidth(col.key, col.width), 0);
  const statusFiltered = useMemo(
    () => (filterStatus === 'All' ? tasks : tasks.filter(t => t.status === filterStatus)),
    [filterStatus, tasks]
  );
  const filtered = useMemo(() => {
    let rows = statusFiltered;
    if (sortConfig?.key) {
      const col = taskTableColumns.find(c => c.key === sortConfig.key);
      if (col) {
        rows = [...rows].sort((a, b) => {
          const result = compareColumnValues(
            columnTextValue(a, col, 0, 'sort'),
            columnTextValue(b, col, 0, 'sort')
          );
          return sortConfig.direction === 'desc' ? -result : result;
        });
      }
    }
    return rows;
  }, [sortConfig, statusFiltered]);
  const toggleTaskSort = (col) => {
    if (!isTaskToolColumn(col)) return;
    setSortConfig(prev => (prev?.key === col.key ? { key: col.key, direction: prev.direction === 'asc' ? 'desc' : 'asc' } : { key: col.key, direction: 'asc' }));
  };
  const subtasksByTaskId = useMemo(() => {
    const byId = new Map();
    for (const s of subtasks || []) {
      const key = s.taskId;
      if (!byId.has(key)) byId.set(key, []);
      byId.get(key).push(s);
    }
    return byId;
  }, [subtasks]);

  useEffect(() => {
    setExpandedTasks(new Set());
  }, [tasks.length]);

  const toggleExpand = (taskId, e) => {
    e.stopPropagation();
    setExpandedTasks(prev => {
      const next = new Set(prev);
      next.has(taskId) ? next.delete(taskId) : next.add(taskId);
      return next;
    });
  };

  const subtaskCount = (taskId) => (subtasksByTaskId.get(taskId) || []).length;
  const fileLabel = (p) => {
    const parts = String(p || '').split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const openRejectReview = (task) => {
    setRejectReviewTask(task);
    setRejectReason('');
    setRejectFiles([]);
    setRejectManualPath('');
    setRejectError('');
  };
  const openSubmitReview = (task) => {
    setSubmitReviewTask(task);
    setSubmitReviewComment('');
    setSubmitReviewFiles([]);
    setSubmitReviewManualPath('');
  };
  const pickRejectFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setRejectFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addRejectManualPath = () => {
    const paths = parseFilePathsFromText(rejectManualPath);
    if (!paths.length) return;
    setRejectFiles(prev => mergeUniqueFilePaths(prev, paths));
    setRejectManualPath('');
  };
  const submitRejectReview = async () => {
    if (!rejectReviewTask) return;
    const reason = String(rejectReason || '').trim();
    if (!reason) {
      setRejectError('Please enter reason');
      return;
    }
    const note = `Review Rejected by ${currentUser}: ${reason}`;
    await onSetTaskStatus?.(rejectReviewTask.id, 'In Progress', note, { reviewRejected: true });
    if (isElectron && rejectFiles.length) {
      await window.electronAPI.attachments.add({ itemId: rejectReviewTask.id, isSubtask: false, filePaths: rejectFiles, actor: currentUser, isAdmin });
    }
    setRejectReviewTask(null);
    setRejectReason('');
    setRejectFiles([]);
    setRejectManualPath('');
    setRejectError('');
  };
  const submitForReviewWithComment = async () => {
    if (!submitReviewTask) return;
    const comment = String(submitReviewComment || '').trim();
    const note = comment ? `Review comment by ${currentUser}: ${comment}` : undefined;
    await onSetTaskStatus?.(submitReviewTask.id, 'Pending Review', note);
    if (isElectron && submitReviewFiles.length) {
      await window.electronAPI.attachments.add({ itemId: submitReviewTask.id, isSubtask: false, filePaths: submitReviewFiles, actor: currentUser, isAdmin });
    }
    setSubmitReviewTask(null);
    setSubmitReviewComment('');
    setSubmitReviewFiles([]);
    setSubmitReviewManualPath('');
  };
  const pickSubmitReviewFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setSubmitReviewFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addSubmitReviewManualPath = () => {
    const paths = parseFilePathsFromText(submitReviewManualPath);
    if (!paths.length) return;
    setSubmitReviewFiles(prev => mergeUniqueFilePaths(prev, paths));
    setSubmitReviewManualPath('');
  };
  const openHistory = async (task) => {
    setHistoryTask(task);
    if (!isElectron || !window.electronAPI?.taskHistory?.list) return;
    const rows = await window.electronAPI.taskHistory.list({ taskId: task.id, actor: currentUser });
    setHistoryRows(Array.isArray(rows) ? rows : []);
  };
  const historyDetailsText = (row) => {
    try {
      const details = JSON.parse(row.details_json || '{}');
      if (String(row.action || '') === 'extend') {
        const attributed = details.attributedTo || {};
        const bits = [
          `Assignor: ${attributed.assignor || '-'}`,
          `Assignee: ${attributed.assignee || '-'}`,
        ];
        if (details.after?.duration_val || details.after?.duration_unit) {
          bits.push(`Duration: ${details.after.duration_val || '-'} ${details.after.duration_unit || ''}`.trim());
        }
        if (details.after?.due_date) bits.push(`Due: ${details.after.due_date}`);
        if (details.comment) bits.push(`Comment: ${details.comment}`);
        return bits.join(' | ');
      }
      return '';
    } catch {
      return '';
    }
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200, maxWidth: 340 }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
          <input value={searchQuery} onChange={e => onSearch(e.target.value)} placeholder="Search tasks..." style={{ ...inputStyle, paddingLeft: 36 }} />
        </div>
        <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} style={{ ...inputStyle, width: 'auto', minWidth: 140 }}>
          <option value="All">All Status</option>
          {STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}
        </select>
        <div style={{ flex: 1 }} />
        {/* Create button moved to top bar */}
      </div>
      {/* Task Tree Table */}
      <div style={{ border: '1px solid #e2e8f0', borderRadius: 10, overflow: 'hidden', width: '100%' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: `max(100%, ${taskTableWidth}px)`, borderCollapse: 'collapse', fontSize: 13, tableLayout: 'fixed' }}>
            <colgroup>
              {taskTableColumns.map(col => (
                <col key={col.key} style={{ width: taskColumnWidth(col.key, col.width) }} />
              ))}
            </colgroup>
            <thead>
              <tr style={{ background: '#f1f5f9' }}>
                {taskTableColumns.map((col) => {
                  const { key, label, width, locked } = col;
                  const showTools = isTaskToolColumn(col);
                  return (
                    <ResizableHeaderCell key={key} tableKey="tasks" columnKey={key} locked={locked} style={{ padding: key === 'expand' ? '10px 0' : key === 'srNo' ? '10px 14px 10px 10px' : '10px 14px 10px 2px', textAlign: 'center', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0', whiteSpace: 'nowrap', width: taskColumnWidth(key, width), minWidth: taskColumnWidth(key, width), cursor: showTools ? 'pointer' : 'default', userSelect: 'none' }}>
                      <div onClick={() => toggleTaskSort(col)}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                          <span>{label}</span>
                          {showTools && sortConfig?.key === key && <span style={{ color: '#0d9488', fontSize: 10 }}>{sortConfig.direction === 'asc' ? '▲' : '▼'}</span>}
                        </div>
                      </div>
                    </ResizableHeaderCell>
                  );
                })}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={10} style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>
                  <Package size={32} style={{ marginBottom: 8, opacity: 0.4 }} /><br />No tasks found
                </td></tr>
              ) : filtered.map((t, idx) => {
                const isExpanded = expandedTasks.has(t.id);
                const taskSubtasks = subtasksByTaskId.get(t.id) || [];
                const sc = taskSubtasks.length;
                const tl = timeLeft(t.dueDate);
                const reviewTarget = (t.pendingTargetStatus || 'Completed');
                const showRejectedAlert = !!t.reviewRejectedUnseen && String(t.assignedTo || '') === String(currentUser || '');
                const hasUnseenAssignment = !!unseenTaskIds?.has?.(String(t.id || ''));
                const showRowUpdateDot = hasUnseenAssignment || showRejectedAlert;
                const taskRowKey = `task:${t.id}`;
                const canExtendOverdue = tl === 'Overdue' && String(t.assignedBy || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase();
                return (
                  <React.Fragment key={t.id}>
                    {/* Parent Task Row */}
                    <tr style={{ borderBottom: isExpanded && sc > 0 ? 'none' : '1px solid #f1f5f9', transition: 'background 0.15s', cursor: 'pointer', height: taskRowHeight(taskRowKey, 46) }}
                      onMouseEnter={e => e.currentTarget.style.background = '#f8fafc'}
                      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      onClick={() => onEdit(t)}>
                      <td style={{ padding: '10px 10px 10px 10px', color: '#334155' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                          {showRowUpdateDot && <AssignmentDot />}
                          {idx + 1}
                        </span>
                      </td>
                      <td style={{ padding: '10px 6px', width: taskColumnWidth('expand', 30) }}>
                        {sc > 0 ? (
                          <button onClick={(e) => toggleExpand(t.id, e)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: 2, borderRadius: 4, display: 'flex' }}>
                            {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                          </button>
                        ) : <span style={{ width: 0, display: 'inline-block' }} />}
                      </td>
                      <td style={{ padding: '10px 14px 10px 8px', maxWidth: 260 }}>
                        <div style={{ fontWeight: 600, color: '#0f172a', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                          {t.name}
                        </div>
                      </td>
                      <td style={{ padding: '10px 14px 10px 2px' }}><span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#64748b' }}>{t.id}</span></td>
                      <td style={{ padding: '10px 14px 10px 2px', color: '#64748b', maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.description || '-'}</td>
                      <td style={{ padding: '10px 14px 10px 2px', whiteSpace: 'nowrap' }}>{t.assignedTo}</td>
                      <td style={{ padding: '10px 14px 10px 2px', whiteSpace: 'nowrap' }}>{t.dueDate?.split(' ')[0] || '-'}</td>
                      <td style={{ padding: '10px 14px 10px 2px' }}><span style={{ color: tl === 'Overdue' ? '#ef4444' : '#475569', fontWeight: tl === 'Overdue' ? 700 : 500 }}>{tl}</span></td>
                      <td style={{ padding: '10px 14px 10px 2px', overflow: 'hidden' }}>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-start' }}>
                          <StatusSelect
                            value={t.status || 'Not Started'}
                            onChange={(val) => {
                              if (val === 'Report Issue') {
                                onReportIssue?.(t);
                                return;
                              }
                              onSetTaskStatus?.(t.id, val);
                            }}
                            onClick={(e) => e.stopPropagation()}
                          />
                          {showRejectedAlert && <StatusBadge status="Review Rejected" labelOverride="Review Rejected" />}
                          {t.status === 'Pending Review' && (
                            (currentUser === t.assignedTo && !isAdmin) ? (
                              <button
                                onClick={(e) => { e.stopPropagation(); onSetTaskStatus?.(t.id, 'In Progress'); }}
                                style={{ background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, color: '#475569', cursor: 'pointer' }}
                              >
                                Withdraw Review
                              </button>
                            ) : (
                              <div style={{ fontSize: 11, color: '#7c3aed', fontWeight: 600 }}>
                                Requested: {reviewTarget}{t.pendingDueDate ? ` | Due Date: ${t.pendingDueDate}` : ''}
                              </div>
                            )
                          )}
                          {(isAdmin || currentUser === t.assignedBy) && t.status === 'Pending Review' && (
                            <div style={{ display: 'flex', gap: 6 }}>
                              <button
                                onClick={(e) => { e.stopPropagation(); onSetTaskStatus?.(t.id, reviewTarget); }}
                                style={{ background: '#dcfce7', border: '1px solid #86efac', borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, color: '#16a34a', cursor: 'pointer' }}
                              >
                                Approve
                              </button>
                              {String(reviewTarget || '') === 'Archived' && (
                                <button
                                  onClick={(e) => { e.stopPropagation(); onExtendNextDay?.(t.id); }}
                                  style={{ background: '#e0f2fe', border: '1px solid #7dd3fc', borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, color: '#0369a1', cursor: 'pointer' }}
                                >
                                  Extend +1 Day
                                </button>
                              )}
                              <button
                                onClick={(e) => { e.stopPropagation(); openRejectReview(t); }}
                                style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, color: '#dc2626', cursor: 'pointer' }}
                              >
                                Reject
                              </button>
                            </div>
                          )}
                          {(currentUser === t.assignedTo && currentUser !== t.assignedBy && !isAdmin && ['Completed', 'On Hold'].includes(String(t.status || ''))) && (
                            <button
                              onClick={(e) => { e.stopPropagation(); openSubmitReview(t); }}
                              style={{ background: '#ede9fe', border: '1px solid #c4b5fd', borderRadius: 5, padding: '2px 8px', fontSize: 11, fontWeight: 600, color: '#7c3aed', cursor: 'pointer' }}
                            >
                              Submit Review
                            </button>
                          )}
                        </div>
                      </td>
                      <td style={{ padding: '10px 8px 10px 2px', overflow: 'hidden', position: 'relative' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6, justifyContent: 'flex-start', flexWrap: 'nowrap', minWidth: 0 }}>
                          {sc > 0 ? (
                            <button onClick={(e) => { e.stopPropagation(); setSubtaskMgrTask(t); }} title="Subtasks"
                              style={{ background: '#f0fdfa', border: '1px solid #99f6e4', borderRadius: 6, padding: '3px 8px', fontSize: 11, fontWeight: 600, color: '#0d9488', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: 4, flexShrink: 0 }}>
                              <ListTree size={12} />{sc}
                            </button>
                          ) : (
                            <button onClick={(e) => { e.stopPropagation(); setSubtaskMgrTask(t); }} title="Add Subtask"
                              style={{ background: 'none', border: '1px dashed #d1d5db', borderRadius: 6, padding: '3px 6px', fontSize: 11, color: '#94a3b8', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                              <Plus size={11} />
                            </button>
                          )}
                          {canViewHistory && (
                            <button onClick={e => { e.stopPropagation(); openHistory(t); }} title="Task History" style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#0d9488', padding: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Clock size={14} /></button>
                          )}
                          <button
                            onClick={e => { e.stopPropagation(); onReportIssue?.(t); }}
                            title="Report Issue"
                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#eab308', padding: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
                          >
                            <AlertTriangle size={15} strokeWidth={1.9} />
                          </button>
                          <button onClick={e => { e.stopPropagation(); setShowAttachmentsForTask(t); }} title="Attachments" style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}><Paperclip size={14} /></button>
                          {canExtendOverdue && (
                            <button
                              onClick={e => { e.stopPropagation(); onExtendOverdue?.(t); }}
                              title="Extend"
                              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
                            >
                              <AlarmClockPlus size={14} />
                            </button>
                          )}
                          {isSuperAdmin && String(t.status || '') === 'Completed' && (
                            <button
                              onClick={e => { e.stopPropagation(); onSetTaskStatus?.(t.id, 'Archived'); }}
                              title="Move to Archive"
                              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b', padding: 4, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
                            >
                              <Archive size={14} />
                            </button>
                          )}
                        </div>
                        <RowResizeHandle tableKey="tasks" rowKey={taskRowKey} />
                      </td>
                    </tr>

                    {/* Subtask Rows (expanded) */}
                    {isExpanded && taskSubtasks.map((s, si) => {
                      const stl = timeLeft(s.dueDate);
                      const subtaskRowKey = `subtask:${s.id}`;
                      return (
                        <tr
                          key={s.id}
                          onClick={(e) => { e.stopPropagation(); setSubtaskMgrTask({ ...t, __selectedSubtaskId: s.id }); }}
                          style={{ background: '#fafbfc', borderBottom: si === taskSubtasks.length - 1 ? '1px solid #e2e8f0' : '1px solid #f1f5f9', height: taskRowHeight(subtaskRowKey, 40), cursor: 'pointer' }}
                        >
                          <td style={{ padding: '8px 14px 8px 10px' }} />
                          <td style={{ padding: '8px 6px' }} />
                          <td style={{ padding: '8px 14px 8px 8px' }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                              <CornerDownRight size={14} color="#cbd5e1" style={{ flexShrink: 0 }} />
                              <div>
                                <div style={{ fontWeight: 500, color: '#334155', fontSize: 12 }}>{s.name}</div>
                                {s.description && <div style={{ fontSize: 11, color: '#94a3b8' }}>{s.description.slice(0, 40)}</div>}
                              </div>
                            </div>
                          </td>
                          <td style={{ padding: '8px 14px 8px 2px' }}><span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#94a3b8' }}>{s.id}</span></td>
                          <td style={{ padding: '8px 14px 8px 2px', color: '#64748b', fontSize: 12, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.description || '-'}</td>
                          <td style={{ padding: '8px 14px 8px 2px', fontSize: 12 }}>{s.assignedTo}</td>
                          <td style={{ padding: '8px 14px 8px 2px', fontSize: 12, whiteSpace: 'nowrap' }}>{s.dueDate?.split(' ')[0] || '-'}</td>
                          <td style={{ padding: '8px 14px 8px 2px' }}><span style={{ fontSize: 12, color: stl === 'Overdue' ? '#ef4444' : '#64748b' }}>{stl}</span></td>
                          <td style={{ padding: '8px 14px 8px 2px' }}><StatusBadge status={s.status} /></td>
                          <td style={{ padding: '8px 6px 8px 2px', position: 'relative' }}>
                            <RowResizeHandle tableKey="tasks" rowKey={subtaskRowKey} />
                          </td>
                        </tr>
                      );
                    })}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={!!rejectReviewTask} onClose={() => setRejectReviewTask(null)} title={`Reject Review - ${rejectReviewTask?.id || ''}`} width={620}>
        <FormField label="Comment for disapproval" required>
          <textarea
            value={rejectReason}
            onChange={(e) => { setRejectReason(e.target.value); if (rejectError) setRejectError(''); }}
            style={{ ...inputStyle, minHeight: 80, resize: 'vertical' }}
            placeholder="Describe what is incomplete or incorrect."
          />
        </FormField>
        <div style={{ border: '1px dashed #e2e8f0', borderRadius: 10, padding: 12, marginTop: 4 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 8 }}>Attachments (optional)</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
            <input
              value={rejectManualPath}
              onChange={e => setRejectManualPath(e.target.value)}
              onPaste={async (e) => {
                const pastedPaths = await getPastedAttachmentPaths(e);
                if (!pastedPaths.length) return;
                e.preventDefault();
                setRejectFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
              }}
              placeholder="Paste file path(s) here or press Ctrl+V after copying files"
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={addRejectManualPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
            <button onClick={pickRejectFiles} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} /> Add Files</button>
          </div>
          {rejectFiles.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {rejectFiles.map((p, i) => (
                <div key={`${p}-${i}`} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: '6px 8px', fontSize: 12 }}>
                  <span style={{ color: '#334155' }}>{fileLabel(p)}</span>
                  <button type="button" onClick={() => setRejectFiles(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
                </div>
              ))}
            </div>
          )}
        </div>
        {rejectError && <div style={{ marginTop: 8, fontSize: 12, color: '#dc2626' }}>{rejectError}</div>}
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 16 }}>
          <button onClick={() => setRejectReviewTask(null)} style={btnSecondary}>Cancel</button>
          <button onClick={submitRejectReview} style={btnDanger}>Reject & Send</button>
        </div>
      </Modal>

      <Modal open={!!submitReviewTask} onClose={() => setSubmitReviewTask(null)} title={`Submit For Review - ${submitReviewTask?.id || ''}`} width={620}>
        <FormField label="Comment for reviewer (optional)">
          <textarea
            value={submitReviewComment}
            onChange={(e) => setSubmitReviewComment(e.target.value)}
            style={{ ...inputStyle, minHeight: 90, resize: 'vertical' }}
            placeholder="Add context for approver..."
          />
        </FormField>
        <div style={{ border: '1px dashed #e2e8f0', borderRadius: 10, padding: 12, marginTop: 4, marginBottom: 14 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 8 }}>Attachments (optional)</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
            <input
              value={submitReviewManualPath}
              onChange={e => setSubmitReviewManualPath(e.target.value)}
              onPaste={async (e) => {
                const pastedPaths = await getPastedAttachmentPaths(e);
                if (!pastedPaths.length) return;
                e.preventDefault();
                setSubmitReviewFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
              }}
              placeholder="Paste file path(s) here or press Ctrl+V after copying files"
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={addSubmitReviewManualPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
            <button onClick={pickSubmitReviewFiles} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} /> Add Files</button>
          </div>
          {submitReviewFiles.length > 0 && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {submitReviewFiles.map((p, i) => (
                <div key={`${p}-${i}`} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 8, padding: '6px 8px', fontSize: 12 }}>
                  <span style={{ color: '#334155' }}>{fileLabel(p)}</span>
                  <button type="button" onClick={() => setSubmitReviewFiles(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
                </div>
              ))}
            </div>
          )}
        </div>
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
          <button onClick={() => setSubmitReviewTask(null)} style={btnSecondary}>Cancel</button>
          <button onClick={submitForReviewWithComment} style={btnPrimary}>Submit</button>
        </div>
      </Modal>

      <Modal open={!!historyTask} onClose={() => setHistoryTask(null)} title={`Task History - ${historyTask?.id || ''}`} width={760}>
        {historyRows.length === 0 ? (
          <div style={{ color: '#94a3b8', fontSize: 13, textAlign: 'center', padding: 30 }}>No history found.</div>
        ) : (
          <DataTable
            columns={[
              { label: 'When', render: r => r.changed_on || '-' },
              { label: 'By', render: r => r.changed_by || '-' },
              { label: 'Action', render: r => String(r.action || '').toUpperCase() },
              { label: 'Summary', render: r => r.summary || '-', nowrap: false, maxWidth: 380 },
              { label: 'Details', render: r => historyDetailsText(r) || '-', nowrap: false, maxWidth: 340 },
            ]}
            data={historyRows}
            emptyMsg="No history found"
          />
        )}
      </Modal>

      {/* Subtask Manager Modal */}
      {subtaskMgrTask && (
        <SubtaskManagerModal
          task={subtaskMgrTask}
          subtasks={subtasks.filter(s => s.taskId === subtaskMgrTask.id)}
          initialSelectedId={subtaskMgrTask.__selectedSubtaskId || ''}
          employees={employees}
          currentUser={currentUser}
          isAdmin={isAdmin}
          onClose={() => setSubtaskMgrTask(null)}
          onAdd={onAddSubtask}
          onUpdate={onUpdateSubtask}
          onDelete={onDeleteSubtask}
          onSetStatus={onSetSubtaskStatus}
        />
      )}
      <AttachmentManager open={!!showAttachmentsForTask} onClose={() => setShowAttachmentsForTask(null)} itemId={showAttachmentsForTask?.id} isSubtask={false} itemName={showAttachmentsForTask?.name} actor={currentUser} isAdmin={isAdmin} />
    </div>
  );
}

//  Subtask Manager Modal //
function SubtaskManagerModal({ task, subtasks, initialSelectedId = '', employees, currentUser, isAdmin, onClose, onAdd, onUpdate, onDelete, onSetStatus }) {
  const [editingSubtask, setEditingSubtask] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedId, setSelectedId] = useState(null);

  const selected = subtasks.find(s => s.id === selectedId);
  useEffect(() => {
    if (initialSelectedId && subtasks.some(s => s.id === initialSelectedId)) {
      setSelectedId(initialSelectedId);
      return;
    }
    if (!selectedId && subtasks.length) setSelectedId(subtasks[0].id);
    if (selectedId && !subtasks.some(s => s.id === selectedId)) setSelectedId(subtasks[0]?.id || null);
  }, [initialSelectedId, selectedId, subtasks]);

  const toggleStatus = (s) => {
    const isMgr = isAdmin;
    const isAssigner = currentUser === s.assignedBy;
    const isMainTaskUser = currentUser === task.assignedTo || currentUser === task.assignedBy;
    const isAssignee = currentUser === s.assignedTo;
    if (s.status === 'Pending Delete') return;
    if (isMgr || isAssigner || isMainTaskUser) {
      if (s.status === 'Pending Review') onSetStatus(s.id, 'Completed');
      else if (s.status === 'Completed') onSetStatus(s.id, 'In Progress');
      else onSetStatus(s.id, 'Completed');
    } else if (isAssignee) {
      if (s.status === 'Not Started' || s.status === 'In Progress') onSetStatus(s.id, 'Pending Review');
      else if (s.status === 'Pending Review') onSetStatus(s.id, 'In Progress');
    }
  };
  const canApproveDelete = (s) => !!isAdmin || currentUser === s.assignedBy || currentUser === task.assignedBy;

  return (
    <Modal open={true} onClose={onClose} title={`Subtasks - ${task.name}`} width={780}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ fontSize: 13, color: '#64748b' }}>
          {subtasks.length} subtask{subtasks.length !== 1 ? 's' : ''}  ·  {subtasks.filter(s => s.status === 'Completed').length} completed
        </div>
        <button onClick={() => { setShowAddForm(true); setEditingSubtask(null); }} style={btnPrimary}><Plus size={14} />Add Subtask</button>
      </div>

      {/* Subtask table */}
      <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflow: 'hidden', marginBottom: 16 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f1f5f9' }}>
              {['#', 'Subtask', 'Assigned To', 'Status', 'Due Date', 'Actions'].map((h, i) => (
                <th key={i} style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {subtasks.length === 0 ? (
              <tr><td colSpan={6} style={{ padding: 30, textAlign: 'center', color: '#94a3b8', fontSize: 13 }}>No subtasks yet. Click "Add Subtask" to create one.</td></tr>
            ) : subtasks.map((s, i) => (
              <tr key={s.id}
                onClick={() => { setSelectedId(s.id); setEditingSubtask(s); setShowAddForm(true); }}
                style={{ borderBottom: '1px solid #f1f5f9', cursor: 'pointer', background: selectedId === s.id ? '#f0fdfa' : 'transparent', transition: 'background 0.15s' }}
                onMouseEnter={e => { if (selectedId !== s.id) e.currentTarget.style.background = '#f8fafc'; }}
                onMouseLeave={e => { if (selectedId !== s.id) e.currentTarget.style.background = 'transparent'; }}>
                <td style={{ padding: '8px 12px', color: '#94a3b8', fontSize: 12 }}>{i + 1}</td>
                <td style={{ padding: '8px 12px' }}>
                  <div style={{ fontWeight: 600, color: '#1e293b' }}>{s.name}</div>
                  {s.description && <div style={{ fontSize: 11, color: '#94a3b8' }}>{s.description.slice(0, 50)}</div>}
                </td>
                <td style={{ padding: '8px 12px' }}>{s.assignedTo}</td>
                <td style={{ padding: '8px 12px' }}><StatusBadge status={s.status} /></td>
                <td style={{ padding: '8px 12px', whiteSpace: 'nowrap', fontSize: 12 }}>{s.dueDate?.split(' ')[0] || '-'}</td>
                <td style={{ padding: '8px 12px' }}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button onClick={(e) => { e.stopPropagation(); toggleStatus(s); }} title="Toggle status"
                      style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#475569', fontSize: 11, display: 'flex', alignItems: 'center', gap: 3 }}>
                      {['Completed', 'Pending Review'].includes(String(s.status || '')) ? <ToggleRight size={12} color={s.status === 'Completed' ? '#22c55e' : '#8b5cf6'} /> : <ToggleLeft size={12} />}
                    </button>
                    {(isAdmin || currentUser === s.assignedBy || currentUser === task.assignedTo || currentUser === task.assignedBy) && s.status === 'Pending Review' && (
                      <>
                        <button onClick={(e) => { e.stopPropagation(); onSetStatus(s.id, 'Completed'); }} title="Approve"
                          style={{ background: '#dcfce7', border: '1px solid #86efac', borderRadius: 5, padding: '3px 8px', cursor: 'pointer', color: '#16a34a', fontSize: 11, fontWeight: 600 }}>
                          Approve
                        </button>
                        <button onClick={(e) => { e.stopPropagation(); onSetStatus(s.id, 'In Progress'); }} title="Reject"
                          style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 8px', cursor: 'pointer', color: '#dc2626', fontSize: 11, fontWeight: 600 }}>
                          Reject
                        </button>
                      </>
                    )}
                    <button onClick={(e) => { e.stopPropagation(); setEditingSubtask(s); setShowAddForm(true); }} title="Edit"
                      style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#475569' }}>
                      <Edit3 size={12} />
                    </button>
                    {s.status === 'Pending Delete' && canApproveDelete(s) ? (
                      <button onClick={(e) => { e.stopPropagation(); onDelete(s.id); }} title="Approve delete"
                        style={{ background: '#fee2e2', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 8px', cursor: 'pointer', color: '#dc2626', fontSize: 11, fontWeight: 600 }}>
                        Approve Delete
                      </button>
                    ) : (
                      <button onClick={(e) => { e.stopPropagation(); onDelete(s.id); }} title="Delete"
                        style={{ background: 'none', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#ef4444' }}>
                        <Trash2 size={12} />
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Progress bar */}
      {subtasks.length > 0 && (
        <div style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
            <span style={{ color: '#475569', fontWeight: 600 }}>Progress</span>
            <span style={{ color: '#64748b' }}>{subtasks.filter(s => s.status === 'Completed').length}/{subtasks.length}</span>
          </div>
          <div style={{ height: 8, borderRadius: 4, background: '#f1f5f9', overflow: 'hidden' }}>
            <div style={{ width: `${subtasks.length ? (subtasks.filter(s => s.status === 'Completed').length / subtasks.length) * 100 : 0}%`, height: '100%', background: '#0d9488', borderRadius: 4, transition: 'width 0.3s' }} />
          </div>
        </div>
      )}

      {selected && (
        <div style={{ ...shadcnPanel, padding: 12, marginBottom: 16 }}>
          <div style={{ ...shadcnLabel, marginBottom: 8 }}>Messages - {selected.name || selected.id}</div>
          <SubtaskCommentsPanel open={true} subtask={selected} task={task} currentUser={currentUser} isAdmin={isAdmin} />
        </div>
      )}

      {/* Inline Subtask Add/Edit Form */}
      {showAddForm && (
        <SubtaskEditorInline
          subtask={editingSubtask}
          taskId={task.id}
          parentDueDate={task?.dueDate || ''}
          employees={employees}
          currentUser={currentUser}
          onSave={async (data) => {
            const { validationFiles, ...payload } = data;
            if (editingSubtask) {
              await onUpdate(editingSubtask.id, payload);
              if (isElectron && validationFiles?.length) {
                await window.electronAPI.attachments.add({ itemId: editingSubtask.id, isSubtask: true, filePaths: validationFiles, actor: currentUser, isAdmin });
              }
            } else {
              const newId = await onAdd({ ...payload, taskId: task.id, assignedBy: currentUser });
              if (isElectron && newId && validationFiles?.length) {
                await window.electronAPI.attachments.add({ itemId: newId, isSubtask: true, filePaths: validationFiles, actor: currentUser, isAdmin });
              }
            }
            setShowAddForm(false);
            setEditingSubtask(null);
          }}
          onCancel={() => { setShowAddForm(false); setEditingSubtask(null); }}
        />
      )}
    </Modal>
  );
}

//  Subtask Editor Inline Form //
function SubtaskEditorInline({ subtask, taskId, employees, currentUser, onSave, onCancel, parentDueDate = '' }) {
  const currentUserRole = employees.find(e => String(e.name || '').toLowerCase() === String(currentUser || '').toLowerCase())?.role || BASE_ROLE;
  const canAssignSystemAdmin = String(currentUser || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase();
  const assignedToOptions = employees
    .filter(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME || e.name === (subtask?.assignedTo || subtask?.assigned_to))
    .map(e => e.name);
  const [form, setForm] = useState(subtask || {
    name: '', description: '', assignedTo: assignedToOptions[0] || employees[0]?.name || '', assignedBy: currentUser,
    durationVal: '1', durationUnit: 'Days', dueDate: fmt(daysFromNow(3)), status: 'Not Started', remarks: '',
  });
  const [validationFiles, setValidationFiles] = useState([]);
  const [existingAttachments, setExistingAttachments] = useState([]);
  const [attachmentError, setAttachmentError] = useState('');
  const [manualAttachmentPath, setManualAttachmentPath] = useState('');
  const [validationError, setValidationError] = useState('');
  const dueDateInputValue = useMemo(() => toDateInputValue(form.dueDate), [form.dueDate]);
  const parentDueDateInputValue = useMemo(() => toDateInputValue(parentDueDate), [parentDueDate]);

  const pickValidationFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setValidationFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualAttachmentPath = () => {
    const paths = parseFilePathsFromText(manualAttachmentPath);
    if (!paths.length) return;
    setValidationFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualAttachmentPath('');
  };
  const fileLabel = (p) => {
    const parts = p.split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };

  const loadExistingAttachments = useCallback(async () => {
    if (!isElectron || !subtask?.id || !window.electronAPI?.attachments?.list) {
      setExistingAttachments([]);
      return;
    }
    try {
      const rows = await window.electronAPI.attachments.list({ itemId: subtask.id, isSubtask: true, actor: currentUser, isAdmin: false });
      setExistingAttachments((rows || []).map(r => ({ id: r.id, fileName: r.file_name, filePath: r.file_path, addedOn: r.added_on, addedBy: r.added_by || '' })));
      setAttachmentError('');
    } catch (err) {
      setAttachmentError(err?.message || 'Unable to load attachments.');
    }
  }, [subtask?.id, currentUser]);

  useEffect(() => {
    loadExistingAttachments();
  }, [loadExistingAttachments]);

  const handleSave = () => {
    if (!form.name?.trim()) return;
    const subDueDt = parseAppDateTime(form.dueDate);
    const parentDueDt = parseAppDateTime(parentDueDate);
    if (subDueDt && parentDueDt && subDueDt.getTime() > parentDueDt.getTime()) {
      setValidationError(`Subtask due date cannot be after main task due date (${parentDueDate}).`);
      return;
    }
    setValidationError('');
    onSave({
      ...form,
      inputLabel: '',
      inputType: '',
      inputValue: '',
      validationRules: '',
      validationFiles,
    });
  };

  return (
    <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 10, padding: 16 }}>
      <h4 style={{ margin: '0 0 12px', fontSize: 14, fontWeight: 700, color: '#0f172a' }}>{subtask ? 'Edit Subtask' : 'Add New Subtask'}</h4>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
        <FormField label="Subtask Name" required>
          <input value={form.name || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} style={inputStyle} placeholder="Subtask name" />
        </FormField>
        <FormField label="Assigned To">
          <select value={form.assignedTo || ''} onChange={e => setForm(p => ({ ...p, assignedTo: e.target.value }))} style={inputStyle}>
            {assignedToOptions.map(name => <option key={name} value={name}>{name}</option>)}
          </select>
        </FormField>
        <FormField label="Description">
          <input value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} style={inputStyle} placeholder="Optional description" />
        </FormField>
        <FormField label="Status">
          <select value={form.status || 'Not Started'} onChange={e => setForm(p => ({ ...p, status: e.target.value }))} style={inputStyle}>
            {STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}
          </select>
        </FormField>
        <FormField label="Due Date">
          <input
            type="date"
            value={dueDateInputValue}
            max={parentDueDateInputValue || undefined}
            onChange={e => {
              const d = e.target.value.split('-');
              setForm(p => ({ ...p, dueDate: `${d[2]}-${d[1]}-${d[0].slice(-2)}` }));
              if (validationError) setValidationError('');
            }}
            style={inputStyle}
          />
        </FormField>
        <FormField label="Duration">
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="number"
              value={form.durationVal || '1'}
              onChange={e => {
                const nextVal = e.target.value;
                setForm(p => ({
                  ...p,
                  durationVal: nextVal,
                  dueDate: dueDateFromDuration(nextVal, p.durationUnit || 'Days', false) || p.dueDate,
                }));
              }}
              style={{ ...inputStyle, width: 70 }}
              min="1"
            />
            <select
              value={form.durationUnit || 'Days'}
              onChange={e => {
                const nextUnit = e.target.value;
                setForm(p => ({
                  ...p,
                  durationUnit: nextUnit,
                  dueDate: dueDateFromDuration(p.durationVal || '1', nextUnit, false) || p.dueDate,
                }));
              }}
              style={{ ...inputStyle, flex: 1 }}
            >
              <option>Hours</option><option>Days</option><option>Weeks</option>
            </select>
          </div>
        </FormField>
        <div style={{ gridColumn: '1 / -1' }}>
          <FormField label="Attach Files">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <input
                value={manualAttachmentPath}
                onChange={e => setManualAttachmentPath(e.target.value)}
                onPaste={async (e) => {
                  const pastedPaths = await getPastedAttachmentPaths(e);
                  if (!pastedPaths.length) return;
                  e.preventDefault();
                  setValidationFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
                }}
                placeholder="Paste file path(s) here or press Ctrl+V after copying files"
                style={{ ...inputStyle, flex: '1 1 260px' }}
              />
              <button onClick={addManualAttachmentPath} type="button" style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
              <button onClick={pickValidationFiles} type="button" style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}><Paperclip size={12} /> Add Files</button>
            </div>
            {validationFiles.length > 0 && (
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
                {validationFiles.map((f, i) => (
                  <span key={`${f}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, color: '#475569', background: '#eef2ff', borderRadius: 999, padding: '2px 8px' }}>
                    {fileLabel(f)}
                    <button
                      type="button"
                      onClick={() => setValidationFiles(prev => prev.filter((_, idx) => idx !== i))}
                      style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}
                    >
                      x
                    </button>
                  </span>
                ))}
              </div>
            )}
            {existingAttachments.length > 0 && (
              <div style={{ marginTop: 10 }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: '#64748b', marginBottom: 6 }}>Attached Files</div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {existingAttachments.map(a => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => isElectron && window.electronAPI.openPath(a.filePath)}
                      title={a.filePath || a.fileName}
                      style={{ ...shadcnGhostButton, padding: '4px 8px', fontSize: 11, maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis' }}
                    >
                      <Paperclip size={12} /> {a.fileName || fileLabel(a.filePath || '') || 'Attachment'}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {attachmentError && <div style={{ marginTop: 6, fontSize: 11, color: '#dc2626' }}>{attachmentError}</div>}
          </FormField>
        </div>
      </div>
      {validationError && <div style={{ marginTop: 8, fontSize: 12, color: '#dc2626' }}>{validationError}</div>}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 14 }}>
        <button onClick={onCancel} style={btnSecondary}>Cancel</button>
        <button onClick={handleSave} style={btnPrimary}>{subtask ? 'Update' : 'Add'} Subtask</button>
      </div>
    </div>
  );
}

function ArchiveTasksPage({ tasks, onRestore }) {
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
        <h3 style={{ margin: 0, fontSize: 16, color: '#0f172a' }}>Archived Tasks</h3>
        <div style={{ fontSize: 12, color: '#64748b' }}>{tasks.length} archived task{tasks.length !== 1 ? 's' : ''}</div>
      </div>
      <DataTable
        tableKey="archive"
        columns={[
          { label: 'Sr.No', key: 'srNo', style: { width: 48 } },
          { label: 'Task', key: 'name' },
          { label: 'ID', key: 'id' },
          { label: 'Assigned To', key: 'assignedTo' },
          { label: 'Assigned By', key: 'assignedBy' },
          { label: 'Archived On', render: t => t.archivedOn || '-' },
          {
            label: 'Actions',
            style: { width: 120 },
            render: t => (
              <button
                onClick={(e) => { e.stopPropagation(); onRestore?.(t.id); }}
                style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}
              >
                Restore
              </button>
            )
          },
        ]}
        data={tasks.map((task, index) => ({ ...task, srNo: index + 1 }))}
        emptyMsg="No archived tasks"
      />
    </div>
  );
}

function ProjectsPage({ projects, tasks, onAdd, onEdit, onDelete, onEditTask, onDeleteTask, canDeleteProject, canDeleteTask, currentUser, isAdmin, unseenProjectIds, unseenTaskIds, onProjectSeen }) {
  const [query, setQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [activeProject, setActiveProject] = useState(null);
  const [showAttachmentsForProject, setShowAttachmentsForProject] = useState(null);
  const [taskQuery, setTaskQuery] = useState('');
  const [confirmState, setConfirmState] = useState(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return projects.filter((p) => {
      const matchesStatus = statusFilter === 'All' || p.status === statusFilter;
      if (!matchesStatus) return false;
      if (!q) return true;
      return (
        p.name?.toLowerCase().includes(q) ||
        p.id?.toLowerCase().includes(q) ||
        p.owner?.toLowerCase().includes(q) ||
        p.team?.toLowerCase().includes(q) ||
        p.priority?.toLowerCase().includes(q) ||
        p.status?.toLowerCase().includes(q)
      );
    });
  }, [projects, query, statusFilter]);

  const projectTasks = useMemo(() => {
    if (!activeProject?.id) return [];
    const q = taskQuery.trim().toLowerCase();
    const rows = (tasks || []).filter(t => t.projectId === activeProject.id);
    if (!q) return rows;
    return rows.filter(t =>
      t.name?.toLowerCase().includes(q) ||
      t.id?.toLowerCase().includes(q) ||
      t.assignedTo?.toLowerCase().includes(q) ||
      t.status?.toLowerCase().includes(q)
    );
  }, [tasks, activeProject, taskQuery]);

  const requestDeleteProject = (project) => {
    if (!canDeleteProject || !project) return;
    setConfirmState({ type: 'project', id: project.id, name: project.name || project.id });
  };

  const requestDeleteTask = (task) => {
    if (!canDeleteTask || !task) return;
    setConfirmState({ type: 'task', id: task.id, name: task.name || task.id });
  };

  const confirmDelete = () => {
    if (!confirmState) return;
    if (confirmState.type === 'project') {
      onDelete?.(confirmState.id);
      setActiveProject(null);
    } else if (confirmState.type === 'task') {
      onDeleteTask?.(confirmState.id);
    }
    setConfirmState(null);
  };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 200, maxWidth: 340 }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search projects..." style={{ ...inputStyle, paddingLeft: 36 }} />
        </div>
        <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} style={{ ...inputStyle, width: 'auto', minWidth: 140 }}>
          <option value="All">All Status</option>
          {PROJECT_STATUS.map(s => <option key={s}>{s}</option>)}
        </select>
        <div style={{ flex: 1 }} />
      </div>
      <DataTable tableKey="projects" enableHeaderTools columns={[
        { label: 'Sr.No', key: 'srNo', style: { width: 48 } },
        { label: 'Project', key: 'name', filterValue: p => `${p.name || ''} ${p.description || ''}`, render: p => <div><div style={{ fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>{unseenProjectIds?.has?.(String(p.id || '')) && <AssignmentDot />}{p.name}</div><div style={{ fontSize: 11, color: '#94a3b8' }}>{p.description?.slice(0, 60) || '-'}</div></div>, nowrap: false, maxWidth: 280 },
        { label: 'ID', key: 'id', render: p => <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#64748b' }}>{p.id}</span> },
        { label: 'Assigned', key: 'assigned', sortValue: p => `${p.team || ''} ${p.owner || ''}`, filterValue: p => `${p.team || ''} ${p.owner || ''}`, render: p => {
          const parts = [];
          if (p.team) parts.push(`Teams: ${p.team}`);
          if (p.owner) parts.push(`Users: ${p.owner}`);
          return parts.join(' | ') || '-';
        } },
        { label: 'Priority', key: 'priority', render: p => <PriorityBadge priority={p.priority} /> },
        { label: 'Status', key: 'status', render: p => <StatusBadge status={p.status} /> },
        { label: 'Progress', key: 'progress', render: p => <span style={{ fontWeight: 600 }}>{p.progress || 0}%</span> },
        {
          label: 'Tasks',
          key: 'tasksCount',
          sortValue: p => tasks.filter(t => t.projectId === p.id).length,
          filterValue: p => {
            const pt = tasks.filter(t => t.projectId === p.id);
            const done = pt.filter(t => t.status === 'Completed').length;
            return `${done}/${pt.length}`;
          },
          render: p => {
            const pt = tasks.filter(t => t.projectId === p.id);
            const done = pt.filter(t => t.status === 'Completed').length;
            return <span style={{ color: '#64748b' }}>{done}/{pt.length}</span>;
          },
        },
        {
          label: 'Actions',
          style: { width: 170 },
          render: p => (
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <button onClick={e => { e.stopPropagation(); setShowAttachmentsForProject(p); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><Paperclip size={12} />Files</button>
              <button onClick={e => { e.stopPropagation(); onEdit(p); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><Edit3 size={12} />Edit</button>
            </div>
          )
        },
      ]} data={filtered.map((project, index) => ({ ...project, srNo: index + 1 }))} onRowClick={(p) => { onProjectSeen?.(p.id); setActiveProject(p); setTaskQuery(''); }} emptyMsg="No projects found" />
      {activeProject && (
      <div style={{ marginTop: 14, border: '1px solid #e2e8f0', borderRadius: 12, background: '#fff', overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12, padding: '12px 14px', borderBottom: '1px solid #e2e8f0', background: '#f8fafc' }}>
          <div style={{ fontSize: 15, fontWeight: 700, color: '#0f172a' }}>Project Tasks - {activeProject?.name || ''}</div>
          <button onClick={() => setActiveProject(null)} style={{ ...btnSecondary, padding: '6px 10px', fontSize: 12 }}>Close</button>
        </div>
        <div style={{ padding: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 10 }}>
          <div style={{ position: 'relative', flex: 1 }}>
            <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
            <input value={taskQuery} onChange={e => setTaskQuery(e.target.value)} placeholder="Search project tasks..." style={{ ...inputStyle, paddingLeft: 36 }} />
          </div>
          <div style={{ fontSize: 12, color: '#64748b' }}>{projectTasks.length} task{projectTasks.length !== 1 ? 's' : ''}</div>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 10 }}>
          <div style={{ fontSize: 12, color: '#64748b' }}>
            Teams: <b style={{ color: '#334155' }}>{activeProject?.team || '-'}</b> | Users: <b style={{ color: '#334155' }}>{activeProject?.owner || '-'}</b>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button onClick={() => setShowAttachmentsForProject(activeProject)} style={{ ...btnSecondary, padding: '6px 12px', fontSize: 12 }}><Paperclip size={12} />Attachments</button>
            <button onClick={() => activeProject && onEdit(activeProject)} style={{ ...btnSecondary, padding: '6px 12px', fontSize: 12 }}><Edit3 size={12} />Edit Project</button>
            <button
              onClick={() => requestDeleteProject(activeProject)}
              title={canDeleteProject ? 'Delete project' : 'Only Admin can delete projects'}
              disabled={!canDeleteProject}
              style={{ ...btnSecondary, padding: '6px 12px', fontSize: 12, color: '#ef4444', borderColor: '#fca5a5', opacity: canDeleteProject ? 1 : 0.45, cursor: canDeleteProject ? 'pointer' : 'not-allowed' }}
            >
              <Trash2 size={12} />Delete Project
            </button>
          </div>
        </div>
        <DataTable
          tableKey="projectTasks"
          enableHeaderTools
          columns={[
            { label: 'Sr.No', key: 'srNo', style: { width: 48 } },
            { label: 'Task', key: 'name', render: t => <div style={{ fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>{unseenTaskIds?.has?.(String(t.id || '')) && <AssignmentDot />}{t.name}</div>, nowrap: false, maxWidth: 260 },
            { label: 'ID', key: 'id', render: t => <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#64748b' }}>{t.id}</span> },
            { label: 'Assigned To', key: 'assignedTo' },
            { label: 'Due Date', key: 'dueDate', sortValue: t => t.dueDate, filterValue: t => t.dueDate?.split(' ')[0] || '-', render: t => t.dueDate?.split(' ')[0] || '-' },
            { label: 'Time Left', key: 'timeLeft', sortValue: t => timeLeft(t.dueDate), filterValue: t => timeLeft(t.dueDate), render: t => <span style={{ color: timeLeft(t.dueDate) === 'Overdue' ? '#ef4444' : '#475569' }}>{timeLeft(t.dueDate)}</span> },
            { label: 'Status', key: 'status', render: t => <StatusBadge status={t.status} /> },
            {
              label: 'Actions',
              style: { width: 170 },
              render: t => (
                <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                  <button onClick={(e) => { e.stopPropagation(); onEditTask?.(t); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><Edit3 size={12} />Edit</button>
                  <button
                    onClick={e => { e.stopPropagation(); requestDeleteTask(t); }}
                    title={canDeleteTask ? 'Delete task' : 'Only Admin/Manager can delete tasks'}
                    disabled={!canDeleteTask}
                    style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12, color: '#ef4444', borderColor: '#fca5a5', opacity: canDeleteTask ? 1 : 0.45, cursor: canDeleteTask ? 'pointer' : 'not-allowed' }}
                  >
                    <Trash2 size={12} />Delete
                  </button>
                </div>
              )
            },
          ]}
          data={projectTasks.map((task, index) => ({ ...task, srNo: index + 1 }))}
          onRowClick={(t) => onEditTask?.(t)}
          emptyMsg="No tasks found for this project"
        />
        </div>
      </div>
      )}
      <Modal open={!!confirmState} onClose={() => setConfirmState(null)} title="Confirm Delete" width={460}>
        <div style={{ color: '#475569', fontSize: 13, lineHeight: 1.6 }}>
          {confirmState?.type === 'project'
            ? `Delete project "${confirmState?.name}"? All linked tasks will be detached from this project.`
            : `Delete task "${confirmState?.name}" from this project?`}
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 18 }}>
          <button onClick={() => setConfirmState(null)} style={btnSecondary}>Cancel</button>
          <button onClick={confirmDelete} style={btnDanger}>Delete</button>
        </div>
      </Modal>
      <AttachmentManager open={!!showAttachmentsForProject} onClose={() => setShowAttachmentsForProject(null)} itemId={showAttachmentsForProject?.id} isSubtask={false} itemName={showAttachmentsForProject?.name} actor={currentUser} isAdmin={isAdmin} />
    </div>
  );
}
function RecurringPage({ recurring, employees, projects, currentUser, isAdmin, canDelete, onAdd, onUpdate, onDelete }) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [selectedId, setSelectedId] = useState(null);
  const [confirmDeleteRec, setConfirmDeleteRec] = useState(null);
  const FREQ_OPTIONS = ['Daily', 'Weekly', 'Monthly', 'Annually', 'Custom'];

  const freqColor = { Daily: '#22c55e', Weekly: '#3b82f6', Monthly: '#f59e0b', Annually: '#8b5cf6', Custom: '#0d9488' };

  const handleSave = (data) => {
    if (editing) {
      onUpdate(editing.id, data);
    } else {
      onAdd({ ...data, assignedBy: currentUser });
    }
    setShowForm(false);
    setEditing(null);
  };

  const handleEdit = (r) => {
    setEditing(r);
    setShowForm(true);
  };

  const handleDelete = (id) => {
    if (!canDelete) return;
    setConfirmDeleteRec(id);
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <div>
          <div style={{ display: 'flex', gap: 12 }}>
            {FREQ_OPTIONS.map(f => {
              const cnt = recurring.filter(r => r.frequency === f).length;
              return cnt > 0 ? (
                <span key={f} style={{ background: `${freqColor[f]}15`, color: freqColor[f], padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600 }}>
                  {f}: {cnt}
                </span>
              ) : null;
            })}
          </div>
        </div>
        <button onClick={() => { setEditing(null); setShowForm(true); }} style={btnPrimary}><Plus size={14} />New Template</button>
      </div>

      {/* Template Form */}
      {showForm && (
        <div style={{ background: '#f8fafc', border: '1px solid #e2e8f0', borderRadius: 12, padding: 20, marginBottom: 20 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>{editing ? 'Edit Template' : 'Create Recurring Template'}</h3>
            <button onClick={() => { setShowForm(false); setEditing(null); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#64748b' }}><X size={18} /></button>
          </div>
          <RecurringTemplateForm
            template={editing}
            employees={employees}
            projects={projects}
            currentUser={currentUser}
            onSave={handleSave}
            onCancel={() => { setShowForm(false); setEditing(null); }}
          />
        </div>
      )}

      {/* Templates Table */}
      <div style={{ border: '1px solid #e2e8f0', borderRadius: 10, overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: '#f1f5f9' }}>
              {['ID', 'Task Name', 'Description', 'Frequency', 'Next Run', 'Assigned To', 'Duration', 'Actions'].map((h, i) => (
                <th key={i} style={{ padding: '10px 14px', textAlign: 'left', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0', whiteSpace: 'nowrap' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {recurring.length === 0 ? (
              <tr><td colSpan={8} style={{ padding: 40, textAlign: 'center', color: '#94a3b8' }}>
                <Repeat size={32} style={{ marginBottom: 8, opacity: 0.3 }} /><br />No recurring templates. Create one to auto-generate tasks.
              </td></tr>
            ) : recurring.map(r => (
              <tr key={r.id}
                onClick={() => setSelectedId(r.id)}
                style={{ borderBottom: '1px solid #f1f5f9', cursor: 'pointer', background: selectedId === r.id ? '#f0fdfa' : 'transparent', transition: 'background 0.15s' }}
                onMouseEnter={e => { if (selectedId !== r.id) e.currentTarget.style.background = '#f8fafc'; }}
                onMouseLeave={e => { if (selectedId !== r.id) e.currentTarget.style.background = 'transparent'; }}>
                <td style={{ padding: '10px 14px' }}><span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 11, color: '#94a3b8' }}>{r.id}</span></td>
                <td style={{ padding: '10px 14px', fontWeight: 600 }}>{r.taskName}</td>
                <td style={{ padding: '10px 14px', color: '#64748b', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.description || ' - '}</td>
                <td style={{ padding: '10px 14px' }}>
                  <span style={{ background: `${freqColor[r.frequency] || '#64748b'}15`, color: freqColor[r.frequency] || '#64748b', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600 }}>
                    {r.frequency}{r.frequency === 'Custom' && r.customInterval ? ` (${r.customInterval} ${r.customUnit})` : ''}
                  </span>
                </td>
                <td style={{ padding: '10px 14px', whiteSpace: 'nowrap' }}>{r.nextRun}</td>
                <td style={{ padding: '10px 14px' }}>{r.assignedTo}</td>
                <td style={{ padding: '10px 14px', whiteSpace: 'nowrap' }}>{r.durationVal} {r.durationUnit}</td>
                <td style={{ padding: '10px 14px' }}>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button onClick={e => { e.stopPropagation(); handleEdit(r); }} style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#475569' }}><Edit3 size={12} /></button>
                    {canDelete && <button onClick={e => { e.stopPropagation(); handleDelete(r.id); }} style={{ background: 'none', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#ef4444' }}><Trash2 size={12} /></button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <ConfirmDialog
        open={confirmDeleteRec !== null}
        title="Delete Recurring Template"
        message="Delete this recurring template? All generated tasks from this template will also be removed."
        confirmLabel="Delete"
        onConfirm={() => { onDelete(confirmDeleteRec); if (selectedId === confirmDeleteRec) setSelectedId(null); setConfirmDeleteRec(null); }}
        onCancel={() => setConfirmDeleteRec(null)}
      />
    </div>
  );
}

//  Recurring Template Form //
function RecurringTemplateForm({ template, employees, projects, currentUser, onSave, onCancel }) {
  const [form, setForm] = useState(template || {
    taskName: '', description: '', assignedTo: employees[0]?.name || '', assignedBy: currentUser,
    durationVal: '1', durationUnit: 'Days', frequency: 'Daily',
    nextRun: fmtFull(now), customInterval: '1', customUnit: 'Days', projectId: '', attachmentPaths: [],
  });
  const [pendingFiles, setPendingFiles] = useState(Array.isArray(template?.attachmentPaths) ? template.attachmentPaths : []);
  const [manualPath, setManualPath] = useState('');

  useEffect(() => {
    setForm(template || {
      taskName: '', description: '', assignedTo: employees[0]?.name || '', assignedBy: currentUser,
      durationVal: '1', durationUnit: 'Days', frequency: 'Daily',
      nextRun: fmtFull(now), customInterval: '1', customUnit: 'Days', projectId: '', attachmentPaths: [],
    });
    setPendingFiles(Array.isArray(template?.attachmentPaths) ? template.attachmentPaths : []);
    setManualPath('');
  }, [template, employees, currentUser]);

  const isCustom = form.frequency === 'Custom';
  const isDaily = form.frequency === 'Daily';
  const nextRunDateValue = toDateInputValue(form.nextRun);
  const fileLabel = (p) => {
    const parts = p.split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const pickFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setPendingFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualPath = () => {
    const paths = parseFilePathsFromText(manualPath);
    if (!paths.length) return;
    setPendingFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualPath('');
  };

  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Task Name" required>
          <input value={form.taskName || ''} onChange={e => setForm(p => ({ ...p, taskName: e.target.value }))} style={inputStyle} placeholder="Task name for generated tasks" />
        </FormField>
        <FormField label="Description">
          <input value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} style={inputStyle} placeholder="Optional description" />
        </FormField>
        <FormField label="Assigned To">
          <select value={form.assignedTo || ''} onChange={e => setForm(p => ({ ...p, assignedTo: e.target.value }))} style={inputStyle}>
            {employees.map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
          </select>
        </FormField>
        <FormField label="Assigned By">
          <select value={form.assignedBy || currentUser} onChange={e => setForm(p => ({ ...p, assignedBy: e.target.value }))} style={inputStyle}>
            {employees.map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
          </select>
        </FormField>
        <FormField label="Frequency">
          <select value={form.frequency || 'Daily'} onChange={e => setForm(p => ({ ...p, frequency: e.target.value }))} style={inputStyle}>
            {['Daily', 'Weekly', 'Monthly', 'Annually', 'Custom'].map(f => <option key={f}>{f}</option>)}
          </select>
        </FormField>
        <FormField label="Next Run Date">
          <input
            type="date"
            value={nextRunDateValue}
            onChange={e => {
              if (!e.target.value) {
                setForm(p => ({ ...p, nextRun: '' }));
                return;
              }
              const d = e.target.value.split('-');
              setForm(p => ({ ...p, nextRun: `${d[2]}-${d[1]}-${d[0].slice(-2)} 09:00` }));
            }}
            style={inputStyle}
          />
        </FormField>
        <FormField label="Duration">
          <div style={{ display: 'flex', gap: 8 }}>
            <input type="number" value={form.durationVal || '1'} onChange={e => setForm(p => ({ ...p, durationVal: e.target.value }))}
              style={{ ...inputStyle, width: 70 }} min="1" disabled={isDaily} />
            <select value={form.durationUnit || 'Days'} onChange={e => setForm(p => ({ ...p, durationUnit: e.target.value }))}
              style={{ ...inputStyle, flex: 1 }} disabled={isDaily}>
              <option>Hours</option><option>Days</option><option>Weeks</option>
            </select>
          </div>
        </FormField>
        {isCustom && (
          <FormField label="Custom Interval">
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <span style={{ fontSize: 12, color: '#64748b' }}>Every</span>
              <input type="number" value={form.customInterval || '1'} onChange={e => setForm(p => ({ ...p, customInterval: e.target.value }))} style={{ ...inputStyle, width: 60 }} min="1" />
              <select value={form.customUnit || 'Days'} onChange={e => setForm(p => ({ ...p, customUnit: e.target.value }))} style={{ ...inputStyle, flex: 1 }}>
                <option>Days</option><option>Weeks</option><option>Months</option>
              </select>
            </div>
          </FormField>
        )}
        <FormField label="Project (optional)">
          <select value={form.projectId || ''} onChange={e => setForm(p => ({ ...p, projectId: e.target.value }))} style={inputStyle}>
            <option value="">No Project</option>
            {projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </FormField>
      </div>

      <div style={{ marginTop: 4 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 6 }}>Attach Files (optional)</div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8, alignItems: 'center' }}>
          <input
            value={manualPath}
            onChange={e => setManualPath(e.target.value)}
            onPaste={async (e) => {
              const pastedPaths = await getPastedAttachmentPaths(e);
              if (!pastedPaths.length) return;
              e.preventDefault();
              setPendingFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
            }}
            placeholder="Paste file path(s) here or press Ctrl+V after copying files"
            style={{ ...inputStyle, flex: 1 }}
          />
          <button type="button" onClick={addManualPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
        </div>
        <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
          <button type="button" onClick={pickFiles} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} />Add Files</button>
        </div>
        {pendingFiles.length > 0 && (
          <div style={{ marginTop: 8, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {pendingFiles.map((p, i) => (
              <span key={`${p}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#eef2ff', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
                {fileLabel(p)}
                <button
                  type="button"
                  onClick={() => setPendingFiles(prev => prev.filter((_, idx) => idx !== i))}
                  style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}
                >
                  x
                </button>
              </span>
            ))}
          </div>
        )}
      </div>

      {isDaily && (
        <div style={{ background: '#fef3c7', border: '1px solid #fde68a', borderRadius: 8, padding: '8px 12px', marginTop: 12, fontSize: 12, color: '#92400e' }}>
          Daily templates generate a new task each day and submit previous open task for assignor/admin archive approval (with 1-day extension option).
        </div>
      )}

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 16 }}>
        <button onClick={onCancel} style={btnSecondary}>Cancel</button>
        <button onClick={() => { if (form.taskName?.trim()) onSave({ ...form, nextRun: form.nextRun || fmtFull(now), attachmentPaths: pendingFiles }); }} style={btnPrimary}>{template ? 'Update' : 'Create'} Template</button>
      </div>
    </div>
  );
}

function CalendarPage({ tasks }) {
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth());
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1).getDay();
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const tasksByDay = useMemo(() => {
    const map = {};
    tasks.forEach(t => {
      if (!t.dueDate) return;
      try {
        const p = t.dueDate.split(' ')[0].split('-');
        if (parseInt(p[1]) - 1 === month && 2000 + parseInt(p[2]) === year) {
          const d = parseInt(p[0]);
          if (!map[d]) map[d] = [];
          map[d].push(t.name);
        }
      } catch {}
    });
    return map;
  }, [tasks, month, year]);
  const prev = () => { if (month === 0) { setMonth(11); setYear(y => y - 1); } else setMonth(m => m - 1); };
  const next = () => { if (month === 11) { setMonth(0); setYear(y => y + 1); } else setMonth(m => m + 1); };
  return (
    <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
        <button onClick={prev} style={btnSecondary}><ChevronLeft size={16} /> Prev</button>
        <h3 style={{ margin: 0, fontSize: 17, fontWeight: 700 }}>{months[month]} {year}</h3>
        <button onClick={next} style={btnSecondary}>Next <ChevronRight size={16} /></button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 1, background: '#e2e8f0', borderRadius: 8, overflow: 'hidden' }}>
        {['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map(d => <div key={d} style={{ background: '#f1f5f9', padding: '10px 8px', textAlign: 'center', fontSize: 12, fontWeight: 600, color: '#475569' }}>{d}</div>)}
        {Array.from({ length: firstDay }).map((_, i) => <div key={`e${i}`} style={{ background: '#fafafa', minHeight: 80 }} />)}
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          const isToday = day === now.getDate() && month === now.getMonth() && year === now.getFullYear();
          const dt = tasksByDay[day] || [];
          return (
            <div key={day} style={{ background: isToday ? '#f0fdfa' : '#fff', padding: 8, minHeight: 80 }}>
              <span style={{ fontSize: 12, fontWeight: isToday ? 700 : 400, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 24, height: 24, borderRadius: '50%', background: isToday ? '#0d9488' : 'transparent', color: isToday ? '#fff' : '#475569' }}>{day}</span>
              {dt.slice(0, 2).map((n, ti) => <div key={ti} style={{ fontSize: 10, padding: '2px 4px', marginTop: 2, borderRadius: 3, background: '#3b82f615', color: '#3b82f6', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n}</div>)}
              {dt.length > 2 && <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 2 }}>+{dt.length - 2} more</div>}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function IssuesPage({ issues, onAdd, onEdit, onDelete, currentUser, isAdmin, unseenIssueIds }) {
  const [query, setQuery] = useState('');
  const [showAttachmentsForIssue, setShowAttachmentsForIssue] = useState(null);
  const [chatIssue, setChatIssue] = useState(null);
  const [confirmDeleteIssue, setConfirmDeleteIssue] = useState(null);
  const filteredIssues = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return issues;
    return issues.filter(i =>
      i.title?.toLowerCase().includes(q) ||
      i.id?.toLowerCase().includes(q) ||
      i.assignedTo?.toLowerCase().includes(q) ||
      i.status?.toLowerCase().includes(q) ||
      i.priority?.toLowerCase().includes(q)
    );
  }, [issues, query]);

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
        <div style={{ position: 'relative', flex: 1, minWidth: 220, maxWidth: 340 }}>
          <Search size={16} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: '#94a3b8' }} />
          <input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search issues..." style={{ ...inputStyle, paddingLeft: 36 }} />
        </div>
        <div style={{ flex: 1 }} />
        <button onClick={onAdd} style={btnPrimary}><Plus size={14} />Report Issue</button>
      </div>
      <DataTable tableKey="issues" enableHeaderTools columns={[
        { label: 'Sr.No', key: 'srNo', style: { width: 48 } },
        { label: 'Issue', key: 'title', filterValue: r => `${r.title || ''} ${r.id || ''}`, render: r => <div><div style={{ fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 6 }}>{unseenIssueIds?.has?.(String(r.id || '')) && <AssignmentDot />}{r.title}</div><div style={{ fontSize: 11, color: '#94a3b8' }}>{r.id}</div></div>, nowrap: false, maxWidth: 260 },
        { label: 'Priority', key: 'priority', render: r => <PriorityBadge priority={r.priority} /> },
        { label: 'Status', key: 'status', render: r => <StatusBadge status={r.status} /> },
        { label: 'Assigned To', key: 'assignedTo' },
        { label: 'Reported', key: 'dateReported' },
        {
          label: 'Actions',
          style: { width: 250 },
          render: r => {
            const canDelete = !!isAdmin || String(r.reportedBy || '').toLowerCase() === String(currentUser || '').toLowerCase();
            return (
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button onClick={e => { e.stopPropagation(); setShowAttachmentsForIssue(r); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><Paperclip size={12} />Files</button>
                <button onClick={e => { e.stopPropagation(); setChatIssue(r); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><MessageSquare size={12} />Chat</button>
                <button onClick={e => { e.stopPropagation(); onEdit(r); }} style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12 }}><Edit3 size={12} />Edit</button>
                <button
                  onClick={e => { e.stopPropagation(); if (canDelete) setConfirmDeleteIssue(r); }}
                  title={canDelete ? 'Delete issue' : 'Only Admin or issue creator can delete'}
                  disabled={!canDelete}
                  style={{ ...btnSecondary, padding: '5px 10px', fontSize: 12, color: '#ef4444', borderColor: '#fca5a5', opacity: canDelete ? 1 : 0.45, cursor: canDelete ? 'pointer' : 'not-allowed' }}
                >
                  <Trash2 size={12} />Delete
                </button>
              </div>
            );
          }
        },
      ]} data={filteredIssues.map((issue, index) => ({ ...issue, srNo: index + 1 }))} onRowClick={onEdit} emptyMsg="No issues" />
      <AttachmentManager open={!!showAttachmentsForIssue} onClose={() => setShowAttachmentsForIssue(null)} itemId={showAttachmentsForIssue?.id} isSubtask={false} itemName={showAttachmentsForIssue?.title} actor={currentUser} isAdmin={isAdmin} />
      <IssueCommentsModal open={!!chatIssue} onClose={() => setChatIssue(null)} issue={chatIssue} currentUser={currentUser} isAdmin={isAdmin} />
      <ConfirmDialog
        open={!!confirmDeleteIssue}
        title="Delete Issue"
        message={`Are you sure you want to delete "${confirmDeleteIssue?.title}"? This action cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={() => { onDelete?.(confirmDeleteIssue.id); setConfirmDeleteIssue(null); }}
        onCancel={() => setConfirmDeleteIssue(null)}
      />
    </div>
  );
}

function SopPage({ sops, employees, currentUser, isAdmin, onAdd, onDelete }) {
  const [showDetail, setShowDetail] = useState(null);
  const [form, setForm] = useState({ task: '', description: '', detail: '', assignedTo: '', attachmentPath: '' });
  const [msg, setMsg] = useState('');
  const visibleRows = isAdmin
    ? sops
    : sops.filter(s => String(s.assignedTo || '').toLowerCase() === String(currentUser || '').toLowerCase());
  const indexedRows = visibleRows.map((r, idx) => ({ ...r, srNo: idx + 1 }));

  const pickFile = async () => {
    if (!isElectron) return;
    const paths = await window.electronAPI.openFile();
    if (paths?.length) setForm(prev => ({ ...prev, attachmentPath: paths[0] }));
  };

  const submit = async () => {
    if (!form.task.trim() || !form.assignedTo.trim()) {
      setMsg('Task and Assigned To are required.');
      return;
    }
    const id = await onAdd?.({ ...form, assignedBy: currentUser });
    if (!id) {
      setMsg('Unable to assign SOP.');
      return;
    }
    setForm({ task: '', description: '', detail: '', assignedTo: '', attachmentPath: '' });
    setMsg('SOP assigned.');
  };

  return (
    <div>
      {isAdmin && (
        <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 16, marginBottom: 14 }}>
          <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 10 }}>Assign SOP</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <input value={form.task} onChange={e => setForm(p => ({ ...p, task: e.target.value }))} placeholder="Task" style={inputStyle} />
            <select value={form.assignedTo} onChange={e => setForm(p => ({ ...p, assignedTo: e.target.value }))} style={inputStyle}>
              <option value="">Assigned To</option>
              {employees.filter(e => e.role === 'Manager' || isBaseRole(e.role)).map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
            </select>
            <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Short Description" style={{ ...inputStyle, minHeight: 52, resize: 'vertical' }} />
            <textarea value={form.detail} onChange={e => setForm(p => ({ ...p, detail: e.target.value }))} placeholder="Detailed SOP" style={{ ...inputStyle, minHeight: 52, resize: 'vertical' }} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 8, alignItems: 'center' }}>
            <input value={form.attachmentPath} onChange={e => setForm(p => ({ ...p, attachmentPath: e.target.value }))} placeholder="Attachment path (optional)" style={{ ...inputStyle, flex: 1 }} />
            <button onClick={pickFile} style={{ ...btnSecondary, padding: '8px 12px' }}><Paperclip size={13} /> Pick</button>
            <button onClick={submit} style={btnPrimary}>Assign SOP</button>
          </div>
          {msg && <div style={{ marginTop: 8, fontSize: 12, color: /required|unable/i.test(msg) ? '#dc2626' : '#0d9488' }}>{msg}</div>}
        </div>
      )}
      <DataTable
        columns={[
          { label: 'Sr.No', key: 'srNo', style: { width: 70 } },
          { label: 'Task', key: 'task' },
          { label: 'Description', key: 'description', nowrap: false, maxWidth: 340 },
          {
            label: 'Attachment',
            render: r => r.attachmentPath
              ? <button onClick={(e) => { e.stopPropagation(); if (isElectron) window.electronAPI.openPath(r.attachmentPath); }} style={{ ...btnSecondary, padding: '4px 10px', fontSize: 12 }}>Open</button>
              : <span style={{ color: '#94a3b8', fontSize: 12 }}>-</span>,
            style: { width: 120 },
          },
          ...(isAdmin ? [{
            label: '',
            render: r => <button onClick={(e) => { e.stopPropagation(); onDelete?.(r.id); }} style={{ ...btnSecondary, padding: '4px 10px', fontSize: 12, color: '#dc2626', borderColor: '#fecaca' }}>Delete</button>,
            style: { width: 90 },
          }] : []),
        ]}
        data={indexedRows}
        onRowClick={(row) => setShowDetail(row)}
        emptyMsg="No SOP assigned"
      />

      <Modal open={!!showDetail} onClose={() => setShowDetail(null)} title={`SOP Detail - ${showDetail?.task || ''}`} width={760}>
        <div style={{ display: 'grid', gap: 10 }}>
          <div><b>Task:</b> {showDetail?.task || '-'}</div>
          <div><b>Description:</b> {showDetail?.description || '-'}</div>
          <div style={{ whiteSpace: 'pre-wrap' }}><b>Detailed SOP:</b>{'\n'}{showDetail?.detail || '-'}</div>
          <div><b>Assigned To:</b> {showDetail?.assignedTo || '-'} | <b>Assigned By:</b> {showDetail?.assignedBy || '-'}</div>
          <div><b>Updated On:</b> {showDetail?.updatedOn || '-'}</div>
          {showDetail?.attachmentPath && (
            <div>
              <button onClick={() => { if (isElectron) window.electronAPI.openPath(showDetail.attachmentPath); }} style={btnPrimary}>Open Attachment</button>
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
}

function ReportsPage({ tasks, projects, issues, employees }) {
  const nonAdminEmployees = employees.filter(e => !isAdminRole(e.role));
  const nowTs = Date.now();
  const monthLabel = (d) => d.toLocaleString('en-IN', { month: 'short', year: 'numeric' });

  const analyzedTasks = useMemo(() => {
    return tasks.map((t) => {
      const due = parseAppDateTime(t.dueDate);
      const completedAt = isTaskCompleted(t) ? (parseAppDateTime(t.completedOn) || parseAppDateTime(t.archivedOn)) : null;
      const dueEnd = due ? new Date(due.getFullYear(), due.getMonth(), due.getDate(), 23, 59, 59, 999) : null;
      const overdue = dueEnd ? (completedAt ? completedAt.getTime() > dueEnd.getTime() : nowTs > dueEnd.getTime()) : false;
      const finishedBefore = !!(due && completedAt && completedAt.getTime() < due.getTime());
      const finishedOnTime = !!(dueEnd && completedAt && completedAt.getTime() <= dueEnd.getTime() && !finishedBefore);
      return { ...t, due, completedAt, overdue, finishedBefore, finishedOnTime };
    });
  }, [tasks, nowTs]);

  const monthlyBacklog = useMemo(() => {
    const bucket = new Map();
    for (const t of analyzedTasks) {
      if (!t.overdue || !t.due) continue;
      const key = `${t.due.getFullYear()}-${String(t.due.getMonth() + 1).padStart(2, '0')}`;
      const prev = bucket.get(key) || { month: monthLabel(t.due), count: 0 };
      prev.count += 1;
      bucket.set(key, prev);
    }
    return [...bucket.entries()]
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([, v]) => v);
  }, [analyzedTasks]);

  const employeeRows = useMemo(() => {
    return nonAdminEmployees.map((emp) => {
      const mine = analyzedTasks.filter(t => t.assignedTo === emp.name);
      return {
        employee: emp.name,
        assigned: mine.length,
        finishedBefore: mine.filter(t => t.finishedBefore).length,
        finishedOnTime: mine.filter(t => t.finishedOnTime).length,
        overdue: mine.filter(t => t.overdue).length,
      };
    });
  }, [analyzedTasks, nonAdminEmployees]);

  const totalAssigned = employeeRows.reduce((sum, r) => sum + r.assigned, 0);
  const totalBefore = employeeRows.reduce((sum, r) => sum + r.finishedBefore, 0);
  const totalOnTime = employeeRows.reduce((sum, r) => sum + r.finishedOnTime, 0);
  const totalOverdue = employeeRows.reduce((sum, r) => sum + r.overdue, 0);

  return (
    <div style={{ display: 'grid', gap: 20 }}>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 18 }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700 }}>Monthly Backlog Report</h3>
        <DataTable
          columns={[
            { label: 'Month', key: 'month' },
            { label: 'Overdue Tasks (Assigned)', key: 'count' },
          ]}
          data={monthlyBacklog}
          emptyMsg="No backlog data"
        />
      </div>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 18 }}>
        <h3 style={{ margin: '0 0 14px', fontSize: 15, fontWeight: 700 }}>Employee Wise Report</h3>
        <DataTable
          columns={[
            { label: 'Employee', key: 'employee' },
            { label: 'Task Assigned', key: 'assigned' },
            { label: 'Finished Before Time', key: 'finishedBefore' },
            { label: 'Finished On Time', key: 'finishedOnTime' },
            { label: 'Overdue Attributed', key: 'overdue' },
          ]}
          data={employeeRows}
          emptyMsg="No employee data"
        />
        <div style={{ marginTop: 10, fontSize: 12, color: '#64748b' }}>
          Totals: Assigned {totalAssigned} | Before Time {totalBefore} | On Time {totalOnTime} | Overdue {totalOverdue}
        </div>
      </div>
    </div>
  );
}

function EmployeesPage({ employees, setEmployees, teams, setTeams, currentUser }) {
  const [showAdd, setShowAdd] = useState(false);
  const [showAddTeam, setShowAddTeam] = useState(false);
  const [showEditEmployee, setShowEditEmployee] = useState(false);
  const [newTeam, setNewTeam] = useState('');
  const [teamMsg, setTeamMsg] = useState('');
  const [empMsg, setEmpMsg] = useState('');
  const [teamActionMsg, setTeamActionMsg] = useState('');
  const [empActionMsg, setEmpActionMsg] = useState('');
  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [confirmDeleteEmp, setConfirmDeleteEmp] = useState(null);
  const [activeTeam, setActiveTeam] = useState('');
  const [selectedEmployeeName, setSelectedEmployeeName] = useState('');
  const [newEmp, setNewEmp] = useState({ name: '', role: BASE_ROLE, team: '' });
  const [editEmp, setEditEmp] = useState({ oldName: '', name: '', role: BASE_ROLE, team: '' });
  const currentUserRole = displayRole(employees.find(e => String(e.name || '').toLowerCase() === String(currentUser || '').toLowerCase())?.role || BASE_ROLE);
  const canChangeManagerExecutiveRoles = isAdminRole(currentUserRole) || currentUserRole === 'Manager';
  const employeeRoleOptions = isAdminRole(currentUserRole) ? [BASE_ROLE, 'Manager', 'Admin'] : [BASE_ROLE, 'Manager'];
  const managedEmployees = useMemo(
    () => employees.filter(e => String(e.name || '').trim().toLowerCase() !== SYSTEM_ADMIN_NAME.toLowerCase()),
    [employees]
  );
  const isManagerExecutiveRole = (role) => ['manager', 'executive', 'employee'].includes(String(role || '').trim().toLowerCase());

  const addUniqueTeamLocal = (teamName) => {
    const trimmed = (teamName || '').trim();
    if (!trimmed) return;
    setTeams(prev => {
      if (prev.some(t => t.toLowerCase() === trimmed.toLowerCase())) return prev;
      return [...prev, trimmed].sort((a, b) => a.localeCompare(b));
    });
  };

  const refreshOrgData = async () => {
    if (!isElectron) return true;
    try {
      const [empRes, teamRes] = await Promise.allSettled([
        window.electronAPI.employees.list(),
        window.electronAPI.teams.list(),
      ]);

      if (empRes.status === 'fulfilled' && Array.isArray(empRes.value)) {
        const parsed = mapEmployeeRows(empRes.value);
        if (parsed.length) setEmployees(parsed);
      } else if (empRes.status === 'witheld') {
        console.error('employees.list failed:', empRes.reason);
      }

      if (teamRes.status === 'fulfilled' && Array.isArray(teamRes.value)) {
        const nextTeams = teamRes.value.map(r => (r.team_name || '').trim()).filter(Boolean);
        setTeams([...new Set(nextTeams)].sort((a, b) => a.localeCompare(b)));
      } else if (teamRes.status === 'witheld') {
        console.error('teams.list failed:', teamRes.reason);
      }
      return true;
    } catch (err) {
      console.error('refreshOrgData failed:', err);
      return false;
    }
  };

  useEffect(() => {
    if (isElectron) refreshOrgData();
  }, []);

  const addEmp = async () => {
    const userName = newEmp.name.trim();
    setEmpMsg('');
    const nameEquals = (a, b) => (a || '').trim().toLowerCase() === (b || '').trim().toLowerCase();
    if (!userName) {
      setEmpMsg('Please enter employee name.');
      return;
    }
    if (nameEquals(userName, SYSTEM_ADMIN_NAME)) {
      setEmpMsg('Built-in Admin is reserved for app recovery and cannot be added here.');
      return;
    }
    if (employees.some(e => nameEquals(e.name, userName))) {
      setEmpMsg('User already exist');
      refreshOrgData();
      return;
    }
    if (isElectron) {
      const res = await window.electronAPI.employees.add({ ...newEmp, name: userName, actor: currentUser });
      if (!res?.ok) {
        setEmpMsg(res?.error || 'Unable to add employee.');
        await refreshOrgData();
        return;
      }
    }
    setEmployees(prev => [...prev, { ...newEmp, name: userName }]);
    addUniqueTeamLocal(newEmp.team);
    if (isElectron) refreshOrgData();
    setNewEmp({ name: '', role: BASE_ROLE, team: '' });
    setEmpMsg('');
    setShowAdd(false);
  };

  const addTeam = async () => {
    const baseName = newTeam.trim();
    setTeamMsg('');
    if (!baseName) {
      setTeamMsg('Please enter a team name.');
      return;
    }
    let finalName = baseName;
    if (isElectron) {
      const res = await window.electronAPI.teams.add({ name: baseName, actor: currentUser });
      if (!res?.ok) {
        setTeamMsg(res?.error || 'Unable to add team.');
        return;
      }
      finalName = (res.name || baseName).trim();
    } else {
      let idx = 2;
      const existsCi = (name) => teams.some(t => t.toLowerCase() === name.toLowerCase());
      while (existsCi(finalName)) {
        finalName = `${baseName} (${idx})`;
        idx += 1;
      }
    }
    addUniqueTeamLocal(finalName);
    if (isElectron) refreshOrgData();
    setShowAddTeam(false);
    setNewTeam('');
    setTeamMsg('');
  };

  const deleteTeam = async (teamName) => {
    setTeamActionMsg('');
    if (isElectron) {
      const res = await window.electronAPI.teams.delete({ name: teamName, actor: currentUser });
      if (!res?.ok) {
        const err = String(res?.error || '');
        if (!/team not found/i.test(err)) {
          setTeamActionMsg(err || 'Unable to delete team.');
          return;
        }
      }
      setTeams(prev => prev.filter(t => (t || '').toLowerCase() !== (teamName || '').toLowerCase()));
      setEmployees(prev => prev.map(emp => (emp.team || '').toLowerCase() === (teamName || '').toLowerCase() ? { ...emp, team: '' } : emp));
      setTeamActionMsg('');
      refreshOrgData();
    } else {
      setTeams(prev => prev.filter(t => (t || '').toLowerCase() !== (teamName || '').toLowerCase()));
      setEmployees(prev => prev.map(emp => (emp.team || '').toLowerCase() === (teamName || '').toLowerCase() ? { ...emp, team: '' } : emp));
      setTeamActionMsg('');
    }
  };

  const openTeamMembers = (teamName) => {
    setTeamActionMsg('');
    setActiveTeam(teamName);
    setSelectedEmployeeName('');
    setTeamModalOpen(true);
  };

  const assignEmployeeToTeam = async () => {
    if (!selectedEmployeeName || !activeTeam) return;
    const emp = employees.find(e => e.name === selectedEmployeeName);
    if (!emp) return;
    if (String(emp.name || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase()) {
      setTeamActionMsg('Built-in Admin cannot be added to teams.');
      return;
    }
    if (isElectron) {
      const res = await window.electronAPI.employees.update({ name: emp.name, role: emp.role, team: activeTeam, actor: currentUser });
      if (!res?.ok) {
        setTeamActionMsg(res?.error || 'Unable to add user to team.');
        return;
      }
    }
    setEmployees(prev => prev.map(e => e.name === emp.name ? { ...e, team: activeTeam } : e));
    addUniqueTeamLocal(activeTeam);
    if (isElectron) refreshOrgData();
    setSelectedEmployeeName('');
  };

  const removeEmployeeFromTeam = async (emp) => {
    if (!emp?.name) return;
    if (String(emp.name || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase()) {
      setTeamActionMsg('Built-in Admin cannot be modified.');
      return;
    }
    if (isElectron) {
      const res = await window.electronAPI.employees.update({ name: emp.name, role: emp.role, team: '', actor: currentUser });
      if (!res?.ok) {
        setTeamActionMsg(res?.error || 'Unable to remove user from team.');
        return;
      }
    }
    setEmployees(prev => prev.map(e => e.name === emp.name ? { ...e, team: '' } : e));
    if (isElectron) refreshOrgData();
  };

  const openEditEmployee = (emp) => {
    if (String(emp?.name || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase()) return;
    setEmpActionMsg('');
    setEditEmp({ oldName: emp.name, name: emp.name, role: displayRole(emp.role || BASE_ROLE), team: emp.team || '' });
    setShowEditEmployee(true);
  };

  const saveEditEmployee = async () => {
    const oldName = (editEmp.oldName || '').trim();
    const name = (editEmp.name || '').trim();
    if (!oldName) return;
    if (
      oldName.toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase() ||
      name.toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase()
    ) {
      setEmpActionMsg('Built-in Admin cannot be modified.');
      return;
    }
    if (!name) {
      setEmpActionMsg('Please enter employee name.');
      return;
    }
    if (name !== oldName && employees.some(e => e.name === name)) {
      setEmpActionMsg('User already exist');
      return;
    }
    const existingEmp = employees.find(e => String(e.name || '').toLowerCase() === oldName.toLowerCase());
    const oldRole = displayRole(existingEmp?.role || BASE_ROLE);
    const roleChanged = String(oldRole || '').toLowerCase() !== String(editEmp.role || '').toLowerCase();
    if (roleChanged && isManagerExecutiveRole(oldRole) && isManagerExecutiveRole(editEmp.role) && !canChangeManagerExecutiveRoles) {
      setEmpActionMsg('Only Admins or Managers can change Manager/Executive roles.');
      return;
    }
    if (isElectron) {
      const res = await window.electronAPI.employees.update({ oldName, newName: name, role: editEmp.role, team: editEmp.team, actor: currentUser });
      if (!res?.ok) {
        setEmpActionMsg(res?.error || 'Unable to update employee.');
        return;
      }
    }
    setEmployees(prev => prev.map(e => e.name === oldName ? { ...e, name, role: editEmp.role, team: editEmp.team } : e));
    addUniqueTeamLocal(editEmp.team);
    setShowEditEmployee(false);
    setEmpActionMsg('');
    if (isElectron) refreshOrgData();
  };

  const deleteEmployee = async (emp) => {
    const name = (emp?.name || '').trim();
    if (!name) return;
    if (name.toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase()) {
      setEmpActionMsg('Built-in Admin cannot be deleted.');
      return;
    }
    setConfirmDeleteEmp(emp);
  };

  const confirmEmployeeDelete = async () => {
    const emp = confirmDeleteEmp;
    setConfirmDeleteEmp(null);
    const name = (emp?.name || '').trim();
    if (!name) return;
    setEmpActionMsg('');
    if (isElectron) {
      const res = await window.electronAPI.employees.delete({ name, actor: currentUser });
      if (!res?.ok) {
        setEmpActionMsg(res?.error || 'Unable to delete employee.');
        return;
      }
    }
    setEmployees(prev => prev.filter(e => e.name !== name));
    if (isElectron) refreshOrgData();
  };

  const teamRows = teams.map(t => ({
    name: t,
    members: managedEmployees.filter(e => (e.team || '') === t).length,
  }));
  const teamMembers = managedEmployees.filter(e => (e.team || '') === activeTeam);
  const addableEmployees = managedEmployees.filter(e => (e.team || '') !== activeTeam);

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginBottom: 20 }}>
        <button onClick={() => { setTeamMsg(''); setShowAddTeam(true); }} style={btnSecondary}><Plus size={14} />Add Team</button>
        <button onClick={() => { setEmpMsg(''); setShowAdd(true); }} style={btnPrimary}><Plus size={14} />Add Employee</button>
      </div>

      <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, padding: 16, marginBottom: 18 }}>
        <div style={{ fontSize: 13, color: '#64748b', marginBottom: 10 }}>Manage Teams</div>
        <DataTable columns={[
          { label: 'Team', key: 'name' },
          { label: 'Members', render: r => <span style={{ fontWeight: 600 }}>{r.members}</span> },
          { label: '', style: { width: 56 }, cellStyle: { textAlign: 'right' }, render: r => <button title="Delete team" onClick={e => { e.stopPropagation(); deleteTeam(r.name); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', padding: 4 }}><Trash2 size={14} /></button> },
        ]} data={teamRows} onRowDoubleClick={(r) => openTeamMembers(r.name)} emptyMsg="No teams yet" />
        <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 8 }}>Double-click a team row to manage team users.</div>
        {teamActionMsg && <div style={{ fontSize: 12, color: '#dc2626', marginTop: 8 }}>{teamActionMsg}</div>}
      </div>

      <div style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: 12, padding: 16 }}>
        <div style={{ fontSize: 13, color: '#64748b', marginBottom: 10 }}>Manage Employees</div>
        <DataTable columns={[
        { label: 'Employee', render: r => <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}><div style={{ width: 32, height: 32, borderRadius: '50%', background: '#0d948815', color: '#0d9488', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13 }}>{r.name.charAt(0)}</div><span style={{ fontWeight: 600 }}>{r.name}</span></div> },
        { label: 'Role', render: r => <span style={{ background: isSuperadminRole(r.role) ? '#fef3c7' : r.role === 'Admin' ? '#fee2e2' : r.role === 'Manager' ? '#dbeafe' : '#f1f5f9', color: isSuperadminRole(r.role) ? '#a16207' : r.role === 'Admin' ? '#dc2626' : r.role === 'Manager' ? '#1d4ed8' : '#475569', padding: '3px 10px', borderRadius: 20, fontSize: 11, fontWeight: 600 }}>{displayRole(r.role)}</span> },
        { label: 'Team', render: r => (r.team || '') },
        { label: '', style: { width: 56 }, cellStyle: { textAlign: 'right' }, render: r => <button title="Delete employee" onClick={e => { e.stopPropagation(); deleteEmployee(r); }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', padding: 4 }}><Trash2 size={14} /></button> },
        ]} data={managedEmployees} onRowDoubleClick={openEditEmployee} emptyMsg="No employees" />
        <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 8 }}>Double-click an employee row to edit name, role, and team.</div>
        {empActionMsg && <div style={{ fontSize: 12, color: '#dc2626', marginTop: 8 }}>{empActionMsg}</div>}
      </div>
      <Modal open={showAdd} onClose={() => { setShowAdd(false); setEmpMsg(''); }} title="Add Employee">
        <FormField label="Name" required><input value={newEmp.name} onChange={e => { setNewEmp(p => ({ ...p, name: e.target.value })); if (empMsg) setEmpMsg(''); }} onKeyDown={e => { if (e.key === 'Enter') addEmp(); }} style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }} /></FormField>
        <FormField label="Role"><select value={newEmp.role} onChange={e => setNewEmp(p => ({ ...p, role: e.target.value }))} style={inputStyle}>{employeeRoleOptions.map(r => <option key={r}>{r}</option>)}</select></FormField>
        <FormField label="Team">
          <select value={newEmp.team} onChange={e => setNewEmp(p => ({ ...p, team: e.target.value }))} style={inputStyle}>
            <option value="">No Team</option>
            {teams.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </FormField>
        <div style={{ fontSize: 11, color: '#64748b', marginTop: -6, marginBottom: 10 }}>
          Default password for new user: <b>12345</b>
        </div>
        {empMsg && <div style={{ fontSize: 12, color: '#dc2626', marginTop: -4, marginBottom: 10 }}>{empMsg}</div>}
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
          <button onClick={() => setShowAdd(false)} style={btnSecondary}>Cancel</button>
          <button onClick={addEmp} style={btnPrimary}>Add Employee</button>
        </div>
      </Modal>

      <Modal open={showEditEmployee} onClose={() => { setShowEditEmployee(false); setEmpActionMsg(''); }} title={`Edit Employee - ${editEmp.oldName || ''}`}>
        <FormField label="Name" required>
          <input value={editEmp.name} onChange={e => { setEditEmp(p => ({ ...p, name: e.target.value })); if (empActionMsg) setEmpActionMsg(''); }} style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }} />
        </FormField>
        <FormField label="Role">
          <select
            value={editEmp.role}
            onChange={e => setEditEmp(p => ({ ...p, role: e.target.value }))}
            style={inputStyle}
            disabled={
              (isManagerExecutiveRole(editEmp.role) && !canChangeManagerExecutiveRoles) ||
              (String(editEmp.role || '').toLowerCase() === 'admin' && !isAdminRole(currentUserRole))
            }
          >
            {[...new Set([...employeeRoleOptions, editEmp.role].filter(Boolean))].map(r => <option key={r}>{r}</option>)}
          </select>
        </FormField>
        <FormField label="Team">
          <select value={editEmp.team} onChange={e => setEditEmp(p => ({ ...p, team: e.target.value }))} style={inputStyle}>
            <option value="">No Team</option>
            {teams.map(t => <option key={t} value={t}>{t}</option>)}
          </select>
        </FormField>
        {empActionMsg && <div style={{ fontSize: 12, color: '#dc2626', marginTop: -4, marginBottom: 10 }}>{empActionMsg}</div>}
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
          <button onClick={() => setShowEditEmployee(false)} style={btnSecondary}>Cancel</button>
          <button onClick={saveEditEmployee} style={btnPrimary}>Save</button>
        </div>
      </Modal>

      <Modal open={showAddTeam} onClose={() => { setShowAddTeam(false); setTeamMsg(''); }} title="Add Team">
        <FormField label="Team Name" required>
          <input
            value={newTeam}
            onChange={e => { setNewTeam(e.target.value); if (teamMsg) setTeamMsg(''); }}
            onKeyDown={e => { if (e.key === 'Enter') addTeam(); }}
            style={inputStyle}
          />
        </FormField>
        {teamMsg && <div style={{ fontSize: 12, color: '#dc2626', marginTop: -4, marginBottom: 10 }}>{teamMsg}</div>}
        <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
          <button onClick={() => setShowAddTeam(false)} style={btnSecondary}>Cancel</button>
          <button onClick={addTeam} style={btnPrimary}>Add Team</button>
        </div>
      </Modal>

      <Modal open={teamModalOpen} onClose={() => { setTeamModalOpen(false); setActiveTeam(''); setSelectedEmployeeName(''); }} title={`Team Users - ${activeTeam || ''}`} width={520}>
        <div style={{ marginBottom: 14 }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <select value={selectedEmployeeName} onChange={e => setSelectedEmployeeName(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
              <option value="">Select employee to add</option>
              {addableEmployees.map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
            </select>
            <button onClick={assignEmployeeToTeam} style={btnPrimary}>Add</button>
          </div>
        </div>
        <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: '#f1f5f9' }}>
                <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', borderBottom: '2px solid #e2e8f0' }}>User</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', borderBottom: '2px solid #e2e8f0' }}>Role</th>
                <th style={{ padding: '8px 12px', width: 70, borderBottom: '2px solid #e2e8f0' }} />
              </tr>
            </thead>
            <tbody>
              {teamMembers.length === 0 ? (
                <tr><td colSpan={3} style={{ padding: 14, textAlign: 'center', color: '#94a3b8' }}>No users in this team</td></tr>
              ) : teamMembers.map(emp => (
                <tr key={emp.name} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '8px 12px', fontWeight: 600 }}>{emp.name}</td>
                  <td style={{ padding: '8px 12px', color: '#64748b' }}>{displayRole(emp.role)}</td>
                  <td style={{ padding: '8px 12px' }}>
                    <button onClick={() => removeEmployeeFromTeam(emp)} title="Remove from team" style={{ background: 'none', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#ef4444' }}>
                      <Minus size={12} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Modal>
      <ConfirmDialog
        open={!!confirmDeleteEmp}
        title="Delete Employee"
        message={`Are you sure you want to delete "${confirmDeleteEmp?.name}"? This action cannot be undone.`}
        confirmLabel="Delete"
        onConfirm={confirmEmployeeDelete}
        onCancel={() => setConfirmDeleteEmp(null)}
      />
    </div>
  );
}

function SettingsPage({ currentUser, isSuperAdmin, isRemoteApp = false, syncConnection, onPasswordChanged, onServerSettingsChanged }) {
  const [dbPath, setDbPath] = useState('');
  const [dbStatus, setDbStatus] = useState('');
  const [saving, setSaving] = useState(false);
  const [appSettings, setAppSettings] = useState({ autoLaunch: false, minimizeToTray: true, serverUrl: '', directDbDir: '', directSyncEnabled: false, directQueuePollSeconds: '10', directAuthToken: '', driveScriptUrl: '', driveToken: '', driveSyncEnabled: false, taskIdPrefix: '', taskIdNextNumber: '' });
  const [appStatus, setAppStatus] = useState('');
  const [appSaving, setAppSaving] = useState(false);
  const [serverStatus, setServerStatus] = useState({ checking: false, connected: false, message: '' });
  const [discovering, setDiscovering] = useState(false);
  const [discoveredServers, setDiscoveredServers] = useState([]);
  const [pwdForm, setPwdForm] = useState({ current: '', next: '', confirm: '' });
  const [pwdSaving, setPwdSaving] = useState(false);
  const [pwdMsg, setPwdMsg] = useState('');
  const lastSyncedLabel = syncConnection?.lastSyncedAt
    ? (() => {
        const diffMs = Date.now() - new Date(syncConnection.lastSyncedAt).getTime();
        if (!Number.isFinite(diffMs) || diffMs < 0) return 'Just now';
        const seconds = Math.floor(diffMs / 1000);
        if (seconds < 60) return `${seconds || 1}s ago`;
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes}m ago`;
        return `${Math.floor(minutes / 60)}h ago`;
      })()
    : 'Not synced yet';

  useEffect(() => {
    if (!isElectron) return;
    window.electronAPI.config.getDbPath().then(p => setDbPath(p || ''));
    window.electronAPI.config.getAppSettings?.().then((cfg) => {
      if (!cfg) return;
      setAppSettings({
        autoLaunch: !!cfg.autoLaunch,
        minimizeToTray: cfg.minimizeToTray !== false,
        serverUrl: cfg.serverUrl || '',
        directDbDir: cfg.directDbDir || '',
        directSyncEnabled: cfg.directSyncEnabled !== false,
        directQueuePollSeconds: cfg.directQueuePollSeconds || '10',
        directAuthToken: cfg.directAuthToken || '',
        driveScriptUrl: cfg.driveScriptUrl || '',
        driveToken: cfg.driveToken || '',
        driveSyncEnabled: cfg.driveSyncEnabled !== false,
        taskIdPrefix: cfg.taskIdPrefix || '',
        taskIdNextNumber: cfg.taskIdNextNumber || '',
      });
    });
  }, []);

  useEffect(() => {
    const serverUrl = String(appSettings.serverUrl || '').trim();
    const directDbDir = String(appSettings.directDbDir || '').trim();
    const driveScriptUrl = String(appSettings.driveScriptUrl || '').trim();
    const savedServerUrl = String(syncConnection?.serverUrl || '').trim();
    if (directDbDir) {
      const running = appSettings.directSyncEnabled !== false && !!syncConnection?.enabled;
      const connected = running && !!syncConnection?.online;
      setServerStatus({
        checking: false,
        connected,
        message: running ? (connected ? 'Connected to DB' : 'DB not connected') : '',
      });
      return;
    }
    if (driveScriptUrl) {
      const running = appSettings.driveSyncEnabled !== false && !!syncConnection?.enabled;
      const connected = running && !!syncConnection?.online;
      setServerStatus({
        checking: false,
        connected,
        message: running ? (connected ? 'Connected to Drive' : 'Drive not connected') : '',
      });
      return;
    }
    if (!serverUrl) {
      setServerStatus({ checking: false, connected: false, message: '' });
      return;
    }
    if (!savedServerUrl || serverUrl !== savedServerUrl) return;
    const connected = !!syncConnection?.online;
    setServerStatus({
      checking: false,
      connected,
      message: connected ? 'Connected to Server' : (syncConnection?.lastError || 'Server not connected'),
    });
  }, [appSettings.serverUrl, appSettings.directDbDir, appSettings.directSyncEnabled, appSettings.directAuthToken, appSettings.driveScriptUrl, appSettings.driveToken, appSettings.driveSyncEnabled, syncConnection?.enabled, syncConnection?.serverUrl, syncConnection?.online, syncConnection?.lastError]);

  const pickDbFolder = async () => {
    if (!isElectron) return;
    if (!isSuperAdmin) {
      setDbStatus('Only Superadmin can change app settings.');
      return;
    }
    setSaving(true);
    setDbStatus('');
    const selected = await window.electronAPI.selectFolder();
    if (!selected) { setSaving(false); return; }
    const res = await window.electronAPI.config.setDbPath({ path: selected, actor: currentUser });
    if (res?.ok) {
      setDbPath(res.path || selected);
      setDbStatus('Restart the app to use the new database location.');
    } else {
      setDbStatus(res?.error || 'Unable to update database location.');
    }
    setSaving(false);
  };

  const updatePassword = async () => {
    setPwdMsg('');
    if (!currentUser) {
      setPwdMsg('User not found.');
      return;
    }
    if (!pwdForm.current || !pwdForm.next || !pwdForm.confirm) {
      setPwdMsg('Please fill all password fields.');
      return;
    }
    if (pwdForm.next !== pwdForm.confirm) {
      setPwdMsg('New password and confirm password do not match.');
      return;
    }
    setPwdSaving(true);
    try {
      if (isElectron && window.electronAPI?.auth?.changePassword) {
        const res = await window.electronAPI.auth.changePassword({
          name: currentUser,
          currentPassword: pwdForm.current,
          newPassword: pwdForm.next,
        });
        if (!res?.ok) {
          setPwdMsg(res?.error || 'Unable to change password.');
          return;
        }
      } else {
        if (pwdForm.current !== '12345') {
          setPwdMsg('Current password is incorrect.');
          return;
        }
      }
      setPwdForm({ current: '', next: '', confirm: '' });
      onPasswordChanged?.(pwdForm.next);
      setPwdMsg('Password updated successfully.');
    } finally {
      setPwdSaving(false);
    }
  };

  const syncDriveNow = async () => {
    if (!isElectron || !window.electronAPI?.sync?.pull) return;
    setAppStatus('Syncing...');
    const res = await window.electronAPI.sync.pull();
    setAppStatus(res?.waitingForServer ? 'Waiting for server to process queued changes.' : (res?.ok ? 'Synced.' : (res?.error || 'Sync failed.')));
    onServerSettingsChanged?.(appSettings, res, {
      enabled: true,
      online: !!res?.ok,
      mode: 'drive',
      serverUrl: appSettings.driveScriptUrl || '',
      pendingCount: Number(res?.pendingCount || 0),
      lastError: res?.ok ? '' : (res?.error || 'Drive not connected'),
    });
  };

  const updateAppOption = async (patch) => {
    if (!isElectron || !window.electronAPI?.config?.setAppSettings) return;
    if (!isSuperAdmin) {
      setAppStatus('Only Superadmin can change app settings.');
      return;
    }
    setAppSaving(true);
    setAppStatus('');
    const isServerPatch = Object.prototype.hasOwnProperty.call(patch || {}, 'serverUrl') || Object.prototype.hasOwnProperty.call(patch || {}, 'serverToken') || Object.prototype.hasOwnProperty.call(patch || {}, 'directDbDir') || Object.prototype.hasOwnProperty.call(patch || {}, 'directSyncEnabled') || Object.prototype.hasOwnProperty.call(patch || {}, 'directQueuePollSeconds') || Object.prototype.hasOwnProperty.call(patch || {}, 'directAuthToken') || Object.prototype.hasOwnProperty.call(patch || {}, 'driveScriptUrl') || Object.prototype.hasOwnProperty.call(patch || {}, 'driveToken') || Object.prototype.hasOwnProperty.call(patch || {}, 'driveSyncEnabled');
    const disconnecting = (Object.prototype.hasOwnProperty.call(patch || {}, 'serverUrl') && !String(patch.serverUrl || '').trim()) || (Object.prototype.hasOwnProperty.call(patch || {}, 'directSyncEnabled') && patch.directSyncEnabled === false) || (Object.prototype.hasOwnProperty.call(patch || {}, 'driveSyncEnabled') && patch.driveSyncEnabled === false);
    if (isServerPatch) {
      setServerStatus({
        checking: !disconnecting,
        connected: false,
        message: disconnecting ? '' : 'Connecting...',
      });
    }
    try {
      const res = await window.electronAPI.config.setAppSettings({ ...(patch || {}), actor: currentUser });
      if (!res?.ok) {
        setAppStatus(res?.error || 'Unable to update app settings.');
        if (Object.prototype.hasOwnProperty.call(patch || {}, 'directDbDir')) {
          setAppSettings(p => ({ ...p, directDbDir: patch.directDbDir || '' }));
        }
        if (isServerPatch) {
          setServerStatus({
            checking: false,
            connected: false,
            message: 'Server not connected',
          });
        }
        return;
      }
      if (res?.settings) {
        setAppSettings({
          autoLaunch: !!res.settings.autoLaunch,
          minimizeToTray: res.settings.minimizeToTray !== false,
          serverUrl: res.settings.serverUrl || '',
          directDbDir: res.settings.directDbDir || '',
          directSyncEnabled: res.settings.directSyncEnabled !== false,
          directQueuePollSeconds: res.settings.directQueuePollSeconds || '10',
          directAuthToken: Object.prototype.hasOwnProperty.call(res.settings, 'directAuthToken') ? (res.settings.directAuthToken || '') : (appSettings.directAuthToken || ''),
          driveScriptUrl: res.settings.driveScriptUrl || '',
          driveToken: Object.prototype.hasOwnProperty.call(res.settings, 'driveToken') ? (res.settings.driveToken || '') : (appSettings.driveToken || ''),
          driveSyncEnabled: res.settings.driveSyncEnabled !== false,
          taskIdPrefix: res.settings.taskIdPrefix || '',
          taskIdNextNumber: res.settings.taskIdNextNumber || '',
        });
        if (isServerPatch) {
          onServerSettingsChanged?.(res.settings, res.initialPull, res.connection);
          const connected = !!res.connection?.online;
          setServerStatus({
            checking: false,
            connected,
            message: !String(res.settings.serverUrl || res.settings.directDbDir || res.settings.driveScriptUrl || '').trim() || (res.connection?.mode === 'direct' && res.settings.directSyncEnabled === false) || (res.connection?.mode === 'drive' && res.settings.driveSyncEnabled === false) ? '' : (connected ? (res.connection?.mode === 'direct' ? 'Connected to DB' : res.connection?.mode === 'drive' ? 'Connected to Drive DB' : 'Connected to Server') : (res.connection?.lastError || (res.connection?.mode === 'direct' ? 'DB not connected' : res.connection?.mode === 'drive' ? 'Drive DB not available' : 'Server not connected'))),
          });
        }
      }
      setAppStatus(patch?.actionType === 'save' ? 'Saved.' : (disconnecting ? 'Disconnected.' : (isServerPatch ? (res?.connection?.online ? 'Connected.' : (res?.connection?.lastError || res?.initialPull?.error || 'Connection not available.')) : 'App settings updated.')));
    } finally {
      setAppSaving(false);
    }
  };

  const fetchLanServers = async () => {
    if (!isElectron || !window.electronAPI?.config?.discoverServers) return;
    setDiscovering(true);
    setAppStatus('');
    setDiscoveredServers([]);
    try {
      const res = await window.electronAPI.config.discoverServers();
      const servers = Array.isArray(res?.servers) ? res.servers : [];
      setDiscoveredServers(servers);
      setAppStatus(servers.length ? `Found ${servers.length} running server${servers.length === 1 ? '' : 's'}.` : 'No running server found.');
    } finally {
      setDiscovering(false);
    }
  };

  return (
    <div style={{ maxWidth: 600 }}>
      {!isRemoteApp && (
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginBottom: 20 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Server Connection</h3>
        <FormField label="Server IP / URL">
          <div style={{ display: 'flex', gap: 10 }}>
            <input
              value={appSettings.serverUrl || ''}
              onChange={e => setAppSettings(p => ({ ...p, serverUrl: e.target.value }))}
              placeholder="192.168.1.10 or http://192.168.1.10:3587"
              style={{ ...inputStyle, flex: 1, cursor: 'text', caretColor: '#0f172a' }}
            />
            <button onClick={fetchLanServers} style={btnSecondary} disabled={discovering || appSaving}>
              {discovering ? 'Fetching...' : 'Fetch'}
            </button>
            <button onClick={() => updateAppOption({ serverUrl: appSettings.serverUrl || '' })} style={btnSecondary} disabled={appSaving || !isSuperAdmin}>
              {appSaving ? 'Saving...' : 'Save'}
            </button>
            <button
              onClick={() => {
                setAppSettings(p => ({ ...p, serverUrl: '' }));
                setServerStatus({ checking: false, connected: false, message: '' });
                updateAppOption({ serverUrl: '', serverToken: '' });
              }}
              style={{ ...btnSecondary, color: '#dc2626', borderColor: '#fecaca' }}
              disabled={appSaving || !isSuperAdmin || !String(appSettings.serverUrl || '').trim()}
            >
              Disconnect
            </button>
          </div>
          {serverStatus.message && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: serverStatus.connected ? '#0f766e' : '#dc2626', marginTop: 8 }}>
              <span style={{ width: 8, height: 8, borderRadius: 999, background: serverStatus.connected ? '#22c55e' : '#ef4444', boxShadow: serverStatus.connected ? '0 0 0 3px rgba(34,197,94,0.12)' : 'none' }} />
              {serverStatus.message}
            </div>
          )}
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
            After connecting, the app pulls the latest server data first. New changes are pushed after that.
          </div>
          {discoveredServers.length > 0 && (
            <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
              {discoveredServers.map(server => (
                <button
                  key={server.url}
                  onClick={() => {
                    setAppSettings(p => ({ ...p, serverUrl: server.url }));
                    updateAppOption({ serverUrl: server.url, serverToken: server.token || '' });
                  }}
                  disabled={!isSuperAdmin || appSaving}
                  style={{
                    ...btnSecondary,
                    width: '100%',
                    justifyContent: 'space-between',
                    display: 'flex',
                    textAlign: 'left',
                    fontWeight: 600,
                  }}
                >
                  <span>{server.name || 'ERP Server'}</span>
                  <span style={{ color: '#64748b', fontWeight: 500 }}>{server.url}</span>
                </button>
              ))}
            </div>
          )}
        </FormField>
      </div>
      )}
      {isRemoteApp && (
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginBottom: 20 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Google Drive Web Access</h3>
        <FormField label="Apps Script Web App URL">
          <input
            value={appSettings.driveScriptUrl || ''}
            onChange={e => setAppSettings(p => ({ ...p, driveScriptUrl: e.target.value, directDbDir: e.target.value ? '' : p.directDbDir, serverUrl: e.target.value ? '' : p.serverUrl }))}
            placeholder="https://script.google.com/macros/s/.../exec"
            style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }}
          />
        </FormField>
        <FormField label="Drive Access Token">
          <input
            type="password"
            value={appSettings.driveToken || ''}
            onChange={e => setAppSettings(p => ({ ...p, driveToken: e.target.value }))}
            placeholder="Token from Apps Script"
            style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }}
          />
        </FormField>
        <FormField label="Sync Interval (seconds)">
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <input
              type="number"
              min="5"
              value={appSettings.directQueuePollSeconds || '10'}
              onChange={e => setAppSettings(p => ({ ...p, directQueuePollSeconds: e.target.value }))}
              style={{ ...inputStyle, maxWidth: 180, cursor: 'text', caretColor: '#0f172a' }}
            />
            <button
              onClick={syncDriveNow}
              style={btnSecondary}
              disabled={appSaving || !isSuperAdmin || !String(appSettings.driveScriptUrl || '').trim() || !String(appSettings.driveToken || '').trim()}
            >
              Sync Now
            </button>
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
            Last synced: {lastSyncedLabel}
          </div>
        </FormField>
        <FormField label="Connection">
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', justifyContent: 'flex-end' }}>
            <button
              onClick={() => updateAppOption({ driveScriptUrl: appSettings.driveScriptUrl || '', driveToken: appSettings.driveToken || '', driveSyncEnabled: false, directDbDir: '', directSyncEnabled: false, directQueuePollSeconds: appSettings.directQueuePollSeconds || '10', saveOnly: true, actionType: 'save' })}
              style={btnSecondary}
              disabled={appSaving || !isSuperAdmin || !String(appSettings.driveScriptUrl || '').trim()}
            >
              {appSaving ? 'Saving...' : 'Save'}
            </button>
            <button
              onClick={() => {
                const isConnected = appSettings.driveSyncEnabled !== false && syncConnection?.enabled && syncConnection?.mode === 'drive' && syncConnection?.online;
                const nextEnabled = !isConnected;
                if (!nextEnabled) {
                  setAppSettings(p => ({ ...p, driveSyncEnabled: false }));
                } else {
                  setServerStatus({ checking: true, connected: false, message: 'Connecting to Drive...' });
                }
                updateAppOption({ driveScriptUrl: appSettings.driveScriptUrl || '', driveToken: appSettings.driveToken || '', driveSyncEnabled: nextEnabled, directDbDir: '', directSyncEnabled: false, directQueuePollSeconds: appSettings.directQueuePollSeconds || '10', saveOnly: !nextEnabled, actionType: nextEnabled ? 'connect' : 'disconnect' });
              }}
              style={{ ...btnSecondary, color: appSettings.driveSyncEnabled !== false && syncConnection?.enabled && syncConnection?.mode === 'drive' && syncConnection?.online ? '#dc2626' : '#0d9488', borderColor: appSettings.driveSyncEnabled !== false && syncConnection?.enabled && syncConnection?.mode === 'drive' && syncConnection?.online ? '#fecaca' : '#99f6e4' }}
              disabled={appSaving || !isSuperAdmin || !String(appSettings.driveScriptUrl || '').trim() || !String(appSettings.driveToken || '').trim()}
            >
              {appSettings.driveSyncEnabled !== false && syncConnection?.enabled && syncConnection?.mode === 'drive' && syncConnection?.online ? 'Disconnect' : 'Connect'}
            </button>
          </div>
        </FormField>
        {serverStatus.message && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: serverStatus.connected ? '#0f766e' : '#dc2626', marginTop: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: 999, background: serverStatus.connected ? '#22c55e' : '#ef4444', boxShadow: serverStatus.connected ? '0 0 0 3px rgba(34,197,94,0.12)' : 'none' }} />
            {serverStatus.message}
          </div>
        )}
        <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
          Drive Web mode reads the Google Drive DB file through Apps Script and writes this Remote Access client&apos;s changes into Drive queue files.
        </div>
      </div>
      )}
      {appStatus && <div style={{ fontSize: 12, color: /updated|found|disconnected|connected/i.test(appStatus) ? '#0d9488' : '#dc2626', marginTop: -8, marginBottom: 16 }}>{appStatus}</div>}
      {isSuperAdmin && (
        <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginBottom: 20 }}>
          <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Task ID Preset</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 10, alignItems: 'end' }}>
            <FormField label="Prefix">
              <input
                value={appSettings.taskIdPrefix || ''}
                onChange={e => setAppSettings(p => ({ ...p, taskIdPrefix: e.target.value.replace(/\s+/g, '') }))}
                placeholder="TASK-"
                style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }}
              />
            </FormField>
            <FormField label="Next Number">
              <input
                type="number"
                min="1"
                value={appSettings.taskIdNextNumber || ''}
                onChange={e => setAppSettings(p => ({ ...p, taskIdNextNumber: e.target.value }))}
                placeholder="1"
                style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }}
              />
            </FormField>
            <button
              onClick={() => updateAppOption({ taskIdPrefix: appSettings.taskIdPrefix || '', taskIdNextNumber: appSettings.taskIdNextNumber || '' })}
              style={{ ...btnSecondary, marginBottom: 14 }}
              disabled={appSaving}
            >
              Save
            </button>
          </div>
          <div style={{ fontSize: 12, color: '#64748b' }}>
            Leave prefix or next number blank to use the default system-generated task IDs.
          </div>
        </div>
      )}
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Notifications</h3>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, cursor: 'pointer', padding: '8px 0' }}><input type="checkbox" defaultChecked style={{ accentColor: '#0d9488' }} /> Enable task due reminders</label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, cursor: 'pointer', padding: '8px 0' }}><input type="checkbox" defaultChecked style={{ accentColor: '#0d9488' }} /> Email notifications for overdue tasks</label>
      </div>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginTop: 20 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Startup & Background</h3>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, cursor: 'pointer', padding: '8px 0' }}>
          <input
            type="checkbox"
            checked={!!appSettings.autoLaunch}
              onChange={(e) => updateAppOption({ autoLaunch: e.target.checked })}
            disabled={appSaving || !isSuperAdmin}
            style={{ accentColor: '#0d9488' }}
          />
          Run Task Manager on startup
        </label>
        <label style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13, cursor: 'pointer', padding: '8px 0' }}>
          <input
            type="checkbox"
            checked={appSettings.minimizeToTray !== false}
            onChange={(e) => updateAppOption({ minimizeToTray: e.target.checked })}
            disabled={appSaving || !isSuperAdmin}
            style={{ accentColor: '#0d9488' }}
          />
          On close, keep app running in hidden icons (system tray)
        </label>
        <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
          To fully exit, use the tray icon menu and click "Exit Task Manager".
        </div>
      </div>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginTop: 20 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Security</h3>
        <FormField label="Current Password">
          <input type="password" value={pwdForm.current} onChange={e => setPwdForm(p => ({ ...p, current: e.target.value }))} style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }} />
        </FormField>
        <FormField label="New Password">
          <input type="password" value={pwdForm.next} onChange={e => setPwdForm(p => ({ ...p, next: e.target.value }))} style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }} />
        </FormField>
        <FormField label="Confirm New Password">
          <input type="password" value={pwdForm.confirm} onChange={e => setPwdForm(p => ({ ...p, confirm: e.target.value }))} style={{ ...inputStyle, cursor: 'text', caretColor: '#0f172a' }} />
        </FormField>
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <button onClick={updatePassword} style={btnPrimary} disabled={pwdSaving}>{pwdSaving ? 'Saving...' : 'Change Password'}</button>
        </div>
        {pwdMsg && <div style={{ fontSize: 12, color: /success/i.test(pwdMsg) ? '#0d9488' : '#dc2626', marginTop: 8 }}>{pwdMsg}</div>}
      </div>
      <div style={{ background: '#fff', borderRadius: 12, border: '1px solid #e2e8f0', padding: 24, marginTop: 20 }}>
        <h3 style={{ margin: '0 0 16px', fontSize: 15, fontWeight: 700 }}>Storage</h3>
        <FormField label={isRemoteApp ? 'Remote Local Data Folder' : 'Local Data Folder'}>
          <div style={{ display: 'flex', gap: 10 }}>
            <input value={dbPath} readOnly style={{ ...inputStyle, flex: 1, background: '#f8fafc' }} />
            <button onClick={pickDbFolder} style={btnSecondary} disabled={saving || !isSuperAdmin}>
              {saving ? 'Updating...' : 'Change'}
            </button>
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>
            {isRemoteApp
              ? 'The Remote Access client stores its local DB copy, offline cache, pending sync queue, logs, attachments, and voice notes inside this selected folder.'
              : 'The local DB copy, offline cache, sync queue, attachments, and voice notes are stored inside this folder.'}
          </div>
          {dbStatus && <div style={{ fontSize: 12, color: '#0d9488', marginTop: 6 }}>{dbStatus}</div>}
        </FormField>
      </div>
    </div>
  );
}

function PlaceholderPage({ icon: Icon, title }) {
  return (
    <div style={{ textAlign: 'center', padding: 60, color: '#94a3b8' }}>
      <Icon size={48} style={{ marginBottom: 16, opacity: 0.3 }} />
      <h3 style={{ color: '#64748b', fontWeight: 600 }}>{title}</h3>
      <p style={{ fontSize: 14 }}>This section is available in the full application.</p>
    </div>
  );
}

//  Attachment Manager Modal //
function AttachmentManager({ open, onClose, itemId, isSubtask, itemName, actor, isAdmin = false, canAdd = true, canRemoveAttachment }) {
  const [attachments, setAttachments] = useState([]);
  const [manualPath, setManualPath] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  const refreshAttachments = async () => {
    if (!isElectron || !itemId) return;
    const rows = await window.electronAPI.attachments.list({ itemId, isSubtask: !!isSubtask, actor, isAdmin });
    setAttachments((rows || []).map(r => ({ id: r.id, fileName: r.file_name, filePath: r.file_path, addedOn: r.added_on, addedBy: r.added_by || '' })));
  };

  useEffect(() => {
    if (!open || !itemId || !isElectron) return;
    setErrorMsg('');
    refreshAttachments();
  }, [open, itemId]);

  const addFiles = async (givenPaths = null) => {
    if (!isElectron) return;
    const picked = givenPaths ?? await window.electronAPI.openFile();
    const filePaths = Array.isArray(picked) ? picked.filter(Boolean) : (picked ? [picked] : []);
    if (!filePaths.length) return;
    setErrorMsg('');
    try {
      const res = await window.electronAPI.attachments.add({ itemId, isSubtask: !!isSubtask, filePaths: mergeUniqueFilePaths([], filePaths), actor, isAdmin });
      if (res?.ok) {
        await refreshAttachments();
        if (res.failed?.length) setErrorMsg(`${res.failed.length} file(s) could not be attached.`);
      } else {
        setErrorMsg(res?.error || 'Unable to add attachment.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to add attachment.');
    }
  };

  const handleAdd = async () => {
    const paths = parseFilePathsFromText(manualPath);
    if (paths.length) {
      await addFiles(paths);
      setManualPath('');
      return;
    }
    await addFiles();
  };

  const canRemoveFile = (att) => {
    if (typeof canRemoveAttachment === 'function') return !!canRemoveAttachment(att);
    return true;
  };

  const removeFile = async (att) => {
    if (!isElectron) return;
    if (!canRemoveFile(att)) return;
    await window.electronAPI.attachments.remove({ id: att.id, actor });
    setAttachments(prev => prev.filter(a => a.id !== att.id));
  };

  const openFile = (path) => {
    if (isElectron) window.electronAPI.openPath(path);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    const dropped = Array.from(e.dataTransfer?.files || []).map(f => f.path).filter(Boolean);
    const textPaths = parseFilePathsFromText(e.dataTransfer?.getData('text') || '');
    const all = mergeUniqueFilePaths(dropped, textPaths);
    if (all.length) await addFiles(all);
  };

  return (
    <Modal open={open} onClose={onClose} title={`Attachments - ${itemName || itemId}`} width={640}>
      <div style={{ fontSize: 13, color: '#64748b', marginBottom: 12 }}>
        {attachments.length} file{attachments.length !== 1 ? 's' : ''} attached
      </div>

      {canAdd && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 10, alignItems: 'center' }}>
          <input
            value={manualPath}
            onChange={e => setManualPath(e.target.value)}
            onPaste={async (e) => {
              const pastedPaths = await getPastedAttachmentPaths(e);
              if (!pastedPaths.length) return;
              e.preventDefault();
              await addFiles(pastedPaths);
            }}
            placeholder="Paste file path(s) here or press Ctrl+V after copying files"
            style={{ ...inputStyle, flex: 1 }}
          />
          <button onClick={handleAdd} style={{ ...btnPrimary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add</button>
        </div>
      )}

      {canAdd && (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={handleDrop}
          style={{ textAlign: 'center', fontSize: 13, color: '#64748b', marginBottom: 12 }}
        >
          Drag & Drop Files or <button type="button" onClick={() => addFiles()} style={{ background: 'none', border: 'none', color: '#0d9488', cursor: 'pointer', fontWeight: 600, padding: 0 }}>Browse</button>
        </div>
      )}
      {errorMsg && <div style={{ fontSize: 12, color: '#dc2626', marginBottom: 10 }}>{errorMsg}</div>}

      {attachments.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 14, color: '#94a3b8', border: '1px dashed #e2e8f0', borderRadius: 10 }}>
          No attachments yet
        </div>
      ) : (
        <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflowX: 'auto', overflowY: 'hidden', maxWidth: '100%' }}>
          <table style={{ width: 840, minWidth: 840, borderCollapse: 'collapse', fontSize: 13, tableLayout: 'fixed' }}>
            <colgroup>
              <col style={{ width: 280 }} />
              <col style={{ width: 320 }} />
              <col style={{ width: 150 }} />
              <col style={{ width: 90 }} />
            </colgroup>
            <thead>
              <tr style={{ background: '#f1f5f9' }}>
                <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0' }}>File Name</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0' }}>Path</th>
                <th style={{ padding: '8px 12px', textAlign: 'left', fontWeight: 600, color: '#475569', fontSize: 12, borderBottom: '2px solid #e2e8f0' }}>Added</th>
                <th style={{ padding: '8px 12px', width: 90, borderBottom: '2px solid #e2e8f0', position: 'sticky', right: 0, background: '#f1f5f9', zIndex: 1 }} />
              </tr>
            </thead>
            <tbody>
              {attachments.map(a => (
                <tr key={a.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                  <td style={{ padding: '8px 12px', fontWeight: 600 }}>
                    <div title={a.fileName || ''} style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 0 }}>
                      <FileText size={14} color="#3b82f6" style={{ flexShrink: 0 }} />
                      <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.fileName}</span>
                    </div>
                  </td>
                  <td title={a.filePath || ''} style={{ padding: '8px 12px', color: '#64748b', fontSize: 12, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{a.filePath}</td>
                  <td style={{ padding: '8px 12px', color: '#94a3b8', fontSize: 12, whiteSpace: 'nowrap' }}>{a.addedOn}</td>
                  <td style={{ padding: '8px 12px', position: 'sticky', right: 0, background: '#fff' }}>
                    <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                      <button onClick={() => openFile(a.filePath)} title="Open file"
                        style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 5, padding: '3px 6px', cursor: 'pointer', color: '#3b82f6' }}>
                        <ExternalLink size={12} />
                      </button>
                      <button
                        onClick={() => removeFile(a)}
                        title={canRemoveFile(a) ? 'Remove' : 'Only files uploaded by you can be removed'}
                        disabled={!canRemoveFile(a)}
                        style={{ background: 'none', border: '1px solid #fca5a5', borderRadius: 5, padding: '3px 6px', cursor: canRemoveFile(a) ? 'pointer' : 'not-allowed', color: '#ef4444', opacity: canRemoveFile(a) ? 1 : 0.45 }}
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}

//  Reminder Manager Modal //
function ReminderManager({ open, onClose, itemId, isSubtask, itemName, dueDate }) {
  const [minutes, setMinutes] = useState(0);
  const [saved, setSaved] = useState(false);
  const PRESETS = [
    { label: 'None', value: 0 },
    { label: '5 min before', value: 5 },
    { label: '15 min before', value: 15 },
    { label: '30 min before', value: 30 },
    { label: '1 hour before', value: 60 },
    { label: '2 hours before', value: 120 },
    { label: '1 day before', value: 1440 },
    { label: '2 days before', value: 2880 },
  ];

  useEffect(() => {
    if (!open || !itemId) return;
    if (isElectron) {
      window.electronAPI.reminders.get({ itemId, isSubtask: !!isSubtask }).then(res => {
        setMinutes(res.minutes || 0);
      });
    }
    setSaved(false);
  }, [open, itemId]);

  const save = async () => {
    if (isElectron) {
      await window.electronAPI.reminders.set({ itemId, isSubtask: !!isSubtask, dueDate, remindMinutes: String(minutes) });
    }
    setSaved(true);
    setTimeout(() => onClose(), 800);
  };

  const remindAtStr = () => {
    if (!dueDate || !minutes) return null;
    try {
      const parts = dueDate.split(' ');
      const dParts = parts[0].split('-');
      const d = new Date(2000 + parseInt(dParts[2]), parseInt(dParts[1]) - 1, parseInt(dParts[0]));
      if (parts[1]) { const [h, m] = parts[1].split(':'); d.setHours(parseInt(h), parseInt(m)); }
      d.setTime(d.getTime() - minutes * 60000);
      return fmtFull(d);
    } catch { return null; }
  };

  return (
    <Modal open={open} onClose={onClose} title={`Reminder - ${itemName || itemId}`} width={440}>
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 13, color: '#64748b', marginBottom: 12 }}>
          Due: <span style={{ fontWeight: 600, color: '#0f172a' }}>{dueDate || 'Not set'}</span>
        </div>

        <FormField label="Remind me">
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {PRESETS.map(p => (
              <button key={p.value} onClick={() => { setMinutes(p.value); setSaved(false); }}
                style={{ padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: minutes === p.value ? '2px solid #0d9488' : '1.5px solid #d1d5db', background: minutes === p.value ? '#f0fdfa' : '#fff', color: minutes === p.value ? '#0d9488' : '#475569', transition: 'all 0.15s' }}>
                {p.label}
              </button>
            ))}
          </div>
        </FormField>

        <FormField label="Custom (minutes)">
          <input type="number" value={minutes} onChange={e => { setMinutes(parseInt(e.target.value) || 0); setSaved(false); }}
            style={{ ...inputStyle, width: 120 }} min="0" />
        </FormField>

        {minutes > 0 && remindAtStr() && (
          <div style={{ background: '#f0fdfa', border: '1px solid #99f6e4', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#0d9488', display: 'flex', alignItems: 'center', gap: 8 }}>
            <BellRing size={14} />
            Reminder will fire at <span style={{ fontWeight: 700 }}>{remindAtStr()}</span>
          </div>
        )}
      </div>

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
        <button onClick={onClose} style={btnSecondary}>Cancel</button>
        <button onClick={save} style={btnPrimary}>
          {saved ? <><Check size={14} /> Saved!</> : <><BellRing size={14} /> Set Reminder</>}
        </button>
      </div>
    </Modal>
  );
}

//  Reminders Panel (Bell button in top bar) //
function ReminderListPanel({ open, onClose, currentUser, isAdmin }) {
  const [reminders, setReminders] = useState([]);

  useEffect(() => {
    if (!open) return;
    if (isElectron) {
      window.electronAPI.reminders.due({ user: currentUser, isAdmin }).then(setReminders);
    }
  }, [open, currentUser]);

  return (
    <Modal open={open} onClose={onClose} title={`Due Reminders (${reminders.length})`} width={700}>
      {reminders.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 30, color: '#94a3b8' }}>
          <BellRing size={32} style={{ marginBottom: 8, opacity: 0.3 }} />
          <div>No due reminders right now</div>
        </div>
      ) : (
        <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
            <thead>
              <tr style={{ background: '#f1f5f9' }}>
                {['Type', 'ID', 'Task', 'Assigned To', 'Due Date', 'Remind At', 'Status'].map((h, i) => (
                  <th key={i} style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, color: '#475569', borderBottom: '2px solid #e2e8f0' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {reminders.map((r, i) => (
                <tr key={i} style={{ borderBottom: '1px solid #f1f5f9', background: r.isDue ? '#fff7ed' : 'transparent' }}>
                  <td style={{ padding: '8px 10px' }}><span style={{ background: r.isSubtask ? '#ede9fe' : '#dbeafe', color: r.isSubtask ? '#7c3aed' : '#1d4ed8', padding: '2px 8px', borderRadius: 10, fontSize: 10, fontWeight: 600 }}>{r.isSubtask ? 'Subtask' : 'Task'}</span></td>
                  <td style={{ padding: '8px 10px', fontFamily: "'JetBrains Mono', monospace", fontSize: 10, color: '#94a3b8' }}>{r.itemId}</td>
                  <td style={{ padding: '8px 10px', fontWeight: 600 }}>{r.itemName}{r.parentTaskName ? ` [${r.parentTaskName}]` : ''}</td>
                  <td style={{ padding: '8px 10px' }}>{r.assignedTo}</td>
                  <td style={{ padding: '8px 10px', whiteSpace: 'nowrap' }}>{r.dueDate}</td>
                  <td style={{ padding: '8px 10px', whiteSpace: 'nowrap', color: r.isDue ? '#d97706' : '#64748b', fontWeight: r.isDue ? 700 : 400 }}>{r.remindAt}</td>
                  <td style={{ padding: '8px 10px' }}><StatusBadge status={r.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Modal>
  );
}

//  Notifications Panel //
function NotificationPanel({ open, onClose, notifications, assignmentNotifications = [], currentUser, isAdmin, onRefresh }) {
  const [showArchived, setShowArchived] = useState(false);
  const visibleNotifications = showArchived ? notifications : [...assignmentNotifications, ...notifications];
  const markAllRead = async () => {
    if (isElectron && window.electronAPI?.notifications?.markAllRead) {
      await window.electronAPI.notifications.markAllRead({ user: currentUser, isAdmin, includeArchived: showArchived });
    }
    onRefresh({ includeArchived: showArchived });
  };
  useEffect(() => {
    if (!open) return;
    onRefresh({ includeArchived: showArchived });
  }, [open, showArchived]);
  const unreadCount = visibleNotifications.filter(n => !n?.isRead).length;
  return (
    <Modal open={open} onClose={onClose} title={`Notifications (${visibleNotifications.length})`} width={420}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <div style={{ fontSize: 12, color: '#64748b' }}>{showArchived ? 'Archived activity' : 'Latest 50 notifications'}</div>
        <div style={{ display: 'flex', gap: 10 }}>
          {isAdmin && <button onClick={() => setShowArchived(v => !v)} style={{ background: 'none', border: 'none', color: '#0d9488', cursor: 'pointer', fontSize: 12 }}>{showArchived ? 'Show Latest' : 'Show Archived'}</button>}
          {visibleNotifications.length > 0 && <button onClick={markAllRead} style={{ background: 'none', border: 'none', color: '#0d9488', cursor: 'pointer', fontSize: 12 }}>Mark Read All</button>}
        </div>
      </div>
      {visibleNotifications.length === 0 ? (
        <div style={{ textAlign: 'center', padding: 20, color: '#94a3b8' }}>
          <Bell size={28} style={{ marginBottom: 8, opacity: 0.3 }} />
          <div>No notifications yet</div>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, maxHeight: 420, overflowY: 'auto' }}>
          {visibleNotifications.map((n) => (
            <div key={n.id} style={{ background: n.isRead ? '#f8fafc' : '#ecfeff', border: n.isRead ? '1px solid #e2e8f0' : '1px solid #99f6e4', borderRadius: 12, padding: 12, position: 'relative' }}>
              <div style={{ display: 'flex', gap: 10 }}>
                <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#0d9488', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 12 }}>{(n.actor || 'U')[0]}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{n.title} {!n.isRead && <span style={{ fontSize: 10, color: '#0d9488', marginLeft: 6 }}>NEW</span>}</div>
                  {n.message && <div style={{ fontSize: 12, color: '#475569', marginTop: 2 }}>{n.message}</div>}
                  {n.ts && <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 6 }}>{n.ts}</div>}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
      {unreadCount > 0 && <div style={{ marginTop: 10, fontSize: 11, color: '#0f766e' }}>{unreadCount} unread notification{unreadCount !== 1 ? 's' : ''}</div>}
    </Modal>
  );
}

function SubtaskCommentsPanel({ open, subtask, task, currentUser, isAdmin = false }) {
  const [comments, setComments] = useState([]);
  const [message, setMessage] = useState('');
  const [pendingFiles, setPendingFiles] = useState([]);
  const [manualPath, setManualPath] = useState('');
  const [sending, setSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const { widths: sharedColumnWidths } = React.useContext(ColumnWidthContext);
  const messageColumnWidth = (key, fallback) => Math.max(key === 'srNo' ? 42 : 48, Number(sharedColumnWidths?.messages?.[key] || fallback || 120));
  const messageTableWidth = messageTableColumns.reduce((sum, col) => sum + messageColumnWidth(col.key, col.width), 0);

  const load = useCallback(async () => {
    if (!open || !subtask?.id || !isElectron || !window.electronAPI?.subtaskComments?.list) return;
    const rows = await window.electronAPI.subtaskComments.list({ subtaskId: subtask.id, actor: currentUser, isAdmin });
    setComments(Array.isArray(rows) ? rows : []);
    setErrorMsg('');
  }, [open, subtask?.id, currentUser, isAdmin]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    setMessage('');
    setPendingFiles([]);
    setManualPath('');
    setErrorMsg('');
  }, [subtask?.id]);

  const pickFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setPendingFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualPath = () => {
    const paths = parseFilePathsFromText(manualPath);
    if (!paths.length) return;
    setPendingFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualPath('');
  };
  const fileLabel = (p) => {
    const parts = String(p || '').split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const send = async () => {
    if (!subtask?.id || !isElectron || !window.electronAPI?.subtaskComments?.add) return;
    if (!message.trim() && pendingFiles.length === 0) return;
    setSending(true);
    setErrorMsg('');
    try {
      const res = await window.electronAPI.subtaskComments.add({
        subtaskId: subtask.id,
        actor: currentUser,
        message: message.trim(),
        filePaths: pendingFiles,
        isAdmin,
      });
      if (res?.ok) {
        setMessage('');
        setPendingFiles([]);
        setManualPath('');
        await load();
        if (res.failed?.length) setErrorMsg(`${res.failed.length} file(s) could not be attached.`);
      } else {
        setErrorMsg(res?.error || 'Unable to send message.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to send message.');
    } finally {
      setSending(false);
    }
  };
  const deleteComment = async (comment) => {
    if (!comment?.id || !isElectron || !window.electronAPI?.subtaskComments?.delete) return;
    const res = await window.electronAPI.subtaskComments.delete({ commentId: comment.id, actor: currentUser, isAdmin });
    if (res?.ok) setComments(prev => prev.filter(c => c.id !== comment.id));
    else setErrorMsg(res?.error || 'Unable to delete message.');
  };
  const canDeleteComment = (comment) => (
    !!isAdmin || String(comment?.author || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase()
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ ...shadcnMutedPanel, maxHeight: messageTableMaxHeight, minHeight: 118, overflow: 'auto' }}>
        {comments.length === 0 ? (
          <div style={{ color: '#94a3b8', fontSize: 12, textAlign: 'center', padding: 14 }}>No messages yet</div>
        ) : (
          <table style={{ width: `max(100%, ${messageTableWidth}px)`, borderCollapse: 'collapse', fontSize: 12, background: '#fff', tableLayout: 'fixed' }}>
            <colgroup>{messageTableColumns.map(col => <col key={col.key} style={{ width: messageColumnWidth(col.key, col.width) }} />)}</colgroup>
            <thead>
              <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e5e7eb' }}>
                {messageTableColumns.map(col => (
                  <ResizableHeaderCell key={col.key} tableKey="messages" columnKey={col.key} locked={col.locked} style={{ padding: '8px 10px', textAlign: 'left', width: messageColumnWidth(col.key, col.width), fontWeight: 600, color: '#475569' }}>
                    {col.label}
                  </ResizableHeaderCell>
                ))}
              </tr>
            </thead>
            <tbody>
              {comments.map((c, index) => {
                const atts = Array.isArray(c.attachments) ? c.attachments : [];
                return (
                  <tr key={c.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '8px 10px', color: '#64748b', verticalAlign: 'top' }}>{index + 1}</td>
                    <td style={{ padding: '8px 10px', color: '#0f172a', fontWeight: 500, verticalAlign: 'top' }}>
                      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
                        {c.isUnread && <span title="New message" style={{ width: 8, height: 8, borderRadius: 999, background: '#ef4444', display: 'inline-block', flexShrink: 0 }} />}
                        {c.author || 'User'}
                      </span>
                    </td>
                    <td style={{ padding: '8px 10px', color: '#64748b', whiteSpace: 'nowrap', verticalAlign: 'top' }}>{c.created_on || '-'}</td>
                    <td style={{ padding: '8px 10px', color: '#0f172a', whiteSpace: 'pre-wrap', verticalAlign: 'top' }}>{c.message || '-'}</td>
                    <td style={{ padding: '8px 10px', verticalAlign: 'top' }}>
                      {atts.length === 0 ? <span style={{ color: '#94a3b8' }}>-</span> : (
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                          {atts.map((a) => (
                            <button key={a.id} onClick={() => isElectron && window.electronAPI.openPath(a.file_path || a.filePath || a.path || '')} style={{ ...shadcnGhostButton, padding: '4px 8px', fontSize: 11 }}>
                              <Paperclip size={12} /> {a.file_name || 'Attachment'}
                            </button>
                          ))}
                        </div>
                      )}
                    </td>
                    <td style={{ padding: '6px 8px', verticalAlign: 'top', textAlign: 'right' }}>
                      {canDeleteComment(c) && (
                        <button type="button" onClick={() => deleteComment(c)} title="Delete message" style={{ width: 22, height: 22, border: '1px solid #fecaca', borderRadius: 6, background: '#fff', color: '#ef4444', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}>
                          <X size={13} />
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
      <textarea value={message} onChange={e => setMessage(e.target.value)} style={{ ...inputStyle, minHeight: 48, resize: 'vertical', border: '1px solid #e5e7eb', borderRadius: 8 }} placeholder={`Type a message for ${subtask?.name || task?.name || 'subtask'}...`} />
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <input
          value={manualPath}
          onChange={e => setManualPath(e.target.value)}
          onPaste={async (e) => {
            const pastedPaths = await getPastedAttachmentPaths(e);
            if (!pastedPaths.length) return;
            e.preventDefault();
            setPendingFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
          }}
          placeholder="Paste file path(s) or copy-paste files"
          style={{ ...inputStyle, flex: '1 1 220px', border: '1px solid #e5e7eb', borderRadius: 8 }}
        />
        <button onClick={addManualPath} style={shadcnGhostButton}>Add Path</button>
        <button onClick={pickFiles} style={shadcnGhostButton}><Paperclip size={13} /> Add Files</button>
        <button onClick={send} disabled={sending || (!message.trim() && pendingFiles.length === 0)} style={{ ...btnPrimary, opacity: (sending || (!message.trim() && pendingFiles.length === 0)) ? 0.6 : 1 }}>
          {sending ? 'Sending...' : 'Send'}
        </button>
      </div>
      {pendingFiles.length > 0 && (
        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
          {pendingFiles.map((p, i) => (
            <span key={`${p}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#eef2ff', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
              {fileLabel(p)}
              <button type="button" onClick={() => setPendingFiles(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
            </span>
          ))}
        </div>
      )}
      {errorMsg && <div style={{ fontSize: 12, color: '#dc2626' }}>{errorMsg}</div>}
    </div>
  );
}

function TaskCommentsModal({ open, onClose, task, currentUser, isAdmin = false, onRead, embedded = false }) {
  const [comments, setComments] = useState([]);
  const [message, setMessage] = useState('');
  const [pendingFiles, setPendingFiles] = useState([]);
  const [manualPath, setManualPath] = useState('');
  const [sending, setSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const { widths: sharedColumnWidths } = React.useContext(ColumnWidthContext);
  const messageColumnWidth = (key, fallback) => Math.max(key === 'srNo' ? 42 : 48, Number(sharedColumnWidths?.messages?.[key] || fallback || 120));
  const messageTableWidth = messageTableColumns.reduce((sum, col) => sum + messageColumnWidth(col.key, col.width), 0);

  const load = useCallback(async () => {
    if (!open || !task?.id || !isElectron || !window.electronAPI?.taskComments?.list) return;
    const rows = await window.electronAPI.taskComments.list({ taskId: task.id, actor: currentUser, isAdmin });
    setComments(Array.isArray(rows) ? rows : []);
    setErrorMsg('');
    onRead?.(task.id);
  }, [open, task?.id, currentUser, isAdmin, onRead]);

  useEffect(() => { load(); }, [load]);

  const pickFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setPendingFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualPath = () => {
    const paths = parseFilePathsFromText(manualPath);
    if (!paths.length) return;
    setPendingFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualPath('');
  };
  const fileLabel = (p) => {
    const parts = String(p || '').split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };

  const send = async () => {
    if (!task?.id || !isElectron || !window.electronAPI?.taskComments?.add) return;
    if (!message.trim() && pendingFiles.length === 0) return;
    setSending(true);
    setErrorMsg('');
    try {
      const res = await window.electronAPI.taskComments.add({
        taskId: task.id,
        actor: currentUser,
        message: message.trim(),
        filePaths: pendingFiles,
        isAdmin,
      });
      if (res?.ok) {
        setMessage('');
        setPendingFiles([]);
        setManualPath('');
        await load();
        if (res.failed?.length) setErrorMsg(`${res.failed.length} file(s) could not be attached.`);
      } else {
        setErrorMsg(res?.error || 'Unable to send comment.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to send comment.');
    } finally {
      setSending(false);
    }
  };
  const canDeleteComment = (comment) => (
    !!isAdmin || String(comment?.author || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase()
  );
  const deleteComment = async (comment) => {
    if (!comment?.id || !isElectron || !window.electronAPI?.taskComments?.delete) return;
    setErrorMsg('');
    try {
      const res = await window.electronAPI.taskComments.delete({ commentId: comment.id, actor: currentUser, isAdmin });
      if (res?.ok) {
        setComments(prev => prev.filter(c => c.id !== comment.id));
        await load();
      } else {
        setErrorMsg(res?.error || 'Unable to delete message.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to delete message.');
    }
  };

  const content = (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ ...shadcnMutedPanel, maxHeight: messageTableMaxHeight, minHeight: embedded ? 118 : 0, overflow: 'auto' }}>
          {comments.length === 0 ? (
            <div style={{ color: '#94a3b8', fontSize: 12, textAlign: 'center', padding: 14 }}>No comments yet</div>
          ) : (
            <table style={{ width: `max(100%, ${messageTableWidth}px)`, borderCollapse: 'collapse', fontSize: 12, background: '#fff', tableLayout: 'fixed' }}>
              <colgroup>
                {messageTableColumns.map(col => <col key={col.key} style={{ width: messageColumnWidth(col.key, col.width) }} />)}
              </colgroup>
              <thead>
                <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e5e7eb' }}>
                  {messageTableColumns.map(col => (
                    <ResizableHeaderCell key={col.key} tableKey="messages" columnKey={col.key} locked={col.locked} style={{ padding: '8px 10px', textAlign: 'left', width: messageColumnWidth(col.key, col.width), fontWeight: 600, color: '#475569' }}>
                      {col.label}
                    </ResizableHeaderCell>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comments.map((c, index) => {
                  const atts = Array.isArray(c.attachments) ? c.attachments : [];
                  return (
                    <tr key={c.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '8px 10px', color: '#64748b', verticalAlign: 'top' }}>{index + 1}</td>
                      <td style={{ padding: '8px 10px', color: '#0f172a', fontWeight: 500, verticalAlign: 'top' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 7 }}>
                          {c.isUnread && <span title="New message" style={{ width: 8, height: 8, borderRadius: 999, background: '#ef4444', display: 'inline-block', flexShrink: 0 }} />}
                          {c.author || 'User'}
                        </span>
                      </td>
                      <td style={{ padding: '8px 10px', color: '#64748b', whiteSpace: 'nowrap', verticalAlign: 'top' }}>{c.created_on || '-'}</td>
                      <td style={{ padding: '8px 10px', color: '#0f172a', whiteSpace: 'pre-wrap', verticalAlign: 'top' }}>{c.message || '-'}</td>
                      <td style={{ padding: '8px 10px', verticalAlign: 'top' }}>
                        {atts.length === 0 ? (
                          <span style={{ color: '#94a3b8' }}>-</span>
                        ) : (
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                            {atts.map((a) => (
                              <button key={a.id} onClick={() => isElectron && window.electronAPI.openPath(a.file_path || a.filePath || a.path || '')} style={{ ...shadcnGhostButton, padding: '4px 8px', fontSize: 11 }}>
                                <Paperclip size={12} /> {a.file_name || 'Attachment'}
                              </button>
                            ))}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '6px 8px', verticalAlign: 'top', textAlign: 'right' }}>
                        {canDeleteComment(c) && (
                          <button
                            type="button"
                            onClick={() => deleteComment(c)}
                            title="Delete message"
                            style={{ width: 22, height: 22, border: '1px solid #fecaca', borderRadius: 6, background: '#fff', color: '#ef4444', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
                          >
                            <X size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>

        <textarea value={message} onChange={e => setMessage(e.target.value)} style={{ ...inputStyle, minHeight: embedded ? 48 : 70, resize: 'vertical', border: '1px solid #e5e7eb', borderRadius: 8 }} placeholder="Type a comment..." />
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            value={manualPath}
            onChange={e => setManualPath(e.target.value)}
            onPaste={async (e) => {
              const pastedPaths = await getPastedAttachmentPaths(e);
              if (!pastedPaths.length) return;
              e.preventDefault();
              setPendingFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
            }}
            placeholder="Paste file path(s) or copy-paste files"
            style={{ ...inputStyle, flex: '1 1 220px', border: '1px solid #e5e7eb', borderRadius: 8 }}
          />
          <button onClick={addManualPath} style={shadcnGhostButton}>Add Path</button>
          <button onClick={pickFiles} style={shadcnGhostButton}><Paperclip size={13} /> Add Files</button>
          <button onClick={send} disabled={sending || (!message.trim() && pendingFiles.length === 0)} style={{ ...btnPrimary, opacity: (sending || (!message.trim() && pendingFiles.length === 0)) ? 0.6 : 1 }}>
            {sending ? 'Sending...' : 'Send'}
          </button>
        </div>
        {pendingFiles.length > 0 && (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {pendingFiles.map((p, i) => (
              <span key={`${p}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#eef2ff', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
                {fileLabel(p)}
                <button type="button" onClick={() => setPendingFiles(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
              </span>
            ))}
          </div>
        )}
        {errorMsg && <div style={{ fontSize: 12, color: '#dc2626' }}>{errorMsg}</div>}
      </div>
  );

  if (embedded) return content;
  return (
    <Modal open={open} onClose={onClose} title={`Comments - ${task?.name || task?.id || ''}`} width={700}>
      {content}
    </Modal>
  );
}

function IssueCommentsModal({ open, onClose, issue, currentUser, isAdmin = false, embedded = false, draftMessage, onDraftMessageChange, draftFiles, onDraftFilesChange }) {
  const [comments, setComments] = useState([]);
  const [localMessage, setLocalMessage] = useState('');
  const [localFiles, setLocalFiles] = useState([]);
  const [manualPath, setManualPath] = useState('');
  const [sending, setSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const message = draftMessage !== undefined ? draftMessage : localMessage;
  const setMessage = onDraftMessageChange || setLocalMessage;
  const pendingFiles = draftFiles !== undefined ? draftFiles : localFiles;
  const setPendingFiles = onDraftFilesChange || setLocalFiles;
  const canSendNow = !!issue?.id;
  const { widths: sharedColumnWidths } = React.useContext(ColumnWidthContext);
  const messageColumnWidth = (key, fallback) => Math.max(key === 'srNo' ? 42 : 48, Number(sharedColumnWidths?.messages?.[key] || fallback || 120));
  const messageTableWidth = messageTableColumns.reduce((sum, col) => sum + messageColumnWidth(col.key, col.width), 0);

  const load = useCallback(async () => {
    if (!open || !issue?.id || !isElectron || !window.electronAPI?.issueComments?.list) return;
    const rows = await window.electronAPI.issueComments.list({ issueId: issue.id, actor: currentUser, isAdmin });
    setComments(Array.isArray(rows) ? rows : []);
    setErrorMsg('');
  }, [open, issue?.id, currentUser, isAdmin]);

  useEffect(() => { load(); }, [load]);

  const pickFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setPendingFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualPath = () => {
    const paths = parseFilePathsFromText(manualPath);
    if (!paths.length) return;
    setPendingFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualPath('');
  };
  const fileLabel = (p) => {
    const parts = String(p || '').split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const send = async () => {
    if (!issue?.id || !isElectron || !window.electronAPI?.issueComments?.add) return;
    if (!message.trim() && pendingFiles.length === 0) return;
    setSending(true);
    setErrorMsg('');
    try {
      const res = await window.electronAPI.issueComments.add({
        issueId: issue.id,
        actor: currentUser,
        message: message.trim(),
        filePaths: pendingFiles,
        isAdmin,
      });
      if (res?.ok) {
        setMessage('');
        setPendingFiles([]);
        setManualPath('');
        await load();
        if (res.failed?.length) setErrorMsg(`${res.failed.length} file(s) could not be attached.`);
      } else {
        setErrorMsg(res?.error || 'Unable to send message.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to send message.');
    } finally {
      setSending(false);
    }
  };
  const canDeleteComment = (comment) => (
    !!isAdmin || String(comment?.author || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase()
  );
  const deleteComment = async (comment) => {
    if (!comment?.id || !isElectron || !window.electronAPI?.issueComments?.delete) return;
    setErrorMsg('');
    try {
      const res = await window.electronAPI.issueComments.delete({ commentId: comment.id, actor: currentUser, isAdmin });
      if (res?.ok) {
        setComments(prev => prev.filter(c => c.id !== comment.id));
        await load();
      } else {
        setErrorMsg(res?.error || 'Unable to delete message.');
      }
    } catch (err) {
      setErrorMsg(err?.message || 'Unable to delete message.');
    }
  };

  const content = (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        <div style={{ ...shadcnMutedPanel, maxHeight: messageTableMaxHeight, minHeight: embedded ? 118 : 0, overflow: 'auto' }}>
          {comments.length === 0 ? (
            <div style={{ color: '#94a3b8', fontSize: 12, textAlign: 'center', padding: 14 }}>No history yet</div>
          ) : (
            <table style={{ width: `max(100%, ${messageTableWidth}px)`, borderCollapse: 'collapse', fontSize: 12, background: '#fff', tableLayout: 'fixed' }}>
              <colgroup>
                {messageTableColumns.map(col => <col key={col.key} style={{ width: messageColumnWidth(col.key, col.width) }} />)}
              </colgroup>
              <thead>
                <tr style={{ background: '#f8fafc', borderBottom: '1px solid #e5e7eb' }}>
                  {messageTableColumns.map(col => (
                    <ResizableHeaderCell key={col.key} tableKey="messages" columnKey={col.key} locked={col.locked} style={{ padding: '8px 10px', textAlign: 'left', width: messageColumnWidth(col.key, col.width), fontWeight: 600, color: '#475569' }}>
                      {col.label}
                    </ResizableHeaderCell>
                  ))}
                </tr>
              </thead>
              <tbody>
                {comments.map((c, index) => {
                  const atts = Array.isArray(c.attachments) ? c.attachments : [];
                  return (
                    <tr key={c.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                      <td style={{ padding: '8px 10px', color: '#64748b', verticalAlign: 'top' }}>{index + 1}</td>
                      <td style={{ padding: '8px 10px', color: '#0f172a', fontWeight: 500, verticalAlign: 'top' }}>{c.author || 'User'}</td>
                      <td style={{ padding: '8px 10px', color: '#64748b', whiteSpace: 'nowrap', verticalAlign: 'top' }}>{c.created_on || '-'}</td>
                      <td style={{ padding: '8px 10px', color: '#0f172a', whiteSpace: 'pre-wrap', verticalAlign: 'top' }}>{c.message || '-'}</td>
                      <td style={{ padding: '8px 10px', verticalAlign: 'top' }}>
                        {atts.length === 0 ? (
                          <span style={{ color: '#94a3b8' }}>-</span>
                        ) : (
                          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                            {atts.map((a) => (
                              <button key={a.id} onClick={() => isElectron && window.electronAPI.openPath(a.file_path || a.filePath || a.path || '')} style={{ ...shadcnGhostButton, padding: '4px 8px', fontSize: 11 }}>
                                <Paperclip size={12} /> {a.file_name || 'Attachment'}
                              </button>
                            ))}
                          </div>
                        )}
                      </td>
                      <td style={{ padding: '6px 8px', verticalAlign: 'top', textAlign: 'right' }}>
                        {canDeleteComment(c) && (
                          <button
                            type="button"
                            onClick={() => deleteComment(c)}
                            title="Delete message"
                            style={{ width: 22, height: 22, border: '1px solid #fecaca', borderRadius: 6, background: '#fff', color: '#ef4444', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', padding: 0 }}
                          >
                            <X size={13} />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
        <textarea value={message} onChange={e => setMessage(e.target.value)} style={{ ...inputStyle, minHeight: embedded ? 48 : 70, resize: 'vertical', border: '1px solid #e5e7eb', borderRadius: 8 }} placeholder={canSendNow ? 'Type a message...' : 'Type the first message...'} />
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
          <input
            value={manualPath}
            onChange={e => setManualPath(e.target.value)}
            onPaste={async (e) => {
              const pastedPaths = await getPastedAttachmentPaths(e);
              if (!pastedPaths.length) return;
              e.preventDefault();
              setPendingFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
            }}
            placeholder="Paste file path(s) or copy-paste files"
            style={{ ...inputStyle, flex: '1 1 220px', border: '1px solid #e5e7eb', borderRadius: 8 }}
          />
          <button onClick={addManualPath} style={shadcnGhostButton}>Add Path</button>
          <button onClick={pickFiles} style={shadcnGhostButton}><Paperclip size={13} /> Add Files</button>
          {canSendNow && <button onClick={send} disabled={sending || (!message.trim() && pendingFiles.length === 0)} style={{ ...btnPrimary, opacity: (sending || (!message.trim() && pendingFiles.length === 0)) ? 0.6 : 1 }}>
            {sending ? 'Sending...' : 'Send'}
          </button>}
        </div>
        {pendingFiles.length > 0 && (
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {pendingFiles.map((p, i) => (
              <span key={`${p}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#f8fafc', color: '#334155', padding: '3px 8px', borderRadius: 6, border: '1px solid #e5e7eb' }}>
                {fileLabel(p)}
                <button type="button" onClick={() => setPendingFiles(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
              </span>
            ))}
          </div>
        )}
        {errorMsg && <div style={{ fontSize: 12, color: '#dc2626' }}>{errorMsg}</div>}
      </div>
  );

  if (embedded) return content;
  return (
    <Modal open={open} onClose={onClose} title={`Issue Chat - ${issue?.title || issue?.id || ''}`} width={700}>
      {content}
    </Modal>
  );
}

function ExtendTaskModal({ open, task, onClose, onSave }) {
  const [durationVal, setDurationVal] = useState('1');
  const [durationUnit, setDurationUnit] = useState('Days');
  const [comment, setComment] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setDurationVal('1');
    setDurationUnit('Days');
    setComment('');
    setSaving(false);
  }, [open, task?.id]);

  const nextDue = useMemo(() => dueDateFromDuration(durationVal, durationUnit, true), [durationVal, durationUnit]);

  const handleSave = async () => {
    if (!task || saving) return;
    setSaving(true);
    try {
      await onSave?.({
        task,
        durationVal: durationVal || '1',
        durationUnit: durationUnit || 'Days',
        comment: String(comment || '').trim(),
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal open={open} onClose={onClose} title={`Extend Task - ${task?.id || ''}`} width={460}>
      <div style={{ display: 'grid', gap: 14 }}>
        <FormField label="Extend Duration">
          <div style={{ display: 'flex', gap: 8 }}>
            <input type="number" min="1" value={durationVal} onChange={e => setDurationVal(e.target.value)} style={{ ...inputStyle, width: 90 }} />
            <select value={durationUnit} onChange={e => setDurationUnit(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
              <option>Hours</option>
              <option>Days</option>
              <option>Weeks</option>
            </select>
          </div>
          <div style={{ fontSize: 12, color: '#64748b', marginTop: 6 }}>New due date: <b>{nextDue || '-'}</b></div>
        </FormField>
        <div style={{ ...shadcnMutedPanel, padding: 12 }}>
          <div style={{ ...shadcnLabel, marginBottom: 8 }}>Attributed To</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            <div>
              <div style={{ fontSize: 11, color: '#64748b', marginBottom: 3 }}>Assignor</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#0f172a' }}>{task?.assignedBy || '-'}</div>
            </div>
            <div>
              <div style={{ fontSize: 11, color: '#64748b', marginBottom: 3 }}>Assignee</div>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#0f172a' }}>{task?.assignedTo || '-'}</div>
            </div>
          </div>
        </div>
        <FormField label="Comment">
          <textarea
            value={comment}
            onChange={e => setComment(e.target.value)}
            placeholder="Enter reason or note for extension"
            style={{ ...inputStyle, minHeight: 76, resize: 'vertical' }}
          />
        </FormField>
      </div>
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 18 }}>
        <button onClick={onClose} style={btnSecondary}>Cancel</button>
        <button onClick={handleSave} disabled={saving} style={{ ...btnPrimary, opacity: saving ? 0.7 : 1 }}>{saving ? 'Extending...' : 'Extend'}</button>
      </div>
    </Modal>
  );
}

function TaskModal({ open, onClose, task, employees, projects, subtasks, tasks, taskTemplates, onSaveTemplate, onAddSubtask, onUpdateSubtask, onSave, onDelete, onExtendOverdue, currentUser, userRole, unreadCommentsCount = 0, onCommentsRead }) {
  const [form, setForm] = useState({});
  const [showAttachments, setShowAttachments] = useState(false);
  const [showReminder, setShowReminder] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState([]);
  const [pendingVoiceNotes, setPendingVoiceNotes] = useState([]);
  const [pendingSubtasks, setPendingSubtasks] = useState([]);
  const [showSubtaskForm, setShowSubtaskForm] = useState(false);
  const [editingSubtask, setEditingSubtask] = useState(null);
  const [saveAsTemplate, setSaveAsTemplate] = useState(false);
  const [manualAttachmentPath, setManualAttachmentPath] = useState('');
  const [dueDateManuallyChanged, setDueDateManuallyChanged] = useState(false);
  const dueDateInputRef = useRef(null);
  const isEmployeeUser = isBaseRole(userRole);
  const canAssignSystemAdmin = String(currentUser || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase();
  const isAdminLike = isAdminLikeRole(userRole);
  const isNewTask = !task;
  const lockAssignmentFields = isEmployeeUser && !!task && String(task.assignedBy || '').toLowerCase() !== String(currentUser || '').toLowerCase();
  const isTaskOwner = !!task && (String(task.assignedTo || '') === String(currentUser || '') || String(task.assignedBy || '') === String(currentUser || ''));
  const canExtendCurrentTask = !!task && timeLeft(task?.dueDate || '') === 'Overdue' && String(task.assignedBy || '').trim().toLowerCase() === String(currentUser || '').trim().toLowerCase();
  const isSubtaskAssigneeOnTask = useMemo(
    () => !!task?.id && (subtasks || []).some(s => String(s.taskId || '') === String(task.id) && String(s.assignedTo || '') === String(currentUser || '')),
    [task?.id, subtasks, currentUser]
  );
  const isSubtaskLimitedUser = !!task && isSubtaskAssigneeOnTask && !isTaskOwner && !isAdminLike;
  const allUserOptions = useMemo(
    () => employees.map(e => e.name).filter(Boolean),
    [employees]
  );
  const assignedToOptions = (isEmployeeUser && isNewTask)
    ? [currentUser].filter(Boolean)
    : employees
        .filter(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME || e.name === form.assignedTo)
        .map(e => e.name);
  const assignedByOptions = (isEmployeeUser && isNewTask)
    ? allUserOptions
    : employees.map(e => e.name);

  useEffect(() => {
    if (!open) return;
    const fallbackAssignedBy = (isEmployeeUser && isNewTask)
      ? (allUserOptions[0] || currentUser)
      : currentUser;
    setForm(task || {
      name: '',
      description: '',
      assignedTo: (isEmployeeUser && isNewTask)
        ? (currentUser || '')
        : (employees.find(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME)?.name || employees[0]?.name || ''),
      assignedBy: fallbackAssignedBy,
      durationVal: '1',
      durationUnit: 'Days',
      dueDate: dueDateFromDuration('1', 'Days', true),
      status: 'Not Started',
      remarks: '',
      projectId: '',
    });
    setShowAttachments(false);
    setShowReminder(false);
    setPendingAttachments([]);
    setPendingVoiceNotes([]);
    setPendingSubtasks([]);
    setShowSubtaskForm(false);
    setEditingSubtask(null);
    setSaveAsTemplate(false);
    setManualAttachmentPath('');
    setDueDateManuallyChanged(false);
  }, [open, task, employees, currentUser, isEmployeeUser, isNewTask, allUserOptions, canAssignSystemAdmin]);

  useEffect(() => {
    if (!open) return;
    if (!(isEmployeeUser && isNewTask)) return;
    setForm(prev => {
      const nextAssignedBy = allUserOptions.includes(prev.assignedBy)
        ? prev.assignedBy
        : (allUserOptions[0] || currentUser || '');
      return {
        ...prev,
        assignedTo: currentUser || '',
        assignedBy: nextAssignedBy,
      };
    });
  }, [open, isEmployeeUser, isNewTask, allUserOptions, currentUser]);

  const pickFiles = async (setter) => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setter(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualAttachmentPath = () => {
    const paths = parseFilePathsFromText(manualAttachmentPath);
    if (!paths.length) return;
    setPendingAttachments(prev => mergeUniqueFilePaths(prev, paths));
    setManualAttachmentPath('');
  };

  const fileLabel = (p) => {
    const parts = p.split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };

  const existingSubtasks = task?.id ? (subtasks || []).filter(s => s.taskId === task.id) : [];
  const dueDateTimeInput = useMemo(() => {
    const raw = form.dueDate || '';
    if (!raw) return '';
    const [datePart, timePart] = raw.split(' ');
    const [dd, mm, yy] = (datePart || '').split('-');
    if (!dd || !mm || !yy) return '';
    const t = (timePart && /^\d{2}:\d{2}$/.test(timePart)) ? timePart : '09:00';
    return `20${yy}-${mm}-${dd}T${t}`;
  }, [form.dueDate]);
  const setDueDateTimeInput = (value) => {
    setDueDateManuallyChanged(true);
    if (!value) {
      setForm(p => ({ ...p, dueDate: '' }));
      return;
    }
    const [datePart, timePart] = value.split('T');
    if (!datePart) return;
    const [yyyy, mm, dd] = datePart.split('-');
    const time = (timePart && /^\d{2}:\d{2}$/.test(timePart)) ? timePart : '09:00';
    setForm(p => ({ ...p, dueDate: `${dd}-${mm}-${yyyy.slice(-2)} ${time}` }));
  };
  const openDueDatePicker = () => {
    const input = dueDateInputRef.current;
    if (!input || typeof input.showPicker !== 'function') return;
    try { input.showPicker(); } catch {}
  };

  const handleSave = async () => {
    if (isSubtaskLimitedUser) return;
    if (!form.name?.trim()) return;
    if (saveAsTemplate && onSaveTemplate) {
      onSaveTemplate({
        templateName: form.name.trim(),
        name: form.name,
        description: form.description || '',
        assignedTo: form.assignedTo || '',
        status: form.status || 'Not Started',
        durationVal: form.durationVal || '1',
        durationUnit: form.durationUnit || 'Days',
        dueDate: form.dueDate || '',
        projectId: form.projectId || '',
        remarks: form.remarks || '',
      });
    }
    const savedId = await onSave(form);
    const itemId = task?.id || savedId;
    const allFiles = [...pendingAttachments, ...pendingVoiceNotes];
    if (isElectron && itemId && allFiles.length) {
      await window.electronAPI.attachments.add({ itemId, isSubtask: false, filePaths: allFiles, actor: currentUser, isAdmin: isAdminLike });
    }
    if (itemId && pendingSubtasks.length && onAddSubtask) {
      for (const st of pendingSubtasks) {
        const { validationFiles, ...payload } = st;
        const newId = await onAddSubtask({ ...payload, taskId: itemId, assignedBy: currentUser });
        if (isElectron && newId && validationFiles?.length) {
          await window.electronAPI.attachments.add({ itemId: newId, isSubtask: true, filePaths: validationFiles, actor: currentUser, isAdmin: isAdminLike });
        }
      }
    }
    onClose();
  };
  return (
    <Modal open={open} onClose={onClose} title={task ? `Edit Task - ${task.id}` : 'New Task'} width={600}>
      {!task && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 10 }}>
          <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#334155', fontWeight: 500 }}>
            <input type="checkbox" checked={saveAsTemplate} onChange={e => setSaveAsTemplate(e.target.checked)} style={{ accentColor: '#0d9488' }} />
            Save as Task Template
          </label>
          <select
            value=""
            onChange={e => {
              const tpl = taskTemplates.find(t => t.templateName === e.target.value);
              if (!tpl) return;
              setForm(p => ({
                ...p,
                name: tpl.name || p.name,
                description: tpl.description || '',
                assignedTo: tpl.assignedTo || p.assignedTo,
                status: tpl.status || p.status,
                durationVal: tpl.durationVal || p.durationVal,
                durationUnit: tpl.durationUnit || p.durationUnit,
                dueDate: tpl.dueDate || p.dueDate,
                projectId: tpl.projectId || '',
                remarks: tpl.remarks || '',
              }));
            }}
            style={{ ...inputStyle, width: 180, padding: '7px 10px', fontSize: 12 }}
          >
            <option value="">Use Template</option>
            {taskTemplates.map(t => <option key={t.templateName} value={t.templateName}>{t.templateName}</option>)}
          </select>
        </div>
      )}
      <FormField label="Task Name" required><input value={form.name || ''} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} style={inputStyle} disabled={isSubtaskLimitedUser} /></FormField>
      <FormField label="Description"><textarea value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} style={{ ...inputStyle, minHeight: 60, resize: 'vertical' }} disabled={isSubtaskLimitedUser} /></FormField>
      {task && (
        <div style={{ marginTop: 6, marginBottom: 12 }}>
          <div style={{ ...shadcnLabel, marginBottom: 8 }}>Messages</div>
          <TaskCommentsModal
            open={open && !!task?.id}
            embedded
            task={task}
            currentUser={currentUser}
            isAdmin={isAdminLike}
            onRead={onCommentsRead}
          />
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Assigned To">
          <select value={form.assignedTo || ''} onChange={e => setForm(p => ({ ...p, assignedTo: e.target.value }))} style={inputStyle} disabled={isSubtaskLimitedUser || (isEmployeeUser && (isNewTask || lockAssignmentFields))}>
            {assignedToOptions.map(name => <option key={name} value={name}>{name}</option>)}
          </select>
        </FormField>
        <FormField label="Assigned By">
          <select value={form.assignedBy || ''} onChange={e => setForm(p => ({ ...p, assignedBy: e.target.value }))} style={inputStyle} disabled={isSubtaskLimitedUser || lockAssignmentFields}>
            {assignedByOptions.map(name => <option key={name} value={name}>{name}</option>)}
          </select>
        </FormField>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Status"><select value={form.status || 'Not Started'} onChange={e => setForm(p => ({ ...p, status: e.target.value }))} style={inputStyle} disabled={isSubtaskLimitedUser}>{STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}</select></FormField>
        <FormField label="Duration">
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="number"
              value={form.durationVal || '1'}
              onChange={e => {
                const nextVal = e.target.value;
                setForm(p => ({
                  ...p,
                  durationVal: nextVal,
                  dueDate: !dueDateManuallyChanged
                    ? (dueDateFromDuration(nextVal, p.durationUnit || 'Days', true) || p.dueDate)
                    : p.dueDate,
                }));
              }}
              style={{ ...inputStyle, width: 82 }}
              min="1"
              disabled={isSubtaskLimitedUser}
            />
            <select
              value={form.durationUnit || 'Days'}
              onChange={e => {
                const nextUnit = e.target.value;
                setForm(p => ({
                  ...p,
                  durationUnit: nextUnit,
                  dueDate: !dueDateManuallyChanged
                    ? (dueDateFromDuration(p.durationVal || '1', nextUnit, true) || p.dueDate)
                    : p.dueDate,
                }));
              }}
              style={{ ...inputStyle, flex: 1 }}
              disabled={isSubtaskLimitedUser}
            >
              <option>Hours</option><option>Days</option><option>Weeks</option>
            </select>
          </div>
        </FormField>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Due Date & Time"><input ref={dueDateInputRef} type="datetime-local" value={dueDateTimeInput} onChange={e => setDueDateTimeInput(e.target.value)} onClick={openDueDatePicker} onFocus={openDueDatePicker} style={inputStyle} disabled={isSubtaskLimitedUser} /></FormField>
        <FormField label="Project"><select value={form.projectId || ''} onChange={e => setForm(p => ({ ...p, projectId: e.target.value }))} style={inputStyle} disabled={isSubtaskLimitedUser}><option value="">No Project</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></FormField>
      </div>
      <FormField label="Remarks"><textarea value={form.remarks || ''} onChange={e => setForm(p => ({ ...p, remarks: e.target.value }))} style={{ ...inputStyle, minHeight: 50, resize: 'vertical' }} disabled={isSubtaskLimitedUser} /></FormField>

      <div style={{ border: '1px dashed #e2e8f0', borderRadius: 10, padding: 12, marginTop: 6 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>Subtasks</div>
          {!isSubtaskLimitedUser && <button onClick={() => { setEditingSubtask(null); setShowSubtaskForm(true); }} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Plus size={13} /> Add Subtask</button>}
        </div>
        {task && existingSubtasks.length > 0 && (
          <div style={{ border: '1px solid #e2e8f0', borderRadius: 8, overflow: 'hidden', marginBottom: 8 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ background: '#f8fafc' }}>
                  {['Subtask', 'Assigned To', 'Status', ''].map((h, i) => (
                    <th key={`${h}-${i}`} style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, color: '#475569', borderBottom: '1px solid #e2e8f0' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {existingSubtasks.map(s => (
                  <tr key={s.id} style={{ borderBottom: '1px solid #f1f5f9' }}>
                    <td style={{ padding: '8px 10px', fontWeight: 600, color: '#0f172a' }}>{s.name || '-'}</td>
                    <td style={{ padding: '8px 10px', color: '#334155' }}>{s.assignedTo || '-'}</td>
                    <td style={{ padding: '8px 10px' }}><StatusBadge status={s.status || 'Not Started'} /></td>
                    <td style={{ padding: '6px 8px', textAlign: 'right', width: 44 }}>
                      {!isSubtaskLimitedUser && (
                        <button
                          type="button"
                          onClick={() => { setEditingSubtask(s); setShowSubtaskForm(true); }}
                          title="Edit subtask"
                          style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 6, padding: 5, cursor: 'pointer', color: '#475569', display: 'inline-flex', alignItems: 'center' }}
                        >
                          <Edit3 size={12} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {task && existingSubtasks.length === 0 && (
          <div style={{ fontSize: 12, color: '#94a3b8', marginBottom: 6 }}>No subtasks yet</div>
        )}
        {!task && pendingSubtasks.length > 0 && (
          <div style={{ fontSize: 12, color: '#64748b' }}>
            {pendingSubtasks.map((s, i) => (
              <div key={`${s.name}-${i}`} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '4px 0' }}>
                <div>{s.name}  ·  {s.inputType || 'none'}</div>
                <button onClick={() => setPendingSubtasks(prev => prev.filter((_, idx) => idx !== i))} style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 12 }}>Remove</button>
              </div>
            ))}
          </div>
        )}
        {showSubtaskForm && (
          <div style={{ marginTop: 10 }}>
            <SubtaskEditorInline
              subtask={editingSubtask}
              taskId={task?.id || 'pending'}
              parentDueDate={task?.dueDate || form.dueDate || ''}
              employees={employees}
              currentUser={currentUser}
              onSave={async (data) => {
                const { validationFiles, ...payload } = data;
                if (editingSubtask && onUpdateSubtask) {
                  await onUpdateSubtask(editingSubtask.id, payload);
                  if (isElectron && validationFiles?.length) {
                    await window.electronAPI.attachments.add({ itemId: editingSubtask.id, isSubtask: true, filePaths: validationFiles, actor: currentUser, isAdmin: isAdminLike });
                  }
                } else if (task?.id && onAddSubtask) {
                  const newId = await onAddSubtask({ ...payload, taskId: task.id, assignedBy: currentUser });
                  if (isElectron && newId && validationFiles?.length) {
                    await window.electronAPI.attachments.add({ itemId: newId, isSubtask: true, filePaths: validationFiles, actor: currentUser, isAdmin: isAdminLike });
                  }
                } else {
                  setPendingSubtasks(prev => [...prev, { ...payload, validationFiles }]);
                }
                setEditingSubtask(null);
                setShowSubtaskForm(false);
              }}
              onCancel={() => { setShowSubtaskForm(false); setEditingSubtask(null); }}
            />
          </div>
        )}
      </div>

      {!task && (
        <div style={{ border: '1px dashed #e2e8f0', borderRadius: 10, padding: '10px 12px 8px', marginTop: 6 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 6 }}>Attach Files</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
            <input
              value={manualAttachmentPath}
              onChange={e => setManualAttachmentPath(e.target.value)}
              onPaste={async (e) => {
                const pastedPaths = await getPastedAttachmentPaths(e);
                if (!pastedPaths.length) return;
                e.preventDefault();
                setPendingAttachments(prev => mergeUniqueFilePaths(prev, pastedPaths));
              }}
              placeholder="Paste file path(s) here or press Ctrl+V after copying files"
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={addManualAttachmentPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
          </div>
          <div style={{ fontSize: 13, color: '#64748b', marginBottom: 8, textAlign: 'center' }}>
            Drag & Drop Files or <button type="button" onClick={() => pickFiles(setPendingAttachments)} style={{ background: 'none', border: 'none', color: '#0d9488', cursor: 'pointer', fontWeight: 600, padding: 0 }}>Browse</button>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={() => pickFiles(setPendingVoiceNotes)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Mic size={13} /> Add Voice Note</button>
          </div>
          {(pendingAttachments.length > 0 || pendingVoiceNotes.length > 0) && (
            <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {pendingAttachments.map((p, i) => (
                <span key={`att-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#eef2ff', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
                  Attachment: {fileLabel(p)}
                  <button
                    type="button"
                    onClick={() => setPendingAttachments(prev => prev.filter((_, idx) => idx !== i))}
                    style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}
                  >
                    x
                  </button>
                </span>
              ))}
              {pendingVoiceNotes.map((p, i) => (
                <span key={`voice-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#ecfeff', color: '#155e75', padding: '3px 8px', borderRadius: 999 }}>
                  Voice note: {fileLabel(p)}
                  <button
                    type="button"
                    onClick={() => setPendingVoiceNotes(prev => prev.filter((_, idx) => idx !== i))}
                    style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#0e7490', padding: 0, lineHeight: 1 }}
                  >
                    x
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Quick action buttons for existing tasks */}
      {task && (
        <div style={{ display: 'flex', gap: 8, marginTop: 12, marginBottom: 4 }}>
          {canExtendCurrentTask && !isSubtaskLimitedUser && (
            <button
              onClick={() => onExtendOverdue?.(task)}
              style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px', color: '#0f766e', borderColor: '#99f6e4' }}
            >
              <AlarmClockPlus size={13} /> Extend
            </button>
          )}
          <button onClick={() => setShowAttachments(true)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} /> Attachments</button>
          {!isSubtaskLimitedUser && <button onClick={() => setShowReminder(true)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><BellRing size={13} /> Reminder</button>}
        </div>
      )}

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
        {onDelete && !isSubtaskLimitedUser && <button onClick={onDelete} style={{ ...btnDanger, marginRight: 'auto' }}><Trash2 size={14} /> Delete</button>}
        <button onClick={onClose} style={btnSecondary}>Cancel</button>
        {!isSubtaskLimitedUser && <button onClick={handleSave} style={btnPrimary}>{task ? 'Update' : 'Create'} Task</button>}
      </div>

      {/* Nested modals */}
      <AttachmentManager
        open={showAttachments}
        onClose={() => setShowAttachments(false)}
        itemId={task?.id}
        isSubtask={false}
        itemName={task?.name}
        actor={currentUser}
        isAdmin={isAdminLikeRole(userRole)}
        canAdd={!!task}
        canRemoveAttachment={(att) => {
          if (!isSubtaskLimitedUser) return true;
          return String(att?.addedBy || '').toLowerCase() === String(currentUser || '').toLowerCase();
        }}
      />
      <ReminderManager open={showReminder} onClose={() => setShowReminder(false)} itemId={task?.id} isSubtask={false} itemName={task?.name} dueDate={task?.dueDate || form.dueDate} />
    </Modal>
  );
}

function ProjectModal({ open, onClose, project, employees, teams, projectTemplates, onSaveTemplate, projectTags, onAddTag, onSave, onDelete, currentUser, isAdmin }) {
  const [form, setForm] = useState({});
  const [assignmentType, setAssignmentType] = useState('user');
  const [saveAsTemplate, setSaveAsTemplate] = useState(false);
  const [newTag, setNewTag] = useState('');
  const [showNewTag, setShowNewTag] = useState(false);
  const [pendingFiles, setPendingFiles] = useState([]);
  const [manualPath, setManualPath] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [selectedUserToAdd, setSelectedUserToAdd] = useState('');
  const [selectedTeamToAdd, setSelectedTeamToAdd] = useState('');
  const canAssignSystemAdmin = String(currentUser || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase();
  const assignableEmployees = useMemo(
    () => employees.filter(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME || includesMultiValue(form.owner, e.name)),
    [employees, canAssignSystemAdmin, form.owner]
  );
  useEffect(() => {
    if (!open) return;
    const defaultOwner = employees.find(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME)?.name || employees[0]?.name || '';
    const next = project || { name: '', tag: '', description: '', team: '', owner: defaultOwner, status: 'Planned', priority: 'Medium', progress: 0, createdBy: currentUser, createdOn: fmtFull(now), customFields: [] };
    setForm(next);
    const hasTeam = !!String(next.team || '').trim();
    const hasOwner = !!String(next.owner || '').trim();
    setAssignmentType(hasTeam && !hasOwner ? 'team' : 'user');
    setSaveAsTemplate(false);
    setNewTag('');
    setShowNewTag(false);
    setPendingFiles([]);
    setManualPath('');
    setErrorMsg('');
    setIsSaving(false);
    setSelectedUserToAdd('');
    setSelectedTeamToAdd('');
  }, [open, project, employees, currentUser, canAssignSystemAdmin]);

  const updateForm = (patch) => {
    setErrorMsg('');
    setForm(p => ({ ...p, ...patch }));
  };

  const addCustomField = () => setForm(p => ({ ...p, customFields: [...(p.customFields || []), { label: '', type: 'Text', value: '' }] }));
  const updateCustomField = (idx, patch) => setForm(p => ({ ...p, customFields: (p.customFields || []).map((f, i) => i === idx ? { ...f, ...patch } : f) }));
  const removeCustomField = (idx) => setForm(p => ({ ...p, customFields: (p.customFields || []).filter((_, i) => i !== idx) }));
  const pickFiles = async () => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setPendingFiles(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualPath = () => {
    const paths = parseFilePathsFromText(manualPath);
    if (!paths.length) return;
    setPendingFiles(prev => mergeUniqueFilePaths(prev, paths));
    setManualPath('');
  };
  const fileLabel = (p) => {
    const parts = p.split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const addTag = () => {
    const tag = newTag.trim();
    if (!tag) return;
    onAddTag?.(tag);
    updateForm({ tag });
    setNewTag('');
    setShowNewTag(false);
  };
  const addProjectUser = () => {
    const name = String(selectedUserToAdd || '').trim();
    if (!name) return;
    updateForm({ owner: joinMultiValue([...splitMultiValue(form.owner), name]) });
    setSelectedUserToAdd('');
  };
  const removeProjectUser = (name) => {
    updateForm({ owner: joinMultiValue(splitMultiValue(form.owner).filter(v => v.toLowerCase() !== String(name || '').trim().toLowerCase())) });
  };
  const addProjectTeam = () => {
    const team = String(selectedTeamToAdd || '').trim();
    if (!team) return;
    updateForm({ team: joinMultiValue([...splitMultiValue(form.team), team]) });
    setSelectedTeamToAdd('');
  };
  const removeProjectTeam = (team) => {
    updateForm({ team: joinMultiValue(splitMultiValue(form.team).filter(v => v.toLowerCase() !== String(team || '').trim().toLowerCase())) });
  };

  const handleSave = async () => {
    const name = String(form.name || '').trim();
    if (!name) {
      setErrorMsg('Please enter a project name.');
      return;
    }
    const owner = assignmentType === 'user' ? joinMultiValue(splitMultiValue(form.owner)) : '';
    const team = assignmentType === 'team' ? joinMultiValue(splitMultiValue(form.team)) : '';
    if (!owner && !team) {
      setErrorMsg(assignmentType === 'team' ? 'Please select a team.' : 'Please select a user.');
      return;
    }
    const typedTag = String(newTag || '').trim();
    const tag = String(form.tag || '').trim() || typedTag;
    if (typedTag && !(projectTags || []).includes(typedTag)) onAddTag?.(typedTag);
    const payload = { ...form, name, tag, owner, team };
    setIsSaving(true);
    setErrorMsg('');
    if (saveAsTemplate && onSaveTemplate) {
      onSaveTemplate({
        templateName: name,
        name,
        tag,
        description: form.description || '',
        owner,
        team,
        status: form.status || 'Planned',
        priority: form.priority || 'Medium',
        progress: form.progress || 0,
        customFields: form.customFields || [],
      });
    }
    const savedId = await onSave(payload);
    if (!savedId) {
      setErrorMsg(project ? 'Unable to update project.' : 'Unable to create project.');
      setIsSaving(false);
      return;
    }
    if (isElectron && savedId && pendingFiles.length) {
      const attachRes = await window.electronAPI.attachments.add({ itemId: savedId, isSubtask: false, filePaths: pendingFiles, actor: currentUser, isAdmin });
      if (!attachRes?.ok) setErrorMsg(attachRes?.error || 'Project saved, but attachments could not be added.');
    }
    setIsSaving(false);
  };

  return (
    <Modal open={open} onClose={onClose} title={project ? `Edit Project - ${project.id}` : 'Create Project'} width={760}>
      {!project && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12, gap: 10 }}>
          <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#334155', fontWeight: 500 }}>
            <input type="checkbox" checked={saveAsTemplate} onChange={e => setSaveAsTemplate(e.target.checked)} style={{ accentColor: '#0d9488' }} />
            Save as Project Template
          </label>
          <select
            value=""
            onChange={e => {
              const tpl = projectTemplates.find(t => t.templateName === e.target.value);
              if (!tpl) return;
              setForm(p => ({
                ...p,
                name: tpl.name || p.name,
                tag: tpl.tag || p.tag,
                description: tpl.description || '',
                owner: tpl.owner || p.owner,
                team: tpl.team || p.team || '',
                status: tpl.status || p.status,
                priority: tpl.priority || p.priority,
                progress: typeof tpl.progress === 'number' ? tpl.progress : p.progress,
                customFields: Array.isArray(tpl.customFields) ? tpl.customFields : [],
              }));
            }}
            style={{ ...inputStyle, width: 180, padding: '7px 10px', fontSize: 12 }}
          >
            <option value="">Templates</option>
            {projectTemplates.map(t => <option key={t.templateName} value={t.templateName}>{t.templateName}</option>)}
          </select>
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Project Name" required><input value={form.name || ''} onChange={e => updateForm({ name: e.target.value })} style={inputStyle} placeholder="Project Name" /></FormField>
        <FormField label="Project Tag">
          <div style={{ display: 'flex', gap: 8 }}>
            <select value={form.tag || ''} onChange={e => updateForm({ tag: e.target.value })} style={{ ...inputStyle, flex: 1 }}>
              <option value="">No Tag</option>
              {(projectTags || []).map(t => <option key={t}>{t}</option>)}
            </select>
            <button onClick={() => setShowNewTag(v => !v)} style={{ ...btnSecondary, padding: '0 10px' }}>+</button>
          </div>
          {showNewTag && (
            <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
              <input value={newTag} onChange={e => setNewTag(e.target.value)} style={{ ...inputStyle, flex: 1 }} placeholder="Add new tag" />
              <button onClick={addTag} style={btnPrimary}>Add</button>
            </div>
          )}
        </FormField>
      </div>
      <FormField label="Description (optional)"><textarea value={form.description || ''} onChange={e => updateForm({ description: e.target.value })} style={{ ...inputStyle, minHeight: 54, resize: 'vertical' }} /></FormField>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Assign To">
          <select
            value={assignmentType}
            onChange={e => {
              const nextType = e.target.value;
              setErrorMsg('');
              setAssignmentType(nextType);
              setForm(p => ({
                ...p,
                owner: nextType === 'user' ? p.owner : '',
                team: nextType === 'team' ? p.team : '',
              }));
            }}
            style={inputStyle}
          >
            <option value="user">User</option>
            <option value="team">Team</option>
          </select>
        </FormField>
        {assignmentType === 'team' ? (
          <FormField label="Teams" required>
            <div style={{ display: 'flex', gap: 8 }}>
              <select value={selectedTeamToAdd} onChange={e => setSelectedTeamToAdd(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
                <option value="">Select Team</option>
                {(teams || []).filter(team => !includesMultiValue(form.team, team)).map(team => <option key={team} value={team}>{team}</option>)}
              </select>
              <button type="button" onClick={addProjectTeam} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}><Plus size={13} /> Add Team</button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
              {splitMultiValue(form.team).length === 0 ? <span style={{ fontSize: 12, color: '#94a3b8' }}>No teams added</span> : splitMultiValue(form.team).map(team => (
                <span key={team} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, background: '#f0fdfa', color: '#0f766e', border: '1px solid #99f6e4', borderRadius: 999, padding: '4px 8px' }}>
                  {team}
                  <button type="button" onClick={() => removeProjectTeam(team)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#0f766e', padding: 0, lineHeight: 1 }}>x</button>
                </span>
              ))}
            </div>
          </FormField>
        ) : (
          <FormField label="Users" required>
            <div style={{ display: 'flex', gap: 8 }}>
              <select value={selectedUserToAdd} onChange={e => setSelectedUserToAdd(e.target.value)} style={{ ...inputStyle, flex: 1 }}>
                <option value="">Select User</option>
                {assignableEmployees.filter(e => !includesMultiValue(form.owner, e.name)).map(e => <option key={e.name} value={e.name}>{e.name}</option>)}
              </select>
              <button type="button" onClick={addProjectUser} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}><Plus size={13} /> Add User</button>
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginTop: 8 }}>
              {splitMultiValue(form.owner).length === 0 ? <span style={{ fontSize: 12, color: '#94a3b8' }}>No users added</span> : splitMultiValue(form.owner).map(name => (
                <span key={name} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 12, background: '#eef2ff', color: '#3730a3', border: '1px solid #c7d2fe', borderRadius: 999, padding: '4px 8px' }}>
                  {name}
                  <button type="button" onClick={() => removeProjectUser(name)} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#3730a3', padding: 0, lineHeight: 1 }}>x</button>
                </span>
              ))}
            </div>
          </FormField>
        )}
        <FormField label="Status"><select value={form.status || 'Planned'} onChange={e => updateForm({ status: e.target.value })} style={inputStyle}>{PROJECT_STATUS.map(s => <option key={s}>{s}</option>)}</select></FormField>
        <FormField label="Priority"><select value={form.priority || 'Medium'} onChange={e => updateForm({ priority: e.target.value })} style={inputStyle}>{PRIORITY_OPTIONS.map(p => <option key={p}>{p}</option>)}</select></FormField>
        <FormField label="Progress (%)"><input type="number" value={form.progress || 0} onChange={e => updateForm({ progress: parseInt(e.target.value) || 0 })} style={inputStyle} min="0" max="100" /></FormField>
      </div>

      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 6 }}>Attach Files</div>
        <div style={{ border: '2px dashed #d1d5db', borderRadius: 10, padding: '12px 14px 8px', textAlign: 'center', background: '#f8fafc' }}>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 10 }}>
            <input
              value={manualPath}
              onChange={e => setManualPath(e.target.value)}
              onPaste={async (e) => {
                const pastedPaths = await getPastedAttachmentPaths(e);


                if (!pastedPaths.length) return;
                e.preventDefault();
                setPendingFiles(prev => mergeUniqueFilePaths(prev, pastedPaths));
              }}
              placeholder="Paste file path(s) here or press Ctrl+V after copying files"
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={addManualPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
          </div>
          <div style={{ fontSize: 13, color: '#64748b', marginBottom: 8 }}>Drag & Drop Files or <button onClick={pickFiles} style={{ background: 'none', border: 'none', color: '#0d9488', cursor: 'pointer', fontWeight: 600 }}>Browse</button></div>
          {pendingFiles.length > 0 && (
            <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap', justifyContent: 'center' }}>
              {pendingFiles.map((p, i) => (
                <span key={`${p}-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#e2e8f0', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
                  {fileLabel(p)}
                  <button
                    type="button"
                    onClick={() => setPendingFiles(prev => prev.filter((_, idx) => idx !== i))}
                    style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}
                  >
                    x
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      <div style={{ marginBottom: 8 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569' }}>Custom Fields ({(form.customFields || []).length}/5)</div>
          <button onClick={addCustomField} disabled={(form.customFields || []).length >= 5} style={{ ...btnSecondary, color: '#16a34a', borderColor: '#86efac' }}><Plus size={13} />Add Fields</button>
        </div>
        {(form.customFields || []).map((f, idx) => (
          <div key={idx} style={{ display: 'grid', gridTemplateColumns: '1fr 140px 1fr 36px', gap: 8, marginBottom: 8 }}>
            <input value={f.label || ''} onChange={e => updateCustomField(idx, { label: e.target.value })} style={inputStyle} placeholder="Field Label" />
            <select value={f.type || 'Text'} onChange={e => updateCustomField(idx, { type: e.target.value })} style={inputStyle}><option>Text</option><option>Number</option><option>Date</option><option>Dropdown</option></select>
            <input value={f.value || ''} onChange={e => updateCustomField(idx, { value: e.target.value })} style={inputStyle} placeholder="Enter value" />
            <button onClick={() => removeCustomField(idx)} style={{ ...btnSecondary, padding: 0, justifyContent: 'center' }}><X size={14} /></button>
          </div>
        ))}
      </div>

      {errorMsg && (
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 8, fontSize: 12, color: '#991b1b', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, padding: '9px 11px', marginTop: 12 }}>
          <AlertCircle size={14} style={{ flexShrink: 0, marginTop: 1 }} />
          <span>{errorMsg}</span>
        </div>
      )}

      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 18 }}>
        {onDelete && <button onClick={onDelete} style={{ ...btnDanger, marginRight: 'auto' }}><Trash2 size={14} /> Delete</button>}
        <button onClick={onClose} style={btnSecondary}>Cancel</button>
        <button onClick={handleSave} disabled={isSaving} style={{ ...btnPrimary, opacity: isSaving ? 0.7 : 1 }}>{isSaving ? 'Saving...' : (project ? 'Update' : 'Create Project')}</button>
      </div>
    </Modal>
  );
}

function IssueModal({ open, onClose, issue, employees, tasks, onSave, currentUser, isAdmin }) {
  const [form, setForm] = useState({});
  const [showAttachments, setShowAttachments] = useState(false);
  const [pendingAttachments, setPendingAttachments] = useState([]);
  const [pendingVoiceNotes, setPendingVoiceNotes] = useState([]);
  const [manualAttachmentPath, setManualAttachmentPath] = useState('');
  const [draftIssueMessage, setDraftIssueMessage] = useState('');
  const [draftIssueFiles, setDraftIssueFiles] = useState([]);
  const isEditIssue = !!issue?.id;
  const canAssignSystemAdmin = String(currentUser || '').trim().toLowerCase() === SYSTEM_ADMIN_NAME.toLowerCase();
  const assignableEmployees = useMemo(
    () => employees.filter(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME || e.name === form.assignedTo),
    [employees, canAssignSystemAdmin, form.assignedTo]
  );
  useEffect(() => {
    if (!open) return;
    const defaultAssignee = employees.find(e => canAssignSystemAdmin || e.name !== SYSTEM_ADMIN_NAME)?.name || employees[0]?.name || '';
    setForm({
      title: '',
      description: '',
      taskId: '',
      reportedBy: currentUser || employees[0]?.name || '',
      assignedTo: defaultAssignee,
      priority: 'Medium',
      status: 'Open',
      remarks: '',
      ...(issue || {}),
    });
    setShowAttachments(false);
    setPendingAttachments([]);
    setPendingVoiceNotes([]);
    setManualAttachmentPath('');
    setDraftIssueMessage('');
    setDraftIssueFiles([]);
  }, [open, issue, employees, currentUser, canAssignSystemAdmin]);
  const pickFiles = async (setter) => {
    if (!isElectron) return;
    const filePaths = await window.electronAPI.openFile();
    if (filePaths?.length) setter(prev => mergeUniqueFilePaths(prev, filePaths));
  };
  const addManualAttachmentPath = () => {
    const paths = parseFilePathsFromText(manualAttachmentPath);
    if (!paths.length) return;
    setPendingAttachments(prev => mergeUniqueFilePaths(prev, paths));
    setManualAttachmentPath('');
  };
  const fileLabel = (p) => {
    const parts = p.split(/[/\\]/);
    return parts[parts.length - 1] || p;
  };
  const handleSave = async () => {
    if (!form.title?.trim()) return;
    const savedId = await onSave(form);
    const itemId = issue?.id || savedId;
    if (isElectron && itemId && (draftIssueMessage.trim() || draftIssueFiles.length) && window.electronAPI?.issueComments?.add) {
      await window.electronAPI.issueComments.add({
        issueId: itemId,
        actor: currentUser,
        message: draftIssueMessage.trim(),
        filePaths: draftIssueFiles,
        isAdmin,
      });
      setDraftIssueMessage('');
      setDraftIssueFiles([]);
    }
    const allFiles = [...pendingAttachments, ...pendingVoiceNotes];
    if (isElectron && itemId && allFiles.length) {
      await window.electronAPI.attachments.add({ itemId, isSubtask: false, filePaths: allFiles, actor: currentUser, isAdmin });
    }
  };
  return (
    <Modal open={open} onClose={onClose} title={isEditIssue ? `Edit Issue — ${issue.id}` : 'Report Issue'} width={560}>
      <FormField label="Title" required><input value={form.title || ''} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} style={inputStyle} /></FormField>
      <FormField label="Description"><textarea value={form.description || ''} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} style={{ ...inputStyle, minHeight: 60, resize: 'vertical' }} /></FormField>
      <div style={{ ...shadcnPanel, padding: 12, marginBottom: 14 }}>
        <div style={{ ...shadcnLabel, marginBottom: 8 }}>Messages</div>
        <IssueCommentsModal
          embedded
          open={open}
          issue={isEditIssue ? issue : null}
          currentUser={currentUser}
          isAdmin={isAdmin}
          draftMessage={!isEditIssue ? draftIssueMessage : undefined}
          onDraftMessageChange={!isEditIssue ? setDraftIssueMessage : undefined}
          draftFiles={!isEditIssue ? draftIssueFiles : undefined}
          onDraftFilesChange={!isEditIssue ? setDraftIssueFiles : undefined}
        />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
        <FormField label="Priority"><select value={form.priority || 'Medium'} onChange={e => setForm(p => ({ ...p, priority: e.target.value }))} style={inputStyle}>{PRIORITY_OPTIONS.map(p => <option key={p}>{p}</option>)}</select></FormField>
        <FormField label="Status"><select value={form.status || 'Open'} onChange={e => setForm(p => ({ ...p, status: e.target.value }))} style={inputStyle}>{ISSUE_STATUS.map(s => <option key={s}>{s}</option>)}</select></FormField>
        <FormField label="Assigned To"><select value={form.assignedTo || ''} onChange={e => setForm(p => ({ ...p, assignedTo: e.target.value }))} style={inputStyle}>{assignableEmployees.map(e => <option key={e.name} value={e.name}>{e.name}</option>)}</select></FormField>
        <FormField label="Related Task"><select value={form.taskId || ''} onChange={e => setForm(p => ({ ...p, taskId: e.target.value }))} style={inputStyle}><option value="">None</option>{tasks.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></FormField>
      </div>
      {!isEditIssue && (
        <div style={{ border: '1px dashed #e2e8f0', borderRadius: 10, padding: 12, marginTop: 10 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: '#475569', marginBottom: 8 }}>Attachments</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
            <input
              value={manualAttachmentPath}
              onChange={e => setManualAttachmentPath(e.target.value)}
              onPaste={async (e) => {
                const pastedPaths = await getPastedAttachmentPaths(e);
                if (!pastedPaths.length) return;
                e.preventDefault();
                setPendingAttachments(prev => mergeUniqueFilePaths(prev, pastedPaths));
              }}
              placeholder="Paste file path(s) here or press Ctrl+V after copying files"
              style={{ ...inputStyle, flex: 1 }}
            />
            <button onClick={addManualAttachmentPath} style={{ ...btnSecondary, padding: '8px 12px', whiteSpace: 'nowrap' }}>Add Path</button>
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            <button onClick={() => pickFiles(setPendingAttachments)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} /> Add Files</button>
            <button onClick={() => pickFiles(setPendingVoiceNotes)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Mic size={13} /> Add Voice Note</button>
          </div>
          {(pendingAttachments.length > 0 || pendingVoiceNotes.length > 0) && (
            <div style={{ marginTop: 10, display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {pendingAttachments.map((p, i) => (
                <span key={`issue-att-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#eef2ff', color: '#334155', padding: '3px 8px', borderRadius: 999 }}>
                  Attachment: {fileLabel(p)}
                  <button type="button" onClick={() => setPendingAttachments(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#64748b', padding: 0, lineHeight: 1 }}>x</button>
                </span>
              ))}
              {pendingVoiceNotes.map((p, i) => (
                <span key={`issue-voice-${i}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 11, background: '#ecfeff', color: '#155e75', padding: '3px 8px', borderRadius: 999 }}>
                  Voice note: {fileLabel(p)}
                  <button type="button" onClick={() => setPendingVoiceNotes(prev => prev.filter((_, idx) => idx !== i))} style={{ border: 'none', background: 'none', cursor: 'pointer', color: '#0e7490', padding: 0, lineHeight: 1 }}>x</button>
                </span>
              ))}
            </div>
          )}
        </div>
      )}
      {isEditIssue && (
        <div style={{ display: 'flex', gap: 8, marginTop: 12, marginBottom: 4 }}>
          <button onClick={() => setShowAttachments(true)} style={{ ...btnSecondary, fontSize: 12, padding: '6px 12px' }}><Paperclip size={13} /> Attachments</button>
        </div>
      )}
      <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end', marginTop: 20 }}>
        <button onClick={onClose} style={btnSecondary}>Cancel</button>
        <button onClick={handleSave} style={btnPrimary}>{isEditIssue ? 'Update' : 'Submit'} Issue</button>
      </div>
      <AttachmentManager open={showAttachments} onClose={() => setShowAttachments(false)} itemId={issue?.id} isSubtask={false} itemName={issue?.title} actor={currentUser} isAdmin={isAdmin} />
    </Modal>
  );
}
