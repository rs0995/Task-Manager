const { spawn } = require('child_process');
const http = require('http');
const path = require('path');

function waitForUrl(url, timeout = 60000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const check = () => {
      http.get(url, () => {
        resolve();
      }).on('error', () => {
        if (Date.now() - start > timeout) {
          reject(new Error(`Timed out waiting for ${url}`));
        } else {
          setTimeout(check, 500);
        }
      });
    };
    check();
  });
}

const prefix = (name, color) => (line) =>
  process.stdout.write(`\x1b[${color}m[${name}]\x1b[0m ${line}\n`);

// Start Vite
const vite = spawn(process.execPath, ['./node_modules/vite/bin/vite.js'], {
  stdio: 'inherit',
  shell: false,
  cwd: path.join(__dirname, '..'),
});

vite.on('error', (err) => {
  console.error('Failed to start Vite:', err.message);
  process.exit(1);
});

// Wait for Vite to be ready, then start Electron
waitForUrl('http://localhost:5173').then(() => {
  const electronPath = require(path.join(__dirname, '../node_modules/electron'));
  const electron = spawn(electronPath, ['.'], {
    stdio: 'inherit',
    shell: false,
    cwd: path.join(__dirname, '..'),
  });

  electron.on('error', (err) => {
    console.error('Failed to start Electron:', err.message);
    vite.kill();
    process.exit(1);
  });

  electron.on('close', (code) => {
    vite.kill();
    process.exit(code || 0);
  });
}).catch((err) => {
  console.error(err.message);
  vite.kill();
  process.exit(1);
});

vite.on('close', (code) => {
  if (code !== 0 && code !== null) {
    process.exit(code);
  }
});

process.on('SIGINT', () => {
  vite.kill();
  process.exit(0);
});
