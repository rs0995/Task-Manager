﻿const fs = require('fs');
const path = require('path');
const { app, BrowserWindow } = require('electron');

app.whenReady().then(async () => {
  try {
    const src = path.join(process.cwd(), 'build', 'icon.svg').replace(/\\/g, '/');
    const outDir = path.join(process.cwd(), 'build');
    const out = path.join(outDir, 'icon.png');
    if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

    const win = new BrowserWindow({
      width: 512,
      height: 512,
      show: false,
      frame: false,
      transparent: true,
      webPreferences: { offscreen: false }
    });

    const html = `<!doctype html><html><body style="margin:0;display:flex;align-items:center;justify-content:center;width:512px;height:512px;background:transparent;overflow:hidden;"><img src="file:///${src}" style="width:512px;height:512px;object-fit:contain;"/></body></html>`;
    await win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
    await new Promise(r => setTimeout(r, 200));
    const image = await win.webContents.capturePage({ x: 0, y: 0, width: 512, height: 512 });
    fs.writeFileSync(out, image.toPNG());
    console.log('WROTE', out);
    win.destroy();
    app.quit();
  } catch (e) {
    console.error('ICON_GEN_FAILED', e && e.message ? e.message : e);
    app.exit(2);
  }
});
