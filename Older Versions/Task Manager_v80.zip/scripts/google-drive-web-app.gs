const FOLDER_ID = '1G_k0_OVBrLYbO-QvywhTJ-5I1TiIw5vz';
const TOKEN = 'asdf1234';
const DATA_FOLDER_NAME = 'server-data';
const DB_FILE = 'erp_tasks.db';
const DB_BASE64_FILE = DB_FILE + '.base64';
const CONNECTION_TEST_FILE = 'erp-drive-connection-test.json';
const CLIENTS_DIR = 'direct-sync-clients';
const PROCESSED_DIR = 'processed-queues';

function doGet(e) {
  try {
    checkToken(e.parameter.token);
    const action = e.parameter.action || 'health';

    if (action === 'health') {
      const dataFolder = getDataFolder();
      const base64File = findFile(dataFolder, DB_BASE64_FILE);
      const dbFile = findFile(dataFolder, DB_FILE);
      const file = base64File || dbFile;
      return json({
        ok: true,
        serverTime: new Date().toISOString(),
        folderId: dataFolder.getId(),
        folderName: dataFolder.getName(),
        dbFound: !!file,
        dbFileName: file ? file.getName() : '',
        snapshotMode: base64File ? 'base64-text' : (dbFile ? 'binary-db' : ''),
        dbUpdatedAt: file ? file.getLastUpdated().toISOString() : '',
      });
    }

    if (action === 'diagnose') {
      const root = getRootFolder();
      const dataFolder = getDataFolder();
      return json({
        ok: true,
        rootFolderId: root.getId(),
        rootFolderName: root.getName(),
        dataFolderId: dataFolder.getId(),
        dataFolderName: dataFolder.getName(),
        files: listFolderFiles(dataFolder),
      });
    }

    if (action === 'connectionTest') {
      const challenge = String(e.parameter.challenge || '').trim();
      const appCode = String(e.parameter.appCode || '').trim();
      if (!challenge || !appCode) return json({ ok: false, error: 'Missing connection test challenge' });
      const dataFolder = getDataFolder();
      const data = {
        appCode: appCode,
        challenge: challenge,
        checkedAt: new Date().toISOString(),
      };
      let file;
      try {
        file = upsertTextFile(dataFolder, CONNECTION_TEST_FILE, JSON.stringify(data));
      } catch (err) {
        return json({ ok: false, error: 'Drive connection test write failed: ' + String(err.message || err) });
      }
      let readBack;
      try {
        readBack = JSON.parse(file.getBlob().getDataAsString() || '{}');
      } catch (err) {
        return json({ ok: false, error: 'Drive connection test read failed: ' + String(err.message || err) });
      }
      const base64File = findFile(dataFolder, DB_BASE64_FILE);
      const dbFile = findFile(dataFolder, DB_FILE);
      const snapshotFile = base64File || dbFile;
      return json({
        ok: readBack.appCode === appCode && readBack.challenge === challenge,
        appCode: readBack.appCode || '',
        challenge: readBack.challenge || '',
        serverTime: new Date().toISOString(),
        folderId: dataFolder.getId(),
        folderName: dataFolder.getName(),
        dbFound: !!snapshotFile,
        dbFileName: snapshotFile ? snapshotFile.getName() : '',
        snapshotMode: base64File ? 'base64-text' : (dbFile ? 'binary-db' : ''),
        dbUpdatedAt: snapshotFile ? snapshotFile.getLastUpdated().toISOString() : '',
      });
    }

    if (action === 'snapshot') {
      const dataFolder = getDataFolder();
      const base64File = findFile(dataFolder, DB_BASE64_FILE);
      const file = base64File || findFile(dataFolder, DB_FILE);
      if (!file) return json({ ok: false, error: 'DB snapshot file not found in ' + dataFolder.getName() });
      const base64 = base64File
        ? base64File.getBlob().getDataAsString().trim()
        : Utilities.base64Encode(file.getBlob().getBytes());
      return json({
        ok: true,
        fileName: DB_FILE,
        sourceFileName: file.getName(),
        folderId: dataFolder.getId(),
        folderName: dataFolder.getName(),
        updatedAt: file.getLastUpdated().toISOString(),
        snapshotMode: base64File ? 'base64-text' : 'binary-db',
        base64: base64,
      });
    }

    if (action === 'listQueues') {
      return json({ ok: true, files: listQueueFiles() });
    }

    if (action === 'queue') {
      const file = DriveApp.getFileById(String(e.parameter.fileId || ''));
      return json({
        ok: true,
        fileId: file.getId(),
        fileName: file.getName(),
        text: file.getBlob().getDataAsString(),
      });
    }

    if (action === 'queueStatus') {
      const clientId = cleanName(e.parameter.clientId || '');
      const files = listQueueFiles().filter(function (file) {
        return !clientId || String(file.clientId || '') === clientId;
      });
      return json({ ok: true, pendingCount: files.length });
    }

    return json({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return json({ ok: false, error: String(err.message || err) });
  }
}

function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    checkToken(body.token);

    if (body.action === 'uploadSnapshot') {
      const base64 = String(body.base64 || '').trim();
      if (!base64) return json({ ok: false, error: 'Missing DB snapshot content' });
      let file;
      try {
        file = upsertTextFile(getDataFolder(), DB_BASE64_FILE, base64);
      } catch (err) {
        return json({
          ok: false,
          error: 'DB snapshot write failed for ' + DB_BASE64_FILE + ': ' + String(err.message || err),
        });
      }
      return json({
        ok: true,
        updatedAt: file.getLastUpdated().toISOString(),
        fileId: file.getId(),
        fileName: file.getName(),
        snapshotMode: 'base64-text',
      });
    }

    if (body.action === 'queue') {
      const clientId = cleanName(body.clientId || body.actor || 'remote-client');
      const clientsFolder = getOrCreateFolder(getDataFolder(), CLIENTS_DIR);
      const clientFolder = getOrCreateFolder(clientsFolder, 'remote-' + clientId);
      const name = 'queue-' + Date.now() + '.jsonl';
      const lines = (body.items || []).map(function (item) {
        return JSON.stringify(item);
      }).join('\n') + '\n';
      const file = clientFolder.createFile(name, lines, MimeType.PLAIN_TEXT);
      return json({ ok: true, fileId: file.getId(), fileName: name, pendingCount: listQueueFiles().length });
    }

    if (body.action === 'markQueueProcessed') {
      moveToProcessed(String(body.fileId || ''));
      return json({ ok: true });
    }

    if (body.action === 'replaceQueue') {
      const file = DriveApp.getFileById(String(body.fileId || ''));
      if ((body.items || []).length) {
        const lines = body.items.map(function (item) {
          return JSON.stringify(item);
        }).join('\n') + '\n';
        file.setContent(lines);
      } else {
        moveToProcessed(file.getId());
      }
      return json({ ok: true });
    }

    return json({ ok: false, error: 'Unknown action' });
  } catch (err) {
    return json({ ok: false, error: String(err.message || err) });
  }
}

function listQueueFiles() {
  const clientsFolder = findFolder(getDataFolder(), CLIENTS_DIR);
  if (!clientsFolder) return [];
  const results = [];
  const clientFolders = clientsFolder.getFolders();
  while (clientFolders.hasNext()) {
    const clientFolder = clientFolders.next();
    const files = clientFolder.getFiles();
    while (files.hasNext()) {
      const file = files.next();
      if (/^queue-.*\.jsonl$/i.test(file.getName())) {
        results.push({
          fileId: file.getId(),
          fileName: file.getName(),
          clientId: clientFolder.getName().replace(/^remote-/, ''),
          updatedAt: file.getLastUpdated().toISOString(),
        });
      }
    }
  }
  return results;
}

function moveToProcessed(fileId) {
  if (!fileId) return;
  const file = DriveApp.getFileById(fileId);
  const processedFolder = getOrCreateFolder(getDataFolder(), PROCESSED_DIR);
  file.moveTo(processedFolder);
}

function upsertTextFile(folder, name, content) {
  const existing = findFile(folder, name);
  if (existing) {
    try {
      existing.setContent(content);
      return existing;
    } catch (err) {
    }
  }
  return folder.createFile(name, content, MimeType.PLAIN_TEXT);
}

function checkToken(token) {
  if (String(token || '') !== TOKEN) throw new Error('Unauthorized');
}

function getRootFolder() {
  return DriveApp.getFolderById(FOLDER_ID);
}

function getDataFolder() {
  const root = getRootFolder();
  if (root.getName() === DATA_FOLDER_NAME || findFile(root, DB_BASE64_FILE) || findFile(root, DB_FILE)) return root;
  const nested = findFolder(root, DATA_FOLDER_NAME);
  return nested || root;
}

function listFolderFiles(folder) {
  const results = [];
  const files = folder.getFiles();
  while (files.hasNext()) {
    const file = files.next();
    results.push({
      name: file.getName(),
      id: file.getId(),
      size: file.getSize(),
      updatedAt: file.getLastUpdated().toISOString(),
    });
  }
  return results;
}

function findFile(folder, name) {
  const files = folder.getFilesByName(name);
  let latest = null;
  while (files.hasNext()) {
    const file = files.next();
    if (!latest || file.getLastUpdated().getTime() > latest.getLastUpdated().getTime()) {
      latest = file;
    }
  }
  return latest;
}

function findFolder(parent, name) {
  const folders = parent.getFoldersByName(name);
  return folders.hasNext() ? folders.next() : null;
}

function getOrCreateFolder(parent, name) {
  return findFolder(parent, name) || parent.createFolder(name);
}

function cleanName(value) {
  return String(value || '').replace(/[\\/:*?"<>|]/g, '_').slice(0, 120);
}

function json(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
