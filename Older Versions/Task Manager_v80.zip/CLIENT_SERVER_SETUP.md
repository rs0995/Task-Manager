# Client Server Setup

Use one machine as the ERP server. That server owns the main SQLite database. Every user installs the desktop client on their own machine. The client keeps a temporary local cache for fast reads and sends changes to the server.

## Installer Options

Windows releases are packaged as two separate setup files:

- **Task Manager Server Setup** for the one machine that will hold the central database and sync service.
- **Task Manager Client Setup** for every user machine that will connect over LAN.

The installer then handles startup like this:

- **Server setup** is configured to start automatically when Windows starts.
- **Client setup** shows a final checkbox after installation for starting the client app when Windows starts.

The server startup option launches:

```text
Task Manager Server.exe
```

The client startup option launches:

```text
Task Manager.exe
```

## Server Machine

1. Run **Task Manager Server Setup** on the server machine.
2. The installer configures the server to run on Windows startup by default.
3. Start the server manager from the installed app folder, or let Windows start it automatically:

```powershell
.\Task Manager Server.exe
```

Server mode opens an **ERP Server Manager** window. Use it to:

- start or stop the server
- see whether the server is running
- copy the LAN URL and client token
- open the database/token folder
- create full server backups
- restore the server from a selected backup
- view live server logs

For development, you can still run the server from the project folder:

```powershell
npm run server
```

By default, the server listens on:

```text
http://SERVER-IP:3587
```

The server database is stored in:

```text
<installed server folder>\erp_tasks.db
```

The client token is created here:

```text
<installed server folder>\server-token.txt
```

You can change the server database folder from the server manager window with **Change Database Folder**. Exit from the tray and reopen the server after changing it.

### Server Backups

In the **ERP Server Manager** window:

- Click **Create Backup** to copy the full current server data folder.
- Click **Restore from Backup**, choose a backup from the list, and confirm restore.

Backups are stored inside the current database folder:

```text
<database folder>\server-backups\<backup-date>
```

Each backup folder contains the database, logs, attachments, and related server data. The backup log is kept here:

```text
<database folder>\server-backups\backup-log.json
```

When restoring, the server stops, the current data folder contents are replaced by the selected backup, and the server starts again.

For development runs with `npm run server`, the server still uses:

```text
server-data\erp_tasks.db
server-data\server-token.txt
```

Give each client the server URL and token.

## Client Machines

1. Run **Task Manager Client Setup** on each user machine.
2. The client is configured to start automatically when Windows starts. You can change this later in **Settings > Startup & Background**.
3. Configure the client to use the LAN server before launching:

```powershell
$env:ERP_SERVER_URL="http://SERVER-IP:3587"
$env:ERP_SERVER_TOKEN="<token from server-token.txt>"
.\Task Manager.exe
```

When these values are present, the app runs in LAN client mode:

- it opens a local cache database
- it pulls the server database snapshot into that cache at startup
- it keeps pulling server snapshots every 5 seconds
- it pushes app operations back to the server through the local-cache sync layer

On first run, each client asks for its own **local data folder**. The client stores its local DB copy, offline cache, pending sync queue, logs, attachments, and voice notes in that folder. You can change it later in **Settings > Storage**.

You can also override only the LAN cache location:

```powershell
$env:ERP_CLIENT_CACHE_DIR="C:\ERP Client Cache"
```

## Crash Logs

If the installed server or client closes immediately, check the crash logs:

```text
<installed client folder>\crash-logs
<installed server folder>\crash-logs
```

## Sync Rule

The server is the source of truth. If two users send contradictory updates, the server compares timestamps and keeps the newer server-side version. The later client receives a warning in the sync response so the app can notify that user.

## Scripts

```powershell
npm run server
npm run dev
npm run build:electron:client
npm run build:electron:server
npm run build:electron:remote
npm run release:remote
npm run build
```

`npm run build` builds the regular client and server installers. Use `npm run build:electron:remote` or `npm run release:remote` for the separate Remote Access client installer.
