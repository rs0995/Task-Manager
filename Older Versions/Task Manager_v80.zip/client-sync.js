const fs = require('fs');
const path = require('path');
const { initDatabase, getDatabase, ensureSystemAdmin } = require('./database');
const Database = require('better-sqlite3');
const { appsScriptGet, appsScriptPost, decodeBase64ToFile } = require('./drive-web-sync');

const CACHE_DIR = process.env.ERP_CLIENT_CACHE_DIR || path.join(process.cwd(), 'client-cache');
const DIRECT_DB_FILE = 'erp_tasks.db';
const DIRECT_CLIENTS_DIR = 'direct-sync-clients';
const DIRECT_CLIENT_QUEUE_FILE = 'queue.jsonl';
const DIRECT_CLIENT_ATTACHMENTS_DIR = 'attachments';
const DIRECT_QUEUE_CONFIG_FILE = 'direct-sync-config.json';
const DIRECT_READ_SNAPSHOT_DIR = 'direct-read-snapshot';
const DRIVE_READ_SNAPSHOT_DIR = 'drive-read-snapshot';
const SYNC_TABLES = [
  'employees',
  'teams',
  'tasks',
  'subtasks',
  'projects',
  'issues',
  'recurring_tasks',
  'inventory_items',
  'inventory_moves',
  'menu_items',
  'pos_orders',
  'pos_order_items',
  'kot_tickets',
  'task_history',
  'task_comments',
  'task_comment_attachments',
  'task_comment_reads',
  'subtask_comments',
  'subtask_comment_attachments',
  'subtask_comment_reads',
  'issue_comments',
  'issue_comment_attachments',
  'task_attachments',
  'task_reminders',
  'app_settings',
  'user_settings',
  'sync_deletions',
];
const ATTACHMENT_TABLES = new Set([
  'task_attachments',
  'task_comment_attachments',
  'subtask_comment_attachments',
  'issue_comment_attachments',
]);

function sanitizeFileName(value) {
  return String(value || 'attachment').replace(/[<>:"/\\|?*\x00-\x1F]/g, '_').slice(0, 180) || 'attachment';
}

function initLocalCache() {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
  return initDatabase(CACHE_DIR);
}

async function serverRequest(serverUrl, token, endpoint, options = {}) {
  const url = `${String(serverUrl || '').replace(/\/$/, '')}${endpoint}`;
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers || {}),
    },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok || !data?.ok) {
    throw new Error(data?.error || `Server request failed: ${response.status}`);
  }
  return data;
}

function getLocalAttachmentDir(cacheDir) {
  const dir = path.join(cacheDir || CACHE_DIR, 'DB', 'attachments', 'server-sync');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function removeSqliteFiles(dbPath) {
  for (const suffix of ['', '-wal', '-shm']) {
    try { fs.rmSync(`${dbPath}${suffix}`, { force: true }); } catch {}
  }
}

function getDirectReadSnapshotPath(cacheDir) {
  const dir = path.join(cacheDir || CACHE_DIR, DIRECT_READ_SNAPSHOT_DIR);
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, DIRECT_DB_FILE);
}

function getDriveReadSnapshotPath(cacheDir) {
  const dir = path.join(cacheDir || CACHE_DIR, DRIVE_READ_SNAPSHOT_DIR);
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, DIRECT_DB_FILE);
}

async function createDirectReadSnapshot(directDbDir, cacheDir) {
  const remoteDbPath = getDirectDbPath(directDbDir);
  if (!fs.existsSync(remoteDbPath)) throw new Error(`Remote DB not found: ${remoteDbPath}`);
  const snapshotPath = getDirectReadSnapshotPath(cacheDir);
  const tempPath = path.join(path.dirname(snapshotPath), `${path.basename(snapshotPath, '.db')}-${process.pid}-${Date.now()}.db`);
  removeSqliteFiles(tempPath);
  let remoteDb = null;
  try {
    remoteDb = new Database(remoteDbPath, { readonly: true, fileMustExist: true });
    if (typeof remoteDb.backup === 'function') {
      await remoteDb.backup(tempPath);
      remoteDb.close();
      remoteDb = null;
      removeSqliteFiles(snapshotPath);
      fs.renameSync(tempPath, snapshotPath);
      return { remoteDbPath, snapshotPath };
    }
  } finally {
    if (remoteDb) remoteDb.close();
  }

  removeSqliteFiles(snapshotPath);
  fs.copyFileSync(remoteDbPath, snapshotPath);
  for (const suffix of ['-wal', '-shm']) {
    const source = `${remoteDbPath}${suffix}`;
    if (fs.existsSync(source)) fs.copyFileSync(source, `${snapshotPath}${suffix}`);
  }
  return { remoteDbPath, snapshotPath };
}

function withAttachmentPayloads(mutations) {
  return (mutations || []).map((mutation) => {
    if (!ATTACHMENT_TABLES.has(mutation?.table) || mutation.action === 'delete') return mutation;
    const filePath = mutation?.data?.file_path;
    if (!filePath || !fs.existsSync(filePath)) return mutation;
    return {
      ...mutation,
      fileName: mutation.data.file_name || path.basename(filePath),
      fileBase64: fs.readFileSync(filePath).toString('base64'),
    };
  });
}

function copyDirectAttachmentPayload(directDbDir, mutation, clientFolder = '') {
  if (!ATTACHMENT_TABLES.has(mutation?.table) || mutation.action === 'delete') return mutation;
  const filePath = mutation?.data?.file_path;
  if (!filePath || !fs.existsSync(filePath)) return mutation;
  if (!clientFolder) return mutation;
  const fileName = sanitizeFileName(mutation.data.file_name || path.basename(filePath));
  const rowId = sanitizeFileName(mutation.data.id ?? mutation.pkValue ?? cryptoRandomId());
  const spoolDir = path.join(clientFolder, DIRECT_CLIENT_ATTACHMENTS_DIR);
  fs.mkdirSync(spoolDir, { recursive: true });
  const spoolPath = path.join(spoolDir, `${mutation.table}-${rowId}-${cryptoRandomId()}-${fileName}`);
  fs.copyFileSync(filePath, spoolPath);
  const directAttachmentRelativePath = clientFolder ? path.relative(clientFolder, spoolPath) : '';
  return {
    ...mutation,
    fileName,
    directAttachmentPath: spoolPath,
    directAttachmentRelativePath,
  };
}

function withDirectAttachmentPayloads(directDbDir, mutations, clientFolder = '') {
  return (mutations || []).map((mutation) => {
    try {
      return copyDirectAttachmentPayload(directDbDir, mutation, clientFolder);
    } catch {
      return mutation;
    }
  });
}

function localizeAttachmentRows(db, table, rows, options = {}) {
  if (!ATTACHMENT_TABLES.has(table) || !Array.isArray(rows) || !rows.length) return rows;
  if (options.preserveAttachmentPaths) return rows;
  const existingPaths = new Map();
  try {
    const existing = db.prepare(`SELECT id, file_path FROM ${table}`).all();
    for (const row of existing) {
      if (row?.id && row?.file_path && fs.existsSync(row.file_path)) {
        existingPaths.set(String(row.id), row.file_path);
      }
    }
  } catch {}
  return rows.map((row) => ({
    ...row,
    file_path: existingPaths.get(String(row?.id || '')) || '',
  }));
}

function normalizeDirectDbDir(directDbDir) {
  const raw = String(directDbDir || '').trim();
  if (!raw) throw new Error('Direct DB folder is required.');
  const withoutQuotes = raw.replace(/^["']|["']$/g, '');
  if (path.basename(withoutQuotes).toLowerCase() === DIRECT_DB_FILE) {
    return path.dirname(withoutQuotes);
  }
  const directDbPath = path.join(withoutQuotes, DIRECT_DB_FILE);
  if (fs.existsSync(directDbPath)) return withoutQuotes;
  const nestedDbDir = path.join(withoutQuotes, 'DB');
  if (fs.existsSync(path.join(nestedDbDir, DIRECT_DB_FILE))) return nestedDbDir;
  const serverDataDir = path.join(withoutQuotes, 'server-data');
  if (fs.existsSync(path.join(serverDataDir, DIRECT_DB_FILE))) return serverDataDir;
  return withoutQuotes;
}

function resolveDirectAttachmentRows(directDbDir, table, rows, cacheDir) {
  if (!ATTACHMENT_TABLES.has(table) || !Array.isArray(rows) || !rows.length) return rows;
  const sharedAttachmentDir = path.join(normalizeDirectDbDir(directDbDir), 'DB', 'attachments', 'server-sync');
  const localAttachmentDir = getLocalAttachmentDir(cacheDir);
  return rows.map((row) => {
    const currentPath = String(row?.file_path || '');
    const candidates = [];
    if (currentPath && fs.existsSync(currentPath)) candidates.push(currentPath);
    const currentBase = currentPath ? path.basename(currentPath) : '';
    if (currentBase) candidates.push(path.join(sharedAttachmentDir, currentBase));
    if (row?.id) {
      candidates.push(path.join(
        sharedAttachmentDir,
        `${table}-${sanitizeFileName(row.id)}-${sanitizeFileName(row.file_name || `attachment-${row.id}`)}`
      ));
    }
    const sharedPath = candidates.find(candidate => candidate && fs.existsSync(candidate));
    if (!sharedPath) return row;
    try {
      const fileName = sanitizeFileName(row.file_name || path.basename(sharedPath) || `attachment-${row.id || cryptoRandomId()}`);
      const rowId = sanitizeFileName(row.id || cryptoRandomId());
      const localPath = path.join(localAttachmentDir, `${table}-${rowId}-${fileName}`);
      if (path.resolve(sharedPath) !== path.resolve(localPath)) {
        const sourceStat = fs.statSync(sharedPath);
        const needsCopy = !fs.existsSync(localPath) || fs.statSync(localPath).size !== sourceStat.size;
        if (needsCopy) fs.copyFileSync(sharedPath, localPath);
      }
      return { ...row, file_path: localPath };
    } catch {
      return { ...row, file_path: sharedPath };
    }
  });
}

function replaceLocalTable(db, table, rows, options = {}) {
  const columns = db.prepare(`PRAGMA table_info(${table})`).all().map(col => col.name);
  if (!columns.length) return;
  const localRows = localizeAttachmentRows(db, table, rows, options);
  const tx = db.transaction(() => {
    db.prepare(`DELETE FROM ${table}`).run();
    if (!localRows?.length) return;
    const insertColumns = columns.filter(col => Object.prototype.hasOwnProperty.call(localRows[0], col));
    const placeholders = insertColumns.map(() => '?').join(', ');
    const stmt = db.prepare(`INSERT OR REPLACE INTO ${table} (${insertColumns.join(', ')}) VALUES (${placeholders})`);
    for (const row of localRows) stmt.run(...insertColumns.map(col => row[col]));
  });
  tx();
}

function remoteTableExists(remoteDb, table) {
  try {
    const row = remoteDb.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(table);
    return !!row;
  } catch {
    return false;
  }
}

function copySnapshotTablesToLocal(localDb, remoteDb, options = {}) {
  let copiedTables = 0;
  let copiedRows = 0;
  const missingTables = [];
  for (const table of SYNC_TABLES) {
    if (!remoteTableExists(remoteDb, table)) {
      missingTables.push(table);
      continue;
    }
    const rows = remoteDb.prepare(`SELECT * FROM ${table}`).all();
    const resolvedRows = typeof options.resolveRows === 'function' ? options.resolveRows(table, rows) : rows;
    replaceLocalTable(localDb, table, resolvedRows, options.replaceOptions || {});
    copiedTables += 1;
    copiedRows += rows.length;
  }
  if (!copiedTables) {
    throw new Error('Drive DB snapshot is not a valid ERP database: no expected tables found.');
  }
  ensureSystemAdmin(localDb);
  return { copiedTables, copiedRows, missingTables };
}

async function downloadAttachmentFile(db, serverUrl, token, cacheDir, table, row, viewer = {}) {
  if (!ATTACHMENT_TABLES.has(table) || !row?.id) return null;
  const localDir = getLocalAttachmentDir(cacheDir);
  const params = new URLSearchParams({
    table,
    id: String(row.id),
    actor: String(viewer.actor || ''),
    isAdmin: viewer.isAdmin ? '1' : '0',
  });
  const file = await serverRequest(serverUrl, token, `/api/files?${params.toString()}`);
  if (!file?.fileBase64) return null;
  const fileName = sanitizeFileName(file.fileName || row.file_name || `attachment-${row.id}`);
  const localPath = path.join(localDir, `${table}-${sanitizeFileName(row.id)}-${fileName}`);
  fs.writeFileSync(localPath, Buffer.from(String(file.fileBase64), 'base64'));
  db.prepare(`UPDATE ${table} SET file_path=? WHERE id=?`).run(localPath, row.id);
  return localPath;
}

async function downloadAttachmentFiles(db, serverUrl, token, cacheDir) {
  const localDir = getLocalAttachmentDir(cacheDir);
  for (const table of ATTACHMENT_TABLES) {
    const rows = db.prepare(`SELECT id, file_name, file_path FROM ${table}`).all();
    for (const row of rows) {
      if (!row?.id) continue;
      try {
        const file = await serverRequest(serverUrl, token, `/api/files?table=${encodeURIComponent(table)}&id=${encodeURIComponent(row.id)}`);
        if (!file?.fileBase64) continue;
        const fileName = sanitizeFileName(file.fileName || row.file_name || `attachment-${row.id}`);
        const localPath = path.join(localDir, `${table}-${sanitizeFileName(row.id)}-${fileName}`);
        fs.writeFileSync(localPath, Buffer.from(String(file.fileBase64), 'base64'));
        db.prepare(`UPDATE ${table} SET file_path=? WHERE id=?`).run(localPath, row.id);
      } catch {}
    }
  }
}

async function pullSnapshotToLocalCache({ serverUrl, token, cacheDir }) {
  const db = getDatabase() || initLocalCache();
  const snapshot = await serverRequest(serverUrl, token, '/api/snapshot');
  for (const [table, rows] of Object.entries(snapshot.tables || {})) {
    replaceLocalTable(db, table, Array.isArray(rows) ? rows : []);
  }
  ensureSystemAdmin(db);
  return snapshot;
}

function getDirectDbPath(directDbDir) {
  return path.join(normalizeDirectDbDir(directDbDir), DIRECT_DB_FILE);
}

async function pullDirectDbSnapshotToLocalCache({ directDbDir, cacheDir }) {
  const { remoteDbPath, snapshotPath } = await createDirectReadSnapshot(directDbDir, cacheDir);
  const localDb = getDatabase() || initLocalCache();
  const remoteDb = new Database(snapshotPath, { readonly: true, fileMustExist: true });
  try {
    const result = copySnapshotTablesToLocal(localDb, remoteDb, {
      resolveRows: (table, rows) => resolveDirectAttachmentRows(directDbDir, table, rows, cacheDir),
      replaceOptions: { preserveAttachmentPaths: true },
    });
    return { ok: true, serverTime: new Date().toISOString(), direct: true, remoteDbPath, snapshotPath, ...result };
  } finally {
    remoteDb.close();
  }
}

async function pullDriveSnapshotToLocalCache({ driveScriptUrl, driveToken, cacheDir }) {
  const snapshot = await appsScriptGet(driveScriptUrl, driveToken, 'snapshot');
  const localDb = getDatabase() || initLocalCache();
  if (snapshot.tables && typeof snapshot.tables === 'object') {
    for (const [table, rows] of Object.entries(snapshot.tables || {})) {
      replaceLocalTable(localDb, table, Array.isArray(rows) ? rows : []);
    }
    ensureSystemAdmin(localDb);
    return { ok: true, serverTime: snapshot.serverTime || new Date().toISOString(), drive: true };
  }
  if (!snapshot.base64) throw new Error('Apps Script snapshot did not include DB data.');
  const snapshotPath = getDriveReadSnapshotPath(cacheDir);
  const tempPath = path.join(path.dirname(snapshotPath), `${path.basename(snapshotPath, '.db')}-${process.pid}-${Date.now()}.db`);
  removeSqliteFiles(tempPath);
  decodeBase64ToFile(snapshot.base64, tempPath);
  const remoteDb = new Database(tempPath, { readonly: true, fileMustExist: true });
  try {
    const result = copySnapshotTablesToLocal(localDb, remoteDb);
    remoteDb.close();
    removeSqliteFiles(snapshotPath);
    fs.renameSync(tempPath, snapshotPath);
    return {
      ok: true,
      serverTime: snapshot.updatedAt || snapshot.serverTime || new Date().toISOString(),
      drive: true,
      snapshotPath,
      snapshotMode: snapshot.snapshotMode || '',
      sourceFileName: snapshot.sourceFileName || snapshot.fileName || '',
      ...result,
    };
  } finally {
    try { remoteDb.open && remoteDb.close(); } catch {}
    removeSqliteFiles(tempPath);
  }
}

function getDirectClientFolder(dir, clientId, actor) {
  const owner = sanitizeFileName(clientId || actor || 'remote-client');
  return path.join(dir, DIRECT_CLIENTS_DIR, `remote-${owner}`);
}

function getDirectClientQueuePath(dir, clientId, actor) {
  const clientFolder = getDirectClientFolder(dir, clientId, actor);
  fs.mkdirSync(clientFolder, { recursive: true });
  return path.join(clientFolder, DIRECT_CLIENT_QUEUE_FILE);
}

function countQueueFileRows(queuePath) {
  try {
    if (!queuePath || !fs.existsSync(queuePath)) return 0;
    return fs.readFileSync(queuePath, 'utf8').split(/\r?\n/).filter(Boolean).length;
  } catch {
    return 0;
  }
}

function getDirectQueueStatus({ directDbDir, clientId, actor } = {}) {
  try {
    const dir = normalizeDirectDbDir(directDbDir);
    const clientFolder = getDirectClientFolder(dir, clientId, actor);
    const queuePath = path.join(clientFolder, DIRECT_CLIENT_QUEUE_FILE);
    return {
      ok: true,
      direct: true,
      pendingCount: countQueueFileRows(queuePath),
      queueFile: queuePath,
    };
  } catch (error) {
    return {
      ok: false,
      direct: true,
      pendingCount: 0,
      error: String(error?.message || error),
    };
  }
}

function queueDirectMutations({ directDbDir, authToken, actor, clientId, mutations }) {
  const dir = normalizeDirectDbDir(directDbDir);
  fs.mkdirSync(dir, { recursive: true });
  const clientFolder = getDirectClientFolder(dir, clientId, actor);
  fs.mkdirSync(clientFolder, { recursive: true });
  const cleanMutations = withDirectAttachmentPayloads(dir, mutations || [], clientFolder).filter(Boolean);
  if (!cleanMutations.length) return { ok: true, skipped: true, pendingCount: 0 };
  const queuePath = path.join(clientFolder, DIRECT_CLIENT_QUEUE_FILE);
  const item = {
    id: cryptoRandomId(),
    clientId: String(clientId || ''),
    authToken: String(authToken || ''),
    actor: String(actor || 'system'),
    mutations: cleanMutations,
    queuedAt: new Date().toISOString(),
  };
  fs.appendFileSync(queuePath, `${JSON.stringify(item)}\n`, 'utf8');
  const pendingCount = countQueueFileRows(queuePath);
  return { ok: true, queued: true, direct: true, pendingCount, queueFile: queuePath };
}

async function queueDriveMutations({ driveScriptUrl, driveToken, actor, clientId, mutations }) {
  const cleanMutations = withAttachmentPayloads(mutations || []).filter(Boolean);
  if (!cleanMutations.length) return { ok: true, skipped: true, pendingCount: 0 };
  const item = {
    id: cryptoRandomId(),
    clientId: String(clientId || ''),
    actor: String(actor || 'system'),
    mutations: cleanMutations,
    queuedAt: new Date().toISOString(),
  };
  const result = await appsScriptPost(driveScriptUrl, driveToken, {
    action: 'queue',
    clientId: String(clientId || actor || 'remote-client'),
    actor: String(actor || 'system'),
    items: [item],
  });
  return { ok: true, queued: true, drive: true, pendingCount: Number(result.pendingCount || 0), fileId: result.fileId || '' };
}

async function getDriveQueueStatus({ driveScriptUrl, driveToken, clientId, actor } = {}) {
  try {
    const result = await appsScriptGet(driveScriptUrl, driveToken, 'queueStatus', {
      clientId: String(clientId || actor || 'remote-client'),
    });
    return { ok: true, drive: true, pendingCount: Number(result.pendingCount || 0) };
  } catch {
    return { ok: true, drive: true, pendingCount: 0 };
  }
}

function writeDirectQueueConfig(directDbDir, pollSeconds) {
  const raw = String(directDbDir || '').trim();
  if (!raw) return;
  const dir = normalizeDirectDbDir(raw);
  const seconds = Math.max(1, Number.parseInt(pollSeconds, 10) || 10);
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, DIRECT_QUEUE_CONFIG_FILE), JSON.stringify({ pollSeconds: seconds }, null, 2), 'utf8');
}

function cryptoRandomId() {
  try {
    return require('crypto').randomUUID();
  } catch {
    return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
  }
}

async function pushMutations({ serverUrl, token, actor, mutations }) {
  return serverRequest(serverUrl, token, '/api/sync', {
    method: 'POST',
    body: JSON.stringify({ actor, mutations: withAttachmentPayloads(mutations) }),
  });
}

module.exports = {
  initLocalCache,
  downloadAttachmentFile,
  pullSnapshotToLocalCache,
  pullDirectDbSnapshotToLocalCache,
  pullDriveSnapshotToLocalCache,
  pushMutations,
  queueDirectMutations,
  queueDriveMutations,
  getDirectQueueStatus,
  getDriveQueueStatus,
  writeDirectQueueConfig,
};
