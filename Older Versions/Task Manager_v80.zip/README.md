# ERP Task Manager — Electron + React Desktop App

A full-featured ERP Task Management desktop application built with **Electron** + **React** + **SQLite**, converted from the original PySide6 Python app.

---

## Features

- **Login System** — Role-based access (Admin, Manager, Employee)
- **Dashboard** — Stats cards, recent tasks, project progress, open issues
- **Tasks** — Full CRUD with search, filter, status badges, time-left tracking
- **Projects** — Card grid view with progress bars, team assignment
- **Recurring Templates** — Daily/Weekly/Monthly/Annual/Custom scheduling
- **Calendar** — Month view with task events
- **Issues** — Bug/issue tracking linked to tasks
- **Template Library** — Reusable task templates
- **Inventory** — Stock management with movement tracking
- **Reports** — Status distribution charts, employee performance
- **User Management** — Add/edit employees and teams (Admin only)
- **Settings** — Date format, notifications, preferences
- **CSV Export** — Export tasks via File menu (Ctrl+E)
- **Window State Persistence** — Remembers size, position, maximized state
- **SQLite Database** — Same schema as the original PySide6 app (compatible!)

---

## Tech Stack

| Layer       | Technology                          |
|-------------|-------------------------------------|
| Desktop     | Electron 33                         |
| Frontend    | React 18 + Vite 6                   |
| Database    | better-sqlite3 (same schema as PySide6 app) |
| Icons       | Lucide React                        |
| State       | electron-store (window persistence)  |
| Build       | electron-builder                    |

---

## Prerequisites

- **Node.js** ≥ 18 (recommended: v20+)
- **npm** ≥ 9

---

## Quick Start

### 1. Install Dependencies

```bash
cd erp-electron
npm install
```

> **Note:** `better-sqlite3` is a native module. If you see build errors, ensure you have the C++ build tools:
> - **Windows:** `npm install -g windows-build-tools` or install Visual Studio Build Tools
> - **macOS:** `xcode-select --install`
> - **Linux:** `sudo apt install build-essential python3`

### 2. Run in Development Mode

```bash
npm run dev
```

This starts:
- Vite dev server on `http://localhost:5173` (React app with hot reload)
- Electron window pointing to the dev server (with DevTools open)

### 3. Build for Production

```bash
npm run build
```

This will:
1. Build the React app (`vite build` → `dist/` folder)
2. Package with electron-builder → `release/` folder

The output installer will be in `release/`:
- **Windows:** `.exe` (NSIS installer)
- **macOS:** `.dmg`
- **Linux:** `.AppImage`

Windows builds now create separate setup files:
- `release/client/Task Manager Client Setup <version>.exe`
- `release/server/Task Manager Server Setup <version>.exe`

---

## Project Structure

```
erp-electron/
├── main.js           # Electron main process (window, menu, IPC)
├── preload.js        # Secure bridge (contextBridge API)
├── database.js       # SQLite setup (same schema as PySide6 app)
├── package.json      # Dependencies & build config
├── vite.config.js    # Vite bundler config
├── index.html        # HTML entry point
├── src/
│   ├── main.jsx      # React entry point
│   └── App.jsx       # Full React application
├── public/
│   └── icon.png      # App icon (add your own 512x512 PNG)
├── dist/             # Built React app (generated)
└── release/          # Packaged installers (generated)
```

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                    Electron Main                     │
│  main.js → BrowserWindow, Menu, IPC Handlers        │
│  database.js → SQLite (better-sqlite3)              │
└─────────────────┬───────────────────────────────────┘
                  │ IPC (contextBridge)
                  │ preload.js exposes window.electronAPI
┌─────────────────┴───────────────────────────────────┐
│                   React Renderer                     │
│  App.jsx → Pages, Components, Modals                │
│  Uses window.electronAPI for DB calls               │
│  Falls back to in-memory data in browser dev mode   │
└─────────────────────────────────────────────────────┘
```

---

## Database Compatibility

The SQLite schema is **identical** to the original PySide6 `erp_tasks.db`. You can:

1. Copy your existing `erp_tasks.db` file to the Electron app's user data folder:
   - **Windows:** `%APPDATA%/erp-task-manager/erp_tasks.db`
   - **macOS:** `~/Library/Application Support/erp-task-manager/erp_tasks.db`
   - **Linux:** `~/.config/erp-task-manager/erp_tasks.db`

2. The app will read all your existing tasks, employees, projects, etc.

---

## Adding an App Icon

Place a `512x512` PNG file at `public/icon.png`. For multi-platform support:

```bash
# Install icon generation tool
npm install -g electron-icon-maker

# Generate all formats from a single PNG
electron-icon-maker --input=public/icon.png --output=build
```

---

## Keyboard Shortcuts

| Shortcut       | Action           |
|----------------|------------------|
| `Ctrl+E`       | Export tasks CSV  |
| `Ctrl+R`       | Reload app        |
| `Ctrl+Shift+I` | Toggle DevTools   |
| `F11`          | Fullscreen        |
| `Ctrl+Q`       | Quit              |

---

## License

MIT
